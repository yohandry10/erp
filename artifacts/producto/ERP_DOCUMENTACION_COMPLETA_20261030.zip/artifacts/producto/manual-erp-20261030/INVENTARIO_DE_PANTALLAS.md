# Inventario de pantallas desde el código

Se verificaron los hashes de los 124 archivos `page.tsx` del dashboard del candidato. Cada ruta es una referencia de fuente; no prueba que una pantalla haya sido contrastada visualmente, que su recorrido esté explicado por completo ni que una cuenta concreta tenga permiso. Las páginas de detalle y edición no son necesariamente capacidades empresariales distintas.

| Ruta | Referencia de proceso | Estado de esta comprobación |
|---|---|---|
| `/dashboard/analytics` | Fuera de UAT; fuente identificada | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/audit-logs` | [Capítulo 37](MANUAL_DEL_PRODUCTO.html#capitulo-37) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ayuda` | [Capítulo 37](MANUAL_DEL_PRODUCTO.html#capitulo-37) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/cajas` | [Capítulo 12](MANUAL_DEL_PRODUCTO.html#capitulo-12) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/cotizaciones/[id]` | [Capítulo 13](MANUAL_DEL_PRODUCTO.html#capitulo-13) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/cotizaciones/nueva` | [Capítulo 13](MANUAL_DEL_PRODUCTO.html#capitulo-13) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/cotizaciones` | [Capítulo 13](MANUAL_DEL_PRODUCTO.html#capitulo-13) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/devoluciones/[id]` | [Capítulo 14](MANUAL_DEL_PRODUCTO.html#capitulo-14) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/devoluciones/nueva` | [Capítulo 14](MANUAL_DEL_PRODUCTO.html#capitulo-14) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/devoluciones` | [Capítulo 14](MANUAL_DEL_PRODUCTO.html#capitulo-14) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/ordenes/[id]` | [Capítulo 13](MANUAL_DEL_PRODUCTO.html#capitulo-13) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/ordenes/nueva` | [Capítulo 13](MANUAL_DEL_PRODUCTO.html#capitulo-13) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/ordenes` | [Capítulo 13](MANUAL_DEL_PRODUCTO.html#capitulo-13) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras` | [Capítulo 13](MANUAL_DEL_PRODUCTO.html#capitulo-13) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/proveedores/[id]/editar` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/proveedores/[id]` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/proveedores/nuevo` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/proveedores` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/recepciones/[id]` | [Capítulo 14](MANUAL_DEL_PRODUCTO.html#capitulo-14) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/recepciones/nueva` | [Capítulo 14](MANUAL_DEL_PRODUCTO.html#capitulo-14) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/compras/recepciones` | [Capítulo 14](MANUAL_DEL_PRODUCTO.html#capitulo-14) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/configuracion/empresa` | [Capítulo 04](MANUAL_DEL_PRODUCTO.html#capitulo-04) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/configuracion` | [Capítulo 04](MANUAL_DEL_PRODUCTO.html#capitulo-04) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/configuracion/rrhh` | [Capítulo 34](MANUAL_DEL_PRODUCTO.html#capitulo-34) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/configuracion/sucursales` | [Capítulo 04](MANUAL_DEL_PRODUCTO.html#capitulo-04) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/configuracion/ventas` | [Capítulo 04](MANUAL_DEL_PRODUCTO.html#capitulo-04) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/activos-fijos` | [Capítulo 26](MANUAL_DEL_PRODUCTO.html#capitulo-26) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/asientos/[id]/editar` | [Capítulo 23](MANUAL_DEL_PRODUCTO.html#capitulo-23) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/asientos/[id]` | [Capítulo 23](MANUAL_DEL_PRODUCTO.html#capitulo-23) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/asientos/nuevo` | [Capítulo 23](MANUAL_DEL_PRODUCTO.html#capitulo-23) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/asientos` | [Capítulo 23](MANUAL_DEL_PRODUCTO.html#capitulo-23) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/centros-costo/[id]/editar` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/centros-costo/[id]` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/centros-costo/nuevo` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/centros-costo` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/consignaciones` | [Capítulo 28](MANUAL_DEL_PRODUCTO.html#capitulo-28) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/consolidacion` | [Capítulo 30](MANUAL_DEL_PRODUCTO.html#capitulo-30) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/diferidos` | [Capítulo 27](MANUAL_DEL_PRODUCTO.html#capitulo-27) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/estados` | [Capítulo 31](MANUAL_DEL_PRODUCTO.html#capitulo-31) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/impuestos/anual` | [Capítulo 32](MANUAL_DEL_PRODUCTO.html#capitulo-32) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/impuestos` | [Capítulo 32](MANUAL_DEL_PRODUCTO.html#capitulo-32) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/monitoreo` | [Capítulo 37](MANUAL_DEL_PRODUCTO.html#capitulo-37) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad` | [Capítulo 23](MANUAL_DEL_PRODUCTO.html#capitulo-23) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/partidas` | [Capítulo 23](MANUAL_DEL_PRODUCTO.html#capitulo-23) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/periodos/[id]` | [Capítulo 24](MANUAL_DEL_PRODUCTO.html#capitulo-24) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/periodos/nuevo` | [Capítulo 24](MANUAL_DEL_PRODUCTO.html#capitulo-24) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/periodos` | [Capítulo 24](MANUAL_DEL_PRODUCTO.html#capitulo-24) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/plantillas` | [Capítulo 23](MANUAL_DEL_PRODUCTO.html#capitulo-23) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/presupuestos/[id]` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/presupuestos/alertas` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/presupuestos/comparacion` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/presupuestos/lista` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/presupuestos/nuevo` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/presupuestos` | [Capítulo 25](MANUAL_DEL_PRODUCTO.html#capitulo-25) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/revaluacion` | [Capítulo 29](MANUAL_DEL_PRODUCTO.html#capitulo-29) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/contabilidad/tipos-cambio` | [Capítulo 29](MANUAL_DEL_PRODUCTO.html#capitulo-29) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/cpe/cotizaciones` | [Capítulo 15](MANUAL_DEL_PRODUCTO.html#capitulo-15) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/cpe` | [Capítulo 15](MANUAL_DEL_PRODUCTO.html#capitulo-15) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/documentos/descargas` | [Capítulo 17](MANUAL_DEL_PRODUCTO.html#capitulo-17) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/documentos` | [Capítulo 17](MANUAL_DEL_PRODUCTO.html#capitulo-17) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/ajustes-fiscales` | [Capítulo 20](MANUAL_DEL_PRODUCTO.html#capitulo-20) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/bancos/[id]/editar` | [Capítulo 21](MANUAL_DEL_PRODUCTO.html#capitulo-21) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/bancos/[id]` | [Capítulo 21](MANUAL_DEL_PRODUCTO.html#capitulo-21) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/bancos/nueva` | [Capítulo 21](MANUAL_DEL_PRODUCTO.html#capitulo-21) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/bancos` | [Capítulo 21](MANUAL_DEL_PRODUCTO.html#capitulo-21) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/conciliacion/[id]` | [Capítulo 21](MANUAL_DEL_PRODUCTO.html#capitulo-21) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/conciliacion` | [Capítulo 21](MANUAL_DEL_PRODUCTO.html#capitulo-21) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/cxc` | [Capítulo 18](MANUAL_DEL_PRODUCTO.html#capitulo-18) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/cxp/[id]` | [Capítulo 19](MANUAL_DEL_PRODUCTO.html#capitulo-19) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/cxp/nueva` | [Capítulo 19](MANUAL_DEL_PRODUCTO.html#capitulo-19) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/cxp` | [Capítulo 19](MANUAL_DEL_PRODUCTO.html#capitulo-19) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas` | [Capítulo 22](MANUAL_DEL_PRODUCTO.html#capitulo-22) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/reportes` | [Capítulo 31](MANUAL_DEL_PRODUCTO.html#capitulo-31) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/tesoreria/flujo-caja` | [Capítulo 22](MANUAL_DEL_PRODUCTO.html#capitulo-22) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/tesoreria/lote` | [Capítulo 22](MANUAL_DEL_PRODUCTO.html#capitulo-22) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/tesoreria` | [Capítulo 22](MANUAL_DEL_PRODUCTO.html#capitulo-22) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/finanzas/tesoreria/programacion` | [Capítulo 22](MANUAL_DEL_PRODUCTO.html#capitulo-22) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/gre/nueva` | [Capítulo 16](MANUAL_DEL_PRODUCTO.html#capitulo-16) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/gre` | [Capítulo 16](MANUAL_DEL_PRODUCTO.html#capitulo-16) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/almacenes` | [Capítulo 06](MANUAL_DEL_PRODUCTO.html#capitulo-06) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/categorias` | [Capítulo 06](MANUAL_DEL_PRODUCTO.html#capitulo-06) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/kardex` | [Capítulo 07](MANUAL_DEL_PRODUCTO.html#capitulo-07) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/logistica/listo-despacho` | [Capítulo 09](MANUAL_DEL_PRODUCTO.html#capitulo-09) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/logistica/ordenes-pendientes` | [Capítulo 09](MANUAL_DEL_PRODUCTO.html#capitulo-09) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/operaciones` | [Capítulo 07](MANUAL_DEL_PRODUCTO.html#capitulo-07) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario` | [Capítulo 07](MANUAL_DEL_PRODUCTO.html#capitulo-07) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/productos/[id]/editar` | [Capítulo 06](MANUAL_DEL_PRODUCTO.html#capitulo-06) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/productos/nuevo` | [Capítulo 06](MANUAL_DEL_PRODUCTO.html#capitulo-06) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/productos` | [Capítulo 06](MANUAL_DEL_PRODUCTO.html#capitulo-06) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/inventario/recepciones` | [Capítulo 07](MANUAL_DEL_PRODUCTO.html#capitulo-07) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/offline` | [Capítulo 39](MANUAL_DEL_PRODUCTO.html#capitulo-39) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard` | [Capítulo 31](MANUAL_DEL_PRODUCTO.html#capitulo-31) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/pos` | [Capítulo 11](MANUAL_DEL_PRODUCTO.html#capitulo-11) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/asistencia` | [Capítulo 33](MANUAL_DEL_PRODUCTO.html#capitulo-33) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/candidatos` | [Capítulo 33](MANUAL_DEL_PRODUCTO.html#capitulo-33) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/contratos` | [Capítulo 33](MANUAL_DEL_PRODUCTO.html#capitulo-33) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/fichas-sunat` | [Capítulo 36](MANUAL_DEL_PRODUCTO.html#capitulo-36) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/liquidaciones` | [Capítulo 35](MANUAL_DEL_PRODUCTO.html#capitulo-35) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh` | [Capítulo 33](MANUAL_DEL_PRODUCTO.html#capitulo-33) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/pagos` | [Capítulo 34](MANUAL_DEL_PRODUCTO.html#capitulo-34) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/planilla-electronica` | [Capítulo 36](MANUAL_DEL_PRODUCTO.html#capitulo-36) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/planillas` | [Capítulo 34](MANUAL_DEL_PRODUCTO.html#capitulo-34) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/reportes` | [Capítulo 33](MANUAL_DEL_PRODUCTO.html#capitulo-33) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/rrhh/solicitudes` | [Capítulo 33](MANUAL_DEL_PRODUCTO.html#capitulo-33) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/sire` | [Capítulo 32](MANUAL_DEL_PRODUCTO.html#capitulo-32) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/usuarios` | [Capítulo 03](MANUAL_DEL_PRODUCTO.html#capitulo-03) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/aprobaciones` | [Capítulo 08](MANUAL_DEL_PRODUCTO.html#capitulo-08) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/clientes/[id]/editar` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/clientes/[id]` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/clientes/nuevo` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/clientes` | [Capítulo 05](MANUAL_DEL_PRODUCTO.html#capitulo-05) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/comercial` | [Capítulo 08](MANUAL_DEL_PRODUCTO.html#capitulo-08) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/cotizaciones/[id]` | [Capítulo 08](MANUAL_DEL_PRODUCTO.html#capitulo-08) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/cotizaciones/nueva` | [Capítulo 08](MANUAL_DEL_PRODUCTO.html#capitulo-08) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/cotizaciones` | [Capítulo 08](MANUAL_DEL_PRODUCTO.html#capitulo-08) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas` | [Capítulo 08](MANUAL_DEL_PRODUCTO.html#capitulo-08) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/pedidos/[id]` | [Capítulo 09](MANUAL_DEL_PRODUCTO.html#capitulo-09) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/pedidos/nuevo` | [Capítulo 09](MANUAL_DEL_PRODUCTO.html#capitulo-09) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/pedidos` | [Capítulo 09](MANUAL_DEL_PRODUCTO.html#capitulo-09) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/reportes` | [Capítulo 31](MANUAL_DEL_PRODUCTO.html#capitulo-31) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/rma/[id]` | [Capítulo 10](MANUAL_DEL_PRODUCTO.html#capitulo-10) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/rma/nuevo` | [Capítulo 10](MANUAL_DEL_PRODUCTO.html#capitulo-10) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/ventas/rma` | [Capítulo 10](MANUAL_DEL_PRODUCTO.html#capitulo-10) | Fuente verificada; sin contraste visual nuevo |
| `/dashboard/wizard` | [Capítulo 02](MANUAL_DEL_PRODUCTO.html#capitulo-02) | Fuente verificada; sin contraste visual nuevo |

## Analytics no desaparece por estar excluido de UAT

La ruta `/dashboard/analytics` existe en el candidato. Su fuente solicita ventas en el tiempo, deudas de clientes, deudas de proveedores, ventas por categoría y KPI visuales mediante cinco consultas de Analytics. Está fuera de la matriz UAT utilizada y no tiene aquí una guía detallada de interpretación y fórmulas verificada. No se equipara esa exclusión a ausencia del producto, ni se acredita su exactitud por las pruebas de otros reportes.

La revisión visual por pantalla y el catálogo semántico de comportamientos requieren su propia evidencia documental. Este inventario no cierra esos puntos por contar archivos.
