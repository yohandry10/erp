# Anexo de cobertura UAT del manual de producto

Este anexo es el respaldo de trazabilidad del libro. El punto de entrada para operar el ERP es [MANUAL_DEL_PRODUCTO.md](MANUAL_DEL_PRODUCTO.md), no esta lista de pruebas.

**Cobertura:** 988 identificadores y 19.598 ocurrencias de criterios originales; ninguno eliminado ni deduplicado.

Las variantes de permisos, fuentes incompletas, errores, respuestas tardías, concurrencia, almacenamiento, reinicios y pérdida de confirmación se documentan en su dominio y en los capítulos transversales 03, 38 y 39. La asignación a un capítulo no convierte un escenario controlado en una operación productiva real.

## Fuentes

Matriz certificada: `C:\Users\PC\.codex\worktrees\b110\erp\artifacts\functional-uat\thread-resume-20261026\r2-r3-consolidated-complete988-20261030.json`

SHA-256: `5bb364da313486eb48d3ea77e47d54816b62998c70211546ef1396b22209caa5`

[Expediente completo de los 19.598 criterios](../../functional-uat/continuation-20261030/documentacion-uat/UAT_COMPLETO.html).

## Cobertura por capítulo

| Capítulo | Requisitos principales | Criterios originales |
|---|---:|---:|
| 01. El producto y sus conceptos básicos | 0 | 0 |
| 02. Primer acceso y preparación de la empresa | 7 | 24 |
| 03. Usuarios, roles, permisos y sesiones | 14 | 91 |
| 04. Identidad, parámetros, sucursales y series | 22 | 276 |
| 05. Clientes, proveedores e importaciones | 9 | 61 |
| 06. Productos, servicios y maestros de inventario | 43 | 896 |
| 07. Existencias, kardex, ajustes y transferencias | 33 | 924 |
| 08. Gestión comercial: precios, comisiones y cotizaciones | 9 | 76 |
| 09. Pedidos, reservas, preparación y entrega | 20 | 381 |
| 10. Devoluciones de clientes, notas y saldo a favor | 3 | 18 |
| 11. Punto de venta | 12 | 37 |
| 12. Cajas, arqueos, turnos y cortes | 21 | 162 |
| 13. Compras: cotización y orden | 44 | 442 |
| 14. Recepciones y devoluciones al proveedor | 37 | 641 |
| 15. Comprobantes electrónicos y ciclo fiscal | 49 | 1799 |
| 16. Guías de remisión y traslado | 27 | 857 |
| 17. Centro de documentos, archivos y bajas RA/RC | 9 | 18 |
| 18. Cuentas por cobrar y recuperación de cartera | 22 | 1155 |
| 19. Facturas de proveedor y cuentas por pagar | 62 | 1671 |
| 20. Anticipos y ajustes fiscales financieros | 1 | 1 |
| 21. Bancos y conciliación | 6 | 28 |
| 22. Tesorería y programación de pagos | 13 | 353 |
| 23. Contabilidad: asientos, partidas y plantillas | 9 | 42 |
| 24. Períodos y cierre contable | 25 | 789 |
| 25. Centros de costo, presupuestos y alertas | 70 | 1215 |
| 26. Activos fijos | 38 | 919 |
| 27. Ingresos y gastos diferidos | 27 | 927 |
| 28. Consignaciones | 8 | 141 |
| 29. Monedas, tipos de cambio y revaluación | 33 | 469 |
| 30. Consolidación y reportes configurables | 18 | 306 |
| 31. Libros, estados financieros y reportes operativos | 93 | 1708 |
| 32. Impuestos y SIRE | 25 | 369 |
| 33. Recursos humanos: personas, contratos y solicitudes | 26 | 567 |
| 34. Planilla, vacaciones remuneradas y EPS | 105 | 1758 |
| 35. CTS y liquidaciones | 14 | 37 |
| 36. PLAME, T-Registro y contexto por país | 2 | 7 |
| 37. Auditoría, notificaciones y ayuda | 18 | 366 |
| 38. Lecturas, borradores y operaciones interrumpidas | 0 | 0 |
| 39. Trabajo sin conexión y escritorio Windows | 14 | 67 |
| 40. Recorridos completos de trabajo | 0 | 0 |
| 41. Incidencias frecuentes y soporte funcional | 0 | 0 |
| 42. Glosario y alcance de esta edición | 0 | 0 |

Los capítulos de modelo, recorridos, soporte y glosario integran los dominios sin duplicar su conteo.

## Correspondencia del primero al último

| N.º | ID UAT original | Función o escenario respaldado | Capítulo principal | Contratos transversales | Criterios |
|---:|---|---|---|---|---:|
| 1 | `accounting-catalog-scope-roles` | Activos/diferidos/FX: vendedor denegado y empresa2 sin catálogos ni IDs financieros ajenos | 23. Contabilidad: asientos, partidas y plantillas | 03, 29, 35, 38 | 12 |
| 2 | `accounting-close-preflight-reopen` | Preflight congruente, error503/retry, cierreSept2025, rechazo de escritura y reapertura | 24. Períodos y cierre contable | 35, 38 | 13 |
| 3 | `accounting-cost-center-budget` | Crear/editar centro y presupuesto; catálogo503 bloquea guardar y retry recupera | 25. Centros de costo, presupuestos y alertas | 35, 38 | 7 |
| 4 | `accounting-current-analytic-save-remove-real` | Asignar centro100% en borrador, recargar y quitar eje sin alterar importes | 23. Contabilidad: asientos, partidas y plantillas | 35 | 1 |
| 5 | `accounting-current-draft-delete-real` | Eliminar asiento borrador: cancelar sin solicitud, confirmar, recargar y verificar ausencia de cabecera y líneas | 23. Contabilidad: asientos, partidas y plantillas | 35 | 1 |
| 6 | `accounting-current-open-items-pair-real` | Conciliar dos partidas confirmadas por50, recargar y verificar pareja única | 23. Contabilidad: asientos, partidas y plantillas | 15, 35 | 1 |
| 7 | `accounting-current120-statements-books-ple-tax` | Corte120: cinco estados/siete ratios/diez libros/cincoPLE y tributos sin nuevas versiones | 31. Libros, estados financieros y reportes operativos | 34, 35, 38 | 4 |
| 8 | `accounting-current126-statements-books-ple-tax-finance` | Corte126: estados/ratios/diezlibros/cincoPLE/tributos/cartera/proyección con fallos y retry | 31. Libros, estados financieros y reportes operativos | 35, 38 | 4 |
| 9 | `accounting-current130-statements-books-ple-tax-finance` | Corte130: cincoestados/sieteratios/diezlibros/cincoPLE/tributos/cartera yproyección | 31. Libros, estados financieros y reportes operativos | 35, 38 | 4 |
| 10 | `accounting-current131-statements-books-ple-tax-finance` | Corte131:cinco estados/siete ratios/diez libros/cincoPLE/tributos ycartera actual web/nativo | 31. Libros, estados financieros y reportes operativos | 03, 15, 34, 35, 38 | 236 |
| 11 | `accounting-journal-search-print` | Buscar reembolso en diario, abrir asiento, imprimir PDF y recargar | 23. Contabilidad: asientos, partidas y plantillas | 31, 35 | 3 |
| 12 | `accounting-main-balance_comprobacion` | Consultar Balance de Comprobación, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 13 | `accounting-main-estado_resultados` | Consultar Estado de Resultados, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 14 | `accounting-main-kardex_valorizado` | Consultar Kardex Valorizado, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 15 | `accounting-main-libro_caja_bancos` | Consultar Libro Caja y Bancos, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 16 | `accounting-main-libro_inventarios_balances` | Consultar Libro de Inventarios y Balances, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 17 | `accounting-main-libro_planillas` | Consultar Libro de Planillas, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 34, 35, 38 | 3 |
| 18 | `accounting-main-libros_electronicos_sunat` | Consultar Panel de Libros Electrónicos SUNAT, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 3 |
| 19 | `accounting-main-period-export` | Cambiar octubre/septiembre, recuperar fallo sin exportar filas anteriores y descartar respuestas tardías | 31. Libros, estados financieros y reportes operativos | 34, 35, 38 | 5 |
| 20 | `accounting-main-registro_activos_fijos` | Consultar Registro de Activos Fijos, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 21 | `accounting-main-registro_compras` | Consultar Registro de Compras, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 22 | `accounting-main-registro_costos` | Consultar Registro de Costos, retirar datos ante503/200incompleto y recuperar desde Reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 23 | `accounting-main-roles-isolation` | Cambiar empresa/actor en el mismo navegador y verificar permisos de las diez vistas | 31. Libros, estados financieros y reportes operativos | 03, 15, 34, 35 | 34 |
| 24 | `accounting-manual-maker-checker` | Bloquear0/centavo descuadrado, crear7.85, editar9.85 y confirmar/reversar por otro actor | 23. Contabilidad: asientos, partidas y plantillas | 03, 35 | 4 |
| 25 | `accounting-payroll` | Reencolar desdeUI el evento fallido y worker automático confirma devengo en diario | 23. Contabilidad: asientos, partidas y plantillas | 34, 35, 38 | 3 |
| 26 | `accounting-reader-five-writer-denials` | Lector intenta alta/retiro/depreciación de activo y alta/devengo de diferido;403 y recarga preservan catálogos | 23. Contabilidad: asientos, partidas y plantillas | 03, 35 | 7 |
| 27 | `accounting-reader-role-real` | Crear rol contable de cuatro permisos de lectura, asignar usuario y abrir activos/cronograma/diferidos | 03. Usuarios, roles, permisos y sesiones | 35 | 5 |
| 28 | `accounting-reads-comparison-january` | Comparación atómica actual/anterior con503/incompleto/retry; enero contra diciembre anterior | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 29 | `accounting-reads-current-books-nine-purchases` | Diez libros actuales: nueve compras, recuperación, roles y Excel fiscal por moneda | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 2 |
| 30 | `accounting-reads-current-excel-pdf` | Descargar tres Excel/PDF de estados: tipos numéricos, signos, códigosString, moneda y seis páginas revisadas | 31. Libros, estados financieros y reportes operativos | 35, 38 | 6 |
| 31 | `accounting-reads-current-ple-five-files` | Cinco PLE individuales y Descargar todos tras503, mismo corte actualizado y archivos exactos | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 6 |
| 32 | `accounting-reads-current-tax-no-saves` | Consultar/recalcular tributos tras nuevasCxP, recuperación y recarga sin guardar versiones | 32. Impuestos y SIRE | 35, 38 | 1 |
| 33 | `accounting-reads-current111-raw-ratios` | Consultar cinco estados actuales y contrastar32cuentas y siete ratios contra111asientos confirmados | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 1 |
| 34 | `accounting-reads-five-states-roles-isolation` | Cinco estados: OWNER→lector inventario403→lector contable200→empresa2vacía→OWNER; red sin cache ajena | 31. Libros, estados financieros y reportes operativos | 03, 35 | 1 |
| 35 | `accounting-reads-refresh-button-contract` | Refrescar desde botón con503/error persistente y POSTreal201/período en cuerpo | 31. Libros, estados financieros y reportes operativos | 35, 38 | 2 |
| 36 | `accounting-reads-strict-recovery-races` | Cinco estados:503/200incompleto/campos ausentes o inválidos/red/retry y descarte de consultas tardías | 31. Libros, estados financieros y reportes operativos | 35, 38 | 1 |
| 37 | `accounting-template-manual-lifecycle` | Crear plantilla manual, recuperar catálogo503, generar7.25, bloquear duplicado, anular borrador y eliminar conservando historial | 23. Contabilidad: asientos, partidas y plantillas | 35, 38 | 10 |
| 38 | `asset-calendar-defaults-dates` | Adquisición e inicio de depreciación según día civil de Perú; tres zonas web y Windows | 26. Activos fijos | 35 | 12 |
| 39 | `asset-calendar-defaults-manual` | Fechas y período editados se conservan al cerrar y abrir el formulario sin envío | 26. Activos fijos | 35 | 12 |
| 40 | `asset-calendar-defaults-period` | Período de depreciación inicial según día civil confirmado de Perú en cambio de año y bisiesto | 26. Activos fijos | 15, 35 | 12 |
| 41 | `asset-calendar-defaults-retirement` | Baja con fecha civil inicial y fecha manual preservada al cancelar; bien real DEPRECIADO sin retiro | 26. Activos fijos | 35 | 12 |
| 42 | `asset-create-operation-actor-held` | Alta de activo: respuesta completa retenida tras cambio real de actor no retira ni expone intención OWNER | 26. Activos fijos | 03, 35, 38 | 10 |
| 43 | `asset-create-operation-isolation` | Alta de activo: secundaria real no ve/envía intención primaria y retorno conserva cuerpo/clave | 26. Activos fijos | 03, 35, 38 | 8 |
| 44 | `asset-create-operation-lifecycle` | Alta de activo: respuesta tardía tras navegación conserva intención y permite regreso/retry manual | 26. Activos fijos | 35, 38 | 10 |
| 45 | `asset-create-operation-native-restart` | Alta de activo: reinicio físico del binario/perfil separado recupera cuerpo/clave exactos sin autoenvío | 26. Activos fijos | 35, 38 | 5 |
| 46 | `asset-create-operation-receipts` | Alta de activo: recibo completo, cuerpo/clave fijos, parcial/caché/cola/409 y recarga sin autoenvío | 26. Activos fijos | 03, 34, 35, 38 | 40 |
| 47 | `asset-create-operation-roles` | Alta de activo: dos lectores reales no ven/envían la intención privada OWNER y regreso con mismos datos | 26. Activos fijos | 03, 35, 38 | 12 |
| 48 | `asset-create-operation-storage` | Alta de activo: archivo de solicitud/recibo antes del retiro, cuota/corrupción y recuperación manual | 26. Activos fijos | 35, 38 | 14 |
| 49 | `asset-current-real-create-ack-recovery` | Alta real de activo y recuperación del recibo original | 26. Activos fijos | 35, 38 | 2 |
| 50 | `asset-current-real-depreciate-ack-recovery` | Depreciación real del lote y recuperación sin duplicar cuotas | 26. Activos fijos | 35, 38 | 2 |
| 51 | `asset-current-real-retire-ack-recovery` | Baja real de activo y recuperación del asiento confirmado | 26. Activos fijos | 15, 35, 38 | 2 |
| 52 | `asset-current-real-sale-ack-recovery` | Venta real de activo y recuperación del asiento confirmado | 26. Activos fijos | 15, 35, 38 | 2 |
| 53 | `asset-current-real-update-ack-recovery` | Edición real de activo y recuperación del recibo original | 26. Activos fijos | 35, 38 | 2 |
| 54 | `asset-depreciation-original-batch-physical-restart` | Lote original de depreciación recuperado tras reinicio físico Windows | 26. Activos fijos | 35, 38 | 3 |
| 55 | `asset-depreciation-original-batch-receipt-recovery` | Lote original de depreciación: recibos íntegros y recuperación durable | 26. Activos fijos | 03, 34, 35, 38 | 62 |
| 56 | `asset-depreciation-original-batch-roles-context-concurrency` | Lote de depreciación: aislamiento, país y concurrencia | 26. Activos fijos | 03, 35, 38 | 34 |
| 57 | `asset-lifecycle-original-physical-restart` | Edición y baja recuperadas tras reinicio físico Windows | 26. Activos fijos | 35, 38 | 6 |
| 58 | `asset-lifecycle-original-roles-country-concurrency` | Activos: roles, país, respuestas tardías y concurrencia | 26. Activos fijos | 03, 35, 38 | 72 |
| 59 | `asset-original-current-two-real-windows` | Bloqueo entre dos ventanas Windows y recuperación manual bidireccional de dos originales reales | 26. Activos fijos | 35, 38 | 4 |
| 60 | `asset-register-live-read-integrity` | Campos monetarios/fechas, empresa, nombre e identidad únicos antes de mostrar registro | 26. Activos fijos | 03, 35, 38 | 42 |
| 61 | `asset-register-live-read-recovery` | Activos y centros rechazan cache/cola/flags e incompletitud; recuperación manual | 26. Activos fijos | 35, 38 | 58 |
| 62 | `asset-register-live-read-roles` | OWNER/lector y empresa2 desde UI; activos y cronograma existentes exactos | 26. Activos fijos | 03, 35 | 12 |
| 63 | `asset-retire-original-receipt-recovery` | Baja de activo: original y asiento confirmado recuperables | 26. Activos fijos | 03, 15, 34, 35, 38 | 78 |
| 64 | `asset-sale-original-confirmed-journal-receipt` | Venta de activo: recibo original con asiento completo | 26. Activos fijos | 03, 35, 38 | 56 |
| 65 | `asset-schedule-late-form-recovery` | Respuesta tardía conserva formularios de edición y retiro sin guardar | 26. Activos fijos | 34, 35, 38 | 6 |
| 66 | `asset-schedule-live-read-recovery` | Cronograma vivo completo, recuperación y última selección de activo | 26. Activos fijos | 35, 38 | 44 |
| 67 | `asset-schedule-register-regression-recovery` | Regresión de activos/centros rechaza lecturas no vivas e incompletas | 26. Activos fijos | 35, 38 | 58 |
| 68 | `asset-schedule-register-regression-roles` | Lector/OWNER/segunda empresa y cronogramas históricos exactos | 26. Activos fijos | 03, 35 | 12 |
| 69 | `asset-update-original-receipt-recovery` | Edición de activo: original y recibo íntegro recuperables | 26. Activos fijos | 03, 34, 35, 38 | 62 |
| 70 | `asset-writer-controls-form-regression` | Regresión de respuesta tardía sobre formularios sin guardar | 26. Activos fijos | 34, 35, 38 | 6 |
| 71 | `asset-writer-controls-recovery` | Alta/edición/depreciación/baja sólo con su permiso; lector conserva consulta y no ve formularios OWNER | 26. Activos fijos | 03, 34, 35, 38 | 28 |
| 72 | `asset-writer-controls-register-regression` | Regresión de activos/centros vivos completos antes de operar | 26. Activos fijos | 35, 38 | 58 |
| 73 | `asset-writer-controls-schedule-regression` | Regresión de cronograma íntegro, vivo, recuperación y selección tardía | 26. Activos fijos | 35, 38 | 44 |
| 74 | `assets-lifecycle-estimate-current` | Alta/retry, edición, cronograma, depreciación/residual, repetición, cambio de estimación y baja/venta | 26. Activos fijos | 35, 38 | 14 |
| 75 | `assets-read-period-recovery-current` | Error/reintento de activos y centros; creación explícita de junio con503 sin falso éxito | 26. Activos fijos | 35, 38 | 3 |
| 76 | `audit-filter-pagination-detail-current` | Error/reintento, paginación, filtro de pedidos, búsqueda, detalle y fechas Lima; denegación vendedor | 37. Auditoría, notificaciones y ayuda | 03, 35, 38 | 8 |
| 77 | `audit-operation-actor-concurrent-filters` | Filtrar INSERT/UPDATE/DELETE y actor; recuperar catálogo de usuarios503 y descartar respuesta tardía | 37. Auditoría, notificaciones y ayuda | 03, 35, 38 | 7 |
| 78 | `audit-pagination-error-incomplete-recovery` | Páginas1/2 reales de logins,503 de segunda página y retry; aviso de fuentes incompletas y recuperación | 37. Auditoría, notificaciones y ayuda | 35, 38 | 5 |
| 79 | `audit-same-browser-company-isolation` | Cerrar sesión, acceder a empresa2 y volver a principal en el mismo navegador; historial y actores aislados | 37. Auditoría, notificaciones y ayuda | 03, 35 | 5 |
| 80 | `audited-current-accounting-downloads` | Excel PDF y cinco PLE de octubre tras delta auditado | 31. Libros, estados financieros y reportes operativos | 03, 35 | 22 |
| 81 | `audited-current-five-finance-reports` | Cinco reportes financieros actuales con SQL y fallos recuperables | 31. Libros, estados financieros y reportes operativos | 35, 38 | 70 |
| 82 | `audited-current-tax-saved-versions` | Consultas tributarias actuales con ajustes guardados y ejercicio2026 explícito | 32. Impuestos y SIRE | 35, 38 | 30 |
| 83 | `audited-current-ten-accounting-views` | Diez vistas contables actuales con rechazo de lectura incompleta | 31. Libros, estados financieros y reportes operativos | 15, 34, 35, 38 | 60 |
| 84 | `audited-october-accounting-statements-current-read` | Cinco estados financieros actuales tras delta auditado y balance35cuentas igual a SQL | 31. Libros, estados financieros y reportes operativos | 35 | 12 |
| 85 | `bank-capital` | Registrar capital bancario50000 y recargar | 21. Bancos y conciliación | 35 | 2 |
| 86 | `bank-csv-date-contract` | Registrar capital13.17/comisión3.17 de agosto; corregir fecha CSV imposible, importar formatos publicados, recuperarACK, conciliar y cerrar | 21. Bancos y conciliación | 31, 35, 38 | 6 |
| 87 | `bank-current-transfer-real` | Transferencia bancaria con ACK perdido: mismo intento, dos movimientos y un GL | 21. Bancos y conciliación | 35, 38 | 1 |
| 88 | `bank-ended-period` | Capital, comisión, CSV, match y cierre efectivo de septiembre; rechazo de movimiento posterior | 21. Bancos y conciliación | 31, 35, 38 | 4 |
| 89 | `bank-manual-adjust-close` | Capital20, ajuste cargo1, importación, conciliación manual exacta y cierre julio19 | 21. Bancos y conciliación | 35, 38 | 10 |
| 90 | `bank-reconciliation-current` | Importar17movimientos CSV con campos entre comillas, conciliarlos automáticamente y rechazar cierre anticipado | 21. Bancos y conciliación | 31, 35 | 5 |
| 91 | `branch-current-full-crud-assign-real` | Sucursal: alta, edición, baja y asignación recuperan sus originales tras ACK perdido | 04. Identidad, parámetros, sucursales y series | 35, 38 | 4 |
| 92 | `branch-pos-current` | Venta efectivo47.20 por cajeraArequipa; vuelto2.80, boleta B0021 y cierre físico147.20 | 11. Punto de venta | 15, 31, 35 | 6 |
| 93 | `branch-restrictions-current` | Asignar cajera sóloArequipa y almacenero sóloLima; recargar y operar sucursal restringida | 03. Usuarios, roles, permisos y sesiones | 35 | 5 |
| 94 | `branches` | Crear sucursal Arequipa y recargar | 04. Identidad, parámetros, sucursales y series | 35 | 2 |
| 95 | `browser-offline-queue-owner` | Encolar edición independiente de cliente; lector de misma empresa no ve ni sincroniza ni elimina; ADMIN recupera mismo ID, sincroniza y recarga | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 5 |
| 96 | `budget-alert-scope-capture` | Alertas: período real, cantidad activa y estados de ausencia diferenciados | 25. Centros de costo, presupuestos y alertas | 35, 38 | 12 |
| 97 | `budget-alert-scope-lifecycle` | Alertas: refresco, respuesta tardía y recuperación manual del alcance | 25. Centros de costo, presupuestos y alertas | 35, 38 | 12 |
| 98 | `budget-alert-scope-receipts` | Alertas: recibo de alcance, filtros vacíos y rechazo de fuentes inciertas | 25. Centros de costo, presupuestos y alertas | 03, 34, 35, 38 | 44 |
| 99 | `budget-alert-scope-restart` | Alertas: reinicio limpio recupera consultas con alcance actual | 25. Centros de costo, presupuestos y alertas | 35, 38 | 12 |
| 100 | `budget-alert-scope-roles` | Alertas: lectores403 y empresa secundaria sin período, sin falsa normalidad | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 10 |
| 101 | `budget-create-operation-lifecycle` | Alta presupuesto: intención privada, recarga/Volver/red/tardías sin autoenvío | 25. Centros de costo, presupuestos y alertas | 35, 38 | 14 |
| 102 | `budget-create-operation-real-restart` | Alta única3.17 y recibo original recuperado tras reinicio real | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 5 |
| 103 | `budget-create-operation-receipts` | Alta presupuesto: recibo completo/actor/importe/clave sin falso éxito | 25. Centros de costo, presupuestos y alertas | 03, 31, 35, 38 | 42 |
| 104 | `budget-create-operation-roles` | Alta presupuesto: lectores reales no ven ni envían intenciónOWNER | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 10 |
| 105 | `budget-create-operation-storage` | Alta presupuesto: fallas, corrupción y bytes concurrentes conservados | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 20 |
| 106 | `budget-delete-cross-window` | Dos pestañas: intención pendiente conservada ante estado desactualizado | 25. Centros de costo, presupuestos y alertas | 35, 38 | 9 |
| 107 | `budget-delete-lock-regression-inflight` | Baja con bloqueo: Respuesta tardía y segundo envío en curso | 25. Centros de costo, presupuestos y alertas | 35, 38 | 14 |
| 108 | `budget-delete-lock-regression-lifecycle` | Baja con bloqueo: Recarga y navegación conservan intención | 25. Centros de costo, presupuestos y alertas | 35, 38 | 14 |
| 109 | `budget-delete-lock-regression-reads` | Baja con bloqueo: Fotografía viva e íntegra antes de enviar | 25. Centros de costo, presupuestos y alertas | 35, 38 | 18 |
| 110 | `budget-delete-lock-regression-receipts` | Baja con bloqueo: Recibos completos y rechazo de confirmaciones ajenas | 25. Centros de costo, presupuestos y alertas | 03, 31, 34, 35, 38 | 64 |
| 111 | `budget-delete-lock-regression-roles` | Baja con bloqueo: Permisos del lector y regreso del propietario | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 14 |
| 112 | `budget-delete-lock-regression-storage` | Baja con bloqueo: Fallos y corrupción del almacenamiento | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 18 |
| 113 | `budget-delete-lock-restart` | Reinicio del escritorio separado con intención pendiente | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 10 |
| 114 | `budget-delete-operation-inflight` | Baja recuperable: inflight | 25. Centros de costo, presupuestos y alertas | 35, 38 | 14 |
| 115 | `budget-delete-operation-isolated-restart` | Reinicio físico de sesión separada con baja fixture pendiente | 25. Centros de costo, presupuestos y alertas | 03, 34, 35, 38 | 10 |
| 116 | `budget-delete-operation-lifecycle` | Baja recuperable: lifecycle | 25. Centros de costo, presupuestos y alertas | 35, 38 | 14 |
| 117 | `budget-delete-operation-reads` | Baja recuperable: reads | 25. Centros de costo, presupuestos y alertas | 35, 38 | 18 |
| 118 | `budget-delete-operation-real` | Presupuesto nuevo0.11: alta ybaja únicas, respuesta perdida yreplay trasreinicio | 25. Centros de costo, presupuestos y alertas | 35, 38 | 6 |
| 119 | `budget-delete-operation-receipts` | Baja recuperable: receipts | 25. Centros de costo, presupuestos y alertas | 03, 31, 34, 35, 38 | 64 |
| 120 | `budget-delete-operation-roles` | Baja recuperable: roles | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 14 |
| 121 | `budget-delete-operation-storage` | Baja recuperable: storage | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 18 |
| 122 | `budget-delete-simultaneous-interleaving` | Dos pestañas: lectura simultánea no reemplaza la intención | 25. Centros de costo, presupuestos y alertas | 35, 38 | 12 |
| 123 | `budget-delete-simultaneous-lock` | Baja: bloqueo exclusivo y fallos al adquirirlo | 25. Centros de costo, presupuestos y alertas | 35, 38 | 18 |
| 124 | `budget-execution-pagination-errors` | Presupuesto: fallo de página no confirma subtotal y recuperación manual | 25. Centros de costo, presupuestos y alertas | 35, 38 | 6 |
| 125 | `budget-execution-pagination-live` | Presupuesto: ejecución completa con conteo real y páginas ordenadas | 25. Centros de costo, presupuestos y alertas | 35, 38 | 8 |
| 126 | `budget-execution-pagination-roles` | Presupuesto: ejecución sólo con permiso y alcance vivo del propietario | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 8 |
| 127 | `budget-live-execution-view-detail-errors` | Detalle: lectura fallida bloquea formulario y conserva fotografía | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 24 |
| 128 | `budget-live-execution-view-errors` | Lista: lectura fallida, incompleta o caché retira métricas | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 24 |
| 129 | `budget-live-execution-view-lifecycle` | Respuesta de lista tardía no reemplaza detalle | 25. Centros de costo, presupuestos y alertas | 35, 38 | 4 |
| 130 | `budget-live-execution-view-live` | Lista/detalle actuales36.35 conservan fotografía original de edición | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 10 |
| 131 | `budget-live-execution-view-roles` | Lectores denegados sin métricas y propietario recupera vista | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 8 |
| 132 | `budget-live-execution-view-snapshot` | Edición interceptada conserva fotografía raw0 e intención privada | 25. Centros de costo, presupuestos y alertas | 35, 38 | 8 |
| 133 | `budget-live-read-controls-catalogs` | Presupuestos: catálogos íntegros de empresa conservan formulario y bloquean guardado incompleto | 25. Centros de costo, presupuestos y alertas | 35, 38 | 32 |
| 134 | `budget-live-read-controls-lifecycle` | Presupuestos: refresco retira resultados y respuesta tardía no restaura la vista | 25. Centros de costo, presupuestos y alertas | 31, 35, 38 | 20 |
| 135 | `budget-live-read-controls-positive` | Presupuestos: umbrales90/95/100/101 con fixtures coherentes y presupuesto real intacto | 25. Centros de costo, presupuestos y alertas | 35, 38 | 12 |
| 136 | `budget-live-read-controls-reads` | Presupuestos: lista, alertas, comparación y detalle completos y vivos | 25. Centros de costo, presupuestos y alertas | 03, 31, 35, 38 | 120 |
| 137 | `budget-live-read-controls-restart` | Presupuestos: reinicio limpio real conserva perfil y recupera consultas actuales | 25. Centros de costo, presupuestos y alertas | 35, 38 | 10 |
| 138 | `budget-live-read-controls-roles` | Presupuestos: lectores reales403, empresa secundaria vacía y detalle ajeno404 | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 24 |
| 139 | `budget-period-calendar-window-errors` | Presupuesto: calendario503 retira alcance y recuperación manual | 25. Centros de costo, presupuestos y alertas | 35, 38 | 6 |
| 140 | `budget-period-calendar-window-live` | Presupuesto: mes civil de empresa y consultas reales por período | 25. Centros de costo, presupuestos y alertas | 35, 38 | 8 |
| 141 | `budget-period-calendar-window-roles` | Presupuesto: lectores403 y restauración del alcance del propietario | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 8 |
| 142 | `budget-positive-execution-errors` | Mayo: error no confirma cero ni conserva alerta anterior | 25. Centros de costo, presupuestos y alertas | 35, 38 | 6 |
| 143 | `budget-positive-execution-lifecycle` | Alta mayo: recarga y respuesta tardía conservan intención | 25. Centros de costo, presupuestos y alertas | 35, 38 | 14 |
| 144 | `budget-positive-execution-live` | Mayo: gasto histórico36.35 y sobregiro real0.35; lista pendiente | 25. Centros de costo, presupuestos y alertas | 35, 38 | 10 |
| 145 | `budget-positive-execution-real-create` | Alta real mayo36.00 una sola vez con gasto histórico existente | 25. Centros de costo, presupuestos y alertas | 35, 38, 39 | 3 |
| 146 | `budget-positive-execution-receipts` | Alta mayo: recibos completos y errores interceptados | 25. Centros de costo, presupuestos y alertas | 03, 31, 35, 38 | 42 |
| 147 | `budget-positive-execution-report-roles` | Mayo: lectores403 y recuperación del propietario | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 8 |
| 148 | `budget-positive-execution-roles` | Alta mayo: intención privada del propietario | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 10 |
| 149 | `budget-positive-execution-storage` | Alta mayo: persistencia comprobada antes de enviar y retirar | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 20 |
| 150 | `budget-reversal-net-errors` | Presupuesto de gasto: lectura fallida no confirma neto ni cero | 25. Centros de costo, presupuestos y alertas | 35, 38 | 6 |
| 151 | `budget-reversal-net-live` | Presupuesto de gasto: neto confirmado con suelo cero y período vivo | 25. Centros de costo, presupuestos y alertas | 15, 35, 38 | 8 |
| 152 | `budget-reversal-net-roles` | Presupuesto de gasto: lectores403 y alcance restaurado del propietario | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 8 |
| 153 | `budget-update-conflict-recovery-conflicts` | Edición409: conserva intención ante errores y recibos incompletos | 25. Centros de costo, presupuestos y alertas | 03, 34, 35, 38 | 24 |
| 154 | `budget-update-conflict-recovery-restart` | Reinicio real tras cierre manual: recupera cuerpo y clave sin autoenvío | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 8 |
| 155 | `budget-update-operation-lifecycle` | Edición presupuesto: recarga, Volver, red y respuestas tardías conservan cambios | 25. Centros de costo, presupuestos y alertas | 35, 38 | 14 |
| 156 | `budget-update-operation-real-restart` | Edición única3.17→3.29 y recibo original recuperado después de reinicio real | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 5 |
| 157 | `budget-update-operation-receipts` | Edición presupuesto: recibo completo, fotografía e identidad;409 sin falso éxito | 25. Centros de costo, presupuestos y alertas | 03, 31, 35, 38 | 44 |
| 158 | `budget-update-operation-roles` | Edición presupuesto: lectores403 sin intención del OWNER | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 10 |
| 159 | `budget-update-operation-storage` | Edición presupuesto: fallas, corrupción y bytes concurrentes conservados | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 20 |
| 160 | `budget-update-resolution-committed` | Edición409: conciliación del recibo original ya confirmado | 25. Centros de costo, presupuestos y alertas | 15, 35, 38 | 6 |
| 161 | `budget-update-resolution-late` | Resolución: respuesta tardía tras navegación conserva intención | 25. Centros de costo, presupuestos y alertas | 34, 35, 38 | 10 |
| 162 | `budget-update-resolution-resolutions` | Edición409: abandono autorizado, contratos negativos y almacenamiento | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 44 |
| 163 | `budget-update-resolution-restart` | Resolución: reinicio físico de la sesión Windows separada con intención exacta | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 6 |
| 164 | `budget-update-resolution-roles` | Resolución: dos lectores reales y regreso del propietario | 25. Centros de costo, presupuestos y alertas | 03, 35, 38 | 12 |
| 165 | `cash-chica-reversal-control-inventory` | Caja chica y reversa sin controlUI localizado; historial cerrado conserva sólo lectura | 12. Cajas, arqueos, turnos y cortes | 03, 35 | 2 |
| 166 | `cash-concurrent-manual-incomes` | Dos ingresos1 simultáneos con claves distintas y saldos seriados100→101→102 | 12. Cajas, arqueos, turnos y cortes | 35 | 1 |
| 167 | `cash-concurrent-open-one-session` | Dos aperturas desdeUI liberadas simultáneamente:201/400 y una sola sesión100 | 12. Cajas, arqueos, turnos y cortes | 03, 35 | 1 |
| 168 | `cash-current-register-edit-real` | Editar caja sin sesión y conservar nombre y descripción tras recarga | 12. Cajas, arqueos, turnos y cortes | 03, 35 | 1 |
| 169 | `cash-cut-export-types-recovery` | PDF/CSV reales;503/red/JSON/MIME erróneo/incompleto rechazan descarga y muestran error en página | 12. Cajas, arqueos, turnos y cortes | 31, 35, 38 | 2 |
| 170 | `cash-cut-frozen-rounding-current-exports` | PDF/CSV del mismo cierre: nominal102.52, redondeo0.02, físico102.50, contado82.50 y diferencias20/20.02 | 12. Cajas, arqueos, turnos y cortes | 31, 35 | 6 |
| 171 | `cash-late-query-dialog-session` | Respuestas tardías de sesiones/cortes/cajas/movimientos no reemplazan consulta/diálogo/sesión vigente | 12. Cajas, arqueos, turnos y cortes | 03, 35, 38 | 6 |
| 172 | `cash-live-sessions-movements-cuts-registers` | Cuatro fuentes:503/red/200incompleto/importe inválido retiran datos y acciones; retry real | 12. Cajas, arqueos, turnos y cortes | 35, 38 | 2 |
| 173 | `cash-opening-no-offline-false-success` | Apertura red/503/pending202/200incompleto conserva formulario e intención sin éxito ni cola | 12. Cajas, arqueos, turnos y cortes | 34, 35, 38 | 6 |
| 174 | `cash-registers` | Crear cajas por sucursal/almacén; error de transporte conserva formulario y permite reintentar | 12. Cajas, arqueos, turnos y cortes | 35, 38 | 5 |
| 175 | `cash-role-tenant-isolation` | Dos lectores403, empresa2vacía real y restauraciónOWNER al historial cerrado | 12. Cajas, arqueos, turnos y cortes | 03, 35 | 6 |
| 176 | `cash-shift-manual-supervisor-cut` | Cancelar turno, transferir con arqueo22, ingreso/gasto/retry, depósito3, cierre70/90 con supervisor y exportar corte | 12. Cajas, arqueos, turnos y cortes | 03, 31, 35, 38 | 15 |
| 177 | `cash-shortage20-rounding002-supervised-close` | Arqueo físico82.50 frente102.50; faltante20 más redondeo0.02 requieren supervisor distinto | 12. Cajas, arqueos, turnos y cortes | 35 | 4 |
| 178 | `cash-supplier-accounting-integration137` | PagoEFECTIVO publica unGL D42/H10.10 y cierre sin diferencia otroevento sin asiento | 12. Cajas, arqueos, turnos y cortes | 03, 35, 38 | 6 |
| 179 | `cash-supplier-history-role-tenant-isolation` | Historial realEFECTIVO.10 una vez:OWNER/lectores403/empresa2real404/regresoOWNER sin pagos | 12. Cajas, arqueos, turnos y cortes | 03, 35, 38 | 12 |
| 180 | `cash-supplier-owner-open-exact-close` | OWNER abrePEN100 y cierra99.90 después de pagoEFECTIVO.10, sesión/corte únicos | 12. Cajas, arqueos, turnos y cortes | 03, 35, 38 | 4 |
| 181 | `cash-supplier-payment-negative-regression` | Corte137:18negativos de pago y16almacenamiento/roles siguen preservando intención exacta sincola | 12. Cajas, arqueos, turnos y cortes | 03, 34, 35, 38 | 68 |
| 182 | `cash-supplier-real-payment-ACK-recover` | Nuevo pagoEFECTIVO.10Windows conACK perdido recupera mismo pago/session/evento/movimiento | 12. Cajas, arqueos, turnos y cortes | 03, 34, 35, 38 | 7 |
| 183 | `cash-supplier-real-same-binary-restart` | Pendiente de pago realmente comprometido sobrevive actualización/reinicio real del mismo nuevoWindows | 12. Cajas, arqueos, turnos y cortes | 03, 34, 35, 38, 39 | 6 |
| 184 | `cashflow-real-source-cuentas_bancarias-recovery` | Flujo de caja: fallo503 real de fuente cuentas_bancarias devuelve reporte503, retira proyección/impresión y recupera consulta completa al reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 185 | `cashflow-real-source-cuentas_por_cobrar-recovery` | Flujo de caja: fallo503 real de fuente cuentas_por_cobrar devuelve reporte503, retira proyección/impresión y recupera consulta completa al reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 186 | `cashflow-real-source-cuentas_por_pagar-recovery` | Flujo de caja: fallo503 real de fuente cuentas_por_pagar devuelve reporte503, retira proyección/impresión y recupera consulta completa al reintentar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 187 | `cashflow-source-five-report-regression` | Tras corrección API, repetir cinco reportes completos con red fallida/503/incompletos/retry, filtros, lectores y empresa2 | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 11 |
| 188 | `commercial-atomic-reviewed-price` | Cambiar regla después del preflight real; bloquear alta/edición de cotización y alta de pedido hasta nueva revisión y confirmación | 08. Gestión comercial: precios, comisiones y cotizaciones | 15, 35, 38 | 9 |
| 189 | `commercial-crud-snapshots` | Listas31 y comisión5%, error/retry, activar/desactivar y consolidado30 con ACK perdido | 08. Gestión comercial: precios, comisiones y cotizaciones | 35, 38 | 14 |
| 190 | `commercial-pos-price-retry-close` | Precio31, error/retry, ACK perdido, desactivar lista desde otra pantalla, impresión/PDF y cierre20 | 08. Gestión comercial: precios, comisiones y cotizaciones | 15, 31, 35, 38 | 12 |
| 191 | `commercial-price-order-integration` | Revisar lista31 en cotización/pedido, despachar, facturar, devengar5% y cobrar36.58 | 08. Gestión comercial: precios, comisiones y cotizaciones | 35, 38 | 11 |
| 192 | `commercial-quote-snapshot-ack-recovery` | Enviar/aprobar por actor distinto, convertir con snapshot histórico y recuperar pedido tras ACK perdido | 08. Gestión comercial: precios, comisiones y cotizaciones | 03, 35, 38 | 8 |
| 193 | `company-create` | Crear empresa Perú y acceder como propietario nuevo | 04. Identidad, parámetros, sucursales y series | 03, 35 | 2 |
| 194 | `company-durable-damaged-draft-preserved` | Seis borradores dañados bloquean edición sin reemplazar clave o borrar almacenamiento | 04. Identidad, parámetros, sucursales y series | 35, 38 | 18 |
| 195 | `company-logo-current-storage-real` | Logo: carga, reemplazo y borrado reales con ACK perdido y recarga | 04. Identidad, parámetros, sucursales y series | 35, 38 | 1 |
| 196 | `company-optional-clear-normalized-real` | Vaciado real de tres campos opcionales: teléfono/correoNULL y nombre comercial restablecido al registrado | 04. Identidad, parámetros, sucursales y series | 35, 38 | 2 |
| 197 | `company-optional-restore-original-real` | Restauración real200 de campos opcionales y recarga de cinco valores originales | 04. Identidad, parámetros, sucursales y series | 03, 35 | 2 |
| 198 | `company-original-lost-ack-recovery-no-duplicate` | Intención real original recuperada200 con la misma clave/cuerpo después de actualizar binario | 04. Identidad, parámetros, sucursales y series | 31, 35, 38 | 3 |
| 199 | `company-owner-pending-real-role-tenant-isolation` | Lector sin editor y empresa2 con perfil propio no exponen pendiente deOWNER; regreso recupera borrador | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 14 |
| 200 | `company-post-onboarding-edit` | Editar razón social, nombre comercial, dirección, teléfono y correo; validar, cancelar, recuperar ACK perdido con misma clave, recargar y restaurar valores | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 6 |
| 201 | `company-save-strict-live-receipt-and-required` | Guardado sin confirmación completa conserva borrador/clave; razón y dirección vacías bloquean writer | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 56 |
| 202 | `configurable-report-retry-cut` | Guardar definición tras ACK perdido y generar reporte individual; cambiar corte descarta resultado anterior | 30. Consolidación y reportes configurables | 35, 38 | 5 |
| 203 | `configuration-logo-invalid-input` | Logo: formato/tamaño bloqueados sin solicitud, binarioPNG falso400 yreintento habilitado conconfiguración preservada | 04. Identidad, parámetros, sucursales y series | 35, 38 | 4 |
| 204 | `configuration-read-errors-isolation` | Consultar identidad/resumen/ventas, fallos503 de estado/empresa/OSE yretry real, cambiar empresa yrecargar | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 10 |
| 205 | `configuration-readonly-optional-rrhh` | Empresa, Resumen y Ventas con permiso de lectura; RRHH no evaluado, logo válido403 y recarga original | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 5 |
| 206 | `configuration-readonly-role-identity` | Crear rol con un único permiso de Configuración, asignarlo a usuario propio y recargar | 03. Usuarios, roles, permisos y sesiones | 35 | 2 |
| 207 | `consignment-current-fresh-original-recovery` | Entrega en consignación: recuperar original y distinguir nueva entrega idéntica tras éxito | 28. Consignaciones | 35, 38 | 2 |
| 208 | `consignment-live-read-complete` | Consignaciones: registro y catálogo íntegros en vivo; negativos/recuperación | 28. Consignaciones | 03, 35, 38 | 96 |
| 209 | `consignment-live-read-currencies-destinations` | Consignaciones: PEN/USD separados y destinos válidos sin transiciones enviadas | 28. Consignaciones | 35, 38 | 8 |
| 210 | `consignment-live-read-lifecycle` | Borrador preservado ante fuente503 y lectura tardía bajo filtro distinto | 28. Consignaciones | 35, 38 | 12 |
| 211 | `consignment-live-read-restart` | Reinicio físico del lector Windows separado, sin writer automático | 28. Consignaciones | 03, 35, 38 | 6 |
| 212 | `consignment-live-read-roles` | Dos lectores reales sin controles de alta/transición; retorno OWNER | 28. Consignaciones | 03, 35, 38 | 10 |
| 213 | `consignments-atomic-reader` | Recuperar registro y productos tras lectura503 antes de habilitar consignaciones | 28. Consignaciones | 35, 38 | 1 |
| 214 | `consignments-complete-cycle` | Alta fraccionaria, ACK/retry, nueva entrega idéntica, venta/cierre, devolución terminal y anulación | 28. Consignaciones | 35, 38 | 6 |
| 215 | `consolidation-atomic-reader` | Lectura503 de grupos/definiciones bloquea operaciones y generación hasta recuperar ambos catálogos | 30. Consolidación y reportes configurables | 35, 38 | 1 |
| 216 | `consolidation-cent-precision` | Rechazar0.019 antes de escribir y registrar centavo0.01 desdeUI tras corrección | 30. Consolidación y reportes configurables | 35, 38 | 2 |
| 217 | `consolidation-current-fresh-two-members-report` | Consolidación real: invitación aceptada en otra sesión, tasas y resultado125USD de dos empresas | 30. Consolidación y reportes configurables | 03, 35 | 3 |
| 218 | `consolidation-designer-date-natures` | Diseñar saldo acumulado, movimiento del período y fórmula; rechazar ciclo/conflicto; generar con tasasCIERRE/HISTORICA | 30. Consolidación y reportes configurables | 35, 38 | 7 |
| 219 | `consolidation-financial-read-isolation` | Consolidación: secundaria real sin definición financiera ajena ni generación de controladora | 30. Consolidación y reportes configurables | 03, 35, 38 | 8 |
| 220 | `consolidation-financial-read-lifecycle` | Consolidación: retiro del resultado pendiente y respuestas anteriores descartadas tras cambiar fechas o pantalla | 30. Consolidación y reportes configurables | 35, 38 | 14 |
| 221 | `consolidation-financial-read-reads` | Consolidación: resultado financiero completo, importes/desgloses/fórmulas/tasas; individual y ambos grupos existentes en lectura real | 30. Consolidación y reportes configurables | 03, 35, 38 | 82 |
| 222 | `consolidation-financial-read-restart` | Consolidación: escritorio separado reinicia físicamente y confirma resultado positivo por lectura, sin writer automático | 30. Consolidación y reportes configurables | 35, 38 | 6 |
| 223 | `consolidation-financial-read-roles` | Consolidación: lector contable real consulta y lector genérico sin permiso queda bloqueado; retorno OWNER | 30. Consolidación y reportes configurables | 03, 35, 38 | 10 |
| 224 | `consolidation-live-read-isolation` | Consolidación: empresa secundaria real, membresía vigente sin definiciones ajenas ni escritores de controladora | 30. Consolidación y reportes configurables | 03, 35, 38 | 10 |
| 225 | `consolidation-live-read-lifecycle` | Consolidación: borrador no enviado ante503, recuperación y catálogo de pantalla anterior descartado | 30. Consolidación y reportes configurables | 35, 38 | 12 |
| 226 | `consolidation-live-read-reads` | Consolidación: catálogos completos en vivo de grupos/membresías/empresas/definiciones/líneas | 30. Consolidación y reportes configurables | 03, 35, 38 | 114 |
| 227 | `consolidation-live-read-restart` | Consolidación: reinicio físico del escritorio separado, sin writer automático | 30. Consolidación y reportes configurables | 35, 38 | 6 |
| 228 | `consolidation-live-read-roles` | Consolidación: dos lectores reales sin alta de grupo/definición; retorno OWNER | 30. Consolidación y reportes configurables | 03, 35, 38 | 10 |
| 229 | `consolidation-map-adjustments` | Homologar cuenta75→70, eliminar/reclasificar y repetir intención tras ACK perdido | 30. Consolidación y reportes configurables | 35, 38 | 5 |
| 230 | `consolidation-membership-cycle` | Recuperar alta de grupo, invitar/aceptar empresa80% y rechazar invitación40% en otro grupo | 30. Consolidación y reportes configurables | 35, 38 | 6 |
| 231 | `consolidation-presentation-rates-intents` | Exigir tasas explícitas de ambos miembros y actualizar factor A→B→A con nueva intención | 30. Consolidación y reportes configurables | 03, 35, 38 | 5 |
| 232 | `country-context-complete-payload` | Contexto fiscal incompleto/ajeno no inventa país, moneda ni tasa y recupera por UI | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 16 |
| 233 | `country-context-confirmed-absence` | Sólo ausencia fiscal explícita válida conduce al asistente, sin inventar PE | 02. Primer acceso y preparación de la empresa | 35, 38 | 6 |
| 234 | `country-context-http-recovery-current` | Conservar error/reintento/ruta/salir ante403/429/503 con nuevo contrato fiscal | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 12 |
| 235 | `country-context-live-roles` | Resolver país de empresa/actor actuales al cambiar roles y empresa | 04. Identidad, parámetros, sucursales y series | 03, 35 | 10 |
| 236 | `cpe-a4-actual-pdf-visual-qa` | Descargar el PDF A4 real y revisar cada render original porinterfaz | 15. Comprobantes electrónicos y ciclo fiscal | 17, 35, 38 | 2 |
| 237 | `cpe-a4-close-roles-tenant-isolation` | Cerrar lecturas en curso, reabrir otro/mismoCPE y negar A4 al lector o empresa distinta | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 35, 38 | 16 |
| 238 | `cpe-a4-existing21-schema-compatibility` | Abrir A4 de los21CPE existentes, con esquemas de detalle de factura y nota anteriores | 15. Comprobantes electrónicos y ciclo fiscal | 35 | 44 |
| 239 | `cpe-a4-live-complete-manual-retry` | Vista A4: lecturas completas en vivo, error/retry y descarga bloqueada ante metadatos/PDF inválidos | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 35, 38 | 70 |
| 240 | `cpe-contado-manual-link-collection` | Vincular receptor manual a cliente coincidente; recuperar respuesta perdida y cobrar desdeUI | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 5 |
| 241 | `cpe-contado-master-collection` | Crear CPE con cliente maestro, abrir cobranza desdeCPE, cobrar y recargar | 15. Comprobantes electrónicos y ciclo fiscal | 17, 35 | 4 |
| 242 | `cpe-contado-paid-retry` | Emisión nueva al contado con vencimiento inmediato, ACK perdido, cobro y reintento del mismo formulario | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 4 |
| 243 | `cpe-creation-actor-late-denial` | Intención OWNER y respuesta negativa demorada: lectores403, empresa secundaria vacía y regreso al propietario | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 5 |
| 244 | `cpe-creation-cut133-reports-ple-tax` | Corte133: cinco estados, cinco PLE, seis Excel/seis PDF y cálculos tributarios actuales con recuperación | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 34, 35, 38 | 67 |
| 245 | `cpe-creation-damaged-draft-blocks-writer` | Borradores locales dañados: JSON, versión, cliente, clave, fecha, moneda o líneas incoherentes bloquean emisión y conservan evidencia | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 24 |
| 246 | `cpe-creation-draft-manual-date-recovery` | Alta directa: borrador sin enviar y emisión incierta conservan cliente, líneas, fecha manual y cuerpo tras cierre/recarga | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 24 |
| 247 | `cpe-creation-input-rejection-correctable` | Cantidad0 rechazada realmente antes de numeración permite corregir conservando borrador y fecha manual | 15. Comprobantes electrónicos y ciclo fiscal | 03, 34, 35, 38 | 30 |
| 248 | `cpe-creation-input-rejection-damaged-draft` | Diez borradores dañados bloquean emisión y conservan contenido; borrador negativo válido restaura intención | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 24 |
| 249 | `cpe-creation-input-rejection-exact-status` | 400genérico/red/503/403/200contradictorios/caché/incompletos conservan intención de emisión | 15. Comprobantes electrónicos y ciclo fiscal | 03, 34, 35, 38 | 30 |
| 250 | `cpe-creation-input-rejection-native-sessions-restart` | OWNER conserva intento tras abandonar modal, lectores403/empresa2vacía y reinicio mismo binario/perfil | 15. Comprobantes electrónicos y ciclo fiscal | 03, 34, 35, 38 | 12 |
| 251 | `cpe-creation-input-rejection-read-a4-regression` | Regresión46pasos de lecturas y24A4 reales tras alta corregible | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 142 |
| 252 | `cpe-creation-invalid-receipts-retain-real-intent` | Dieciséis respuestas incompletas, offline, cacheadas o incoherentes no confirman la emisión real pendiente | 15. Comprobantes electrónicos y ciclo fiscal | 34, 35, 38 | 19 |
| 253 | `cpe-creation-real-lost-ack-native-restart` | F001-00000014/PEN1.18: una emisión con fecha8oct, ACK perdido y recuperación real201 después de reiniciar mismo binario/perfil | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 14 |
| 254 | `cpe-export-inafect-collection` | Exportación de bienes a pasaporte e inafecta: emitir, PDF, cobrar y recargar | 15. Comprobantes electrónicos y ciclo fiscal | 17, 35, 38 | 10 |
| 255 | `cpe-financial-cut132-statements-ple-exports` | Corte132: cinco estados, cinco PLE y Excel/PDF descargados en web y Windows | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 35 | 33 |
| 256 | `cpe-financial-draft-tax-cut132-recovery` | NC BORRADOR excluida de ventas: impuestos actualizados, fallos/retry/período/tardías y versiones guardadas preservadas | 15. Comprobantes electrónicos y ciclo fiscal | 34, 35, 38 | 38 |
| 257 | `cpe-financial-preview-select-stale-recovery` | Consulta financiera real con cobro: SELECT backend, fallo de refresco y datos incompletos sin writer anterior | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 8 |
| 258 | `cpe-financial-request-actor-late-denial` | Intento OWNER y POST negativo demorado: lectores403, empresa2vacía y regreso alOWNER sin exponer estado privado | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 5 |
| 259 | `cpe-financial-request-negative-confirmation-intent` | Solicitud NC: error/red/vacío/offline/caché/403 e identidad/fingerprint inválidos no confirman; cierre/recarga conservan intención | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 35, 38 | 33 |
| 260 | `cpe-financial-request-real-lost-ack-restart` | Una solicitud NC FC00-00000001: ACK perdido, mismo binario/perfil reiniciado y recuperación real con misma clave/cuerpo | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 3 |
| 261 | `cpe-financial-writer-new-target` | Factura nueva F001-00000013/PEN1.18 a crédito, creada una sola vez para recuperar solicitud NC | 15. Comprobantes electrónicos y ciclo fiscal | 35 | 3 |
| 262 | `cpe-historical-current-read-filter-export` | Historia CPE MIGRADO: procedencia, sólo lectura, filtro y CSV sin constancia fiscal inventada | 15. Comprobantes electrónicos y ciclo fiscal | 17, 35 | 3 |
| 263 | `cpe-list-download-binary-csv-recovery` | Descargar PDF/CSV completos; rechazar JSON/mime/truncamiento/red/caché y reintentar manualmente | 15. Comprobantes electrónicos y ciclo fiscal | 17, 35, 38 | 30 |
| 264 | `cpe-live-complete-list-stats-recovery` | Listado/indicadores incompletos,403/503/red/caché: retirar desconocidos y recuperar desdeUI | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 92 |
| 265 | `cpe-note-origins-live-incomplete-retry` | Orígenes NC/ND completos en vivo; seis variantes fallidas no anuncian vacío ni habilitan creación | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 44 |
| 266 | `cpe-note-sign-actor-late-denial` | Firma pendiente OWNER aislada al cambiar sesión; lectores403, empresa2 vacía y respuesta negativa demorada | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 5 |
| 267 | `cpe-note-sign-damaged-intent-late-origin` | Siete intenciones dañadas bloquean firma sin sobrescribir evidencia; modal reabierto descarta lecturas negativas antiguas | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 22 |
| 268 | `cpe-note-sign-invalid-replies-same-intent` | Respuestas vacías, pendientes, cacheadas, incoherentes o denegadas conservan la intención de firma | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 57 |
| 269 | `cpe-note-sign-real-lost-ack-native-restart` | Firma única de NC FC00-00000001, pérdida de ACK y recuperación real tras reiniciar el mismo binario/perfil | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 15 |
| 270 | `cpe-note-signed-a4-download-reference` | A4 de NC firmada conserva referencia F00113/base1/IGV0.18/total1.18 y HTML Sin aceptación SUNAT | 15. Comprobantes electrónicos y ciclo fiscal | 17, 34, 35 | 8 |
| 271 | `cpe-note-signed-unissued-tax-cut133` | Firma sin documento emitido no rectifica impuestos; notas emitidas conservan signo y PLE/diario concuerdan | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 34, 35, 38 | 43 |
| 272 | `cpe-read-late-roles-tenant-isolation` | Respuesta anterior no sustituye filtro/CPE ni descarga otro contexto; lectores403 y empresa2 vacía reales | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 35, 38 | 18 |
| 273 | `cpe-send-current-read-and-a4-catalog24` | Regresión de listado/indicadores/consulta financiera y catálogo24A4 reales tras corregir envío | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 142 |
| 274 | `cpe-send-damaged-intent-and-late-modal` | Siete intenciones dañadas bloquean envío y conservan contenido; lectura demorada del modal anterior se descarta | 15. Comprobantes electrónicos y ciclo fiscal | 35, 38 | 22 |
| 275 | `cpe-send-native-roles-restart-negative` | Intención de envío OWNER aislada de lectores403 y empresa2; mismo binario/perfil reiniciado conserva retry manual | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 11 |
| 276 | `cpe-send-negative-complete-receipt-canonical-intent` | Envío Perú: doble clic bloqueado, clave canónica y once respuestas fallidas/incompletas no confirman envío ni aceptación | 15. Comprobantes electrónicos y ciclo fiscal | 03, 35, 38 | 30 |
| 277 | `cpe-send-pdf-no-cdr-explicit` | PDF de NC firmada sinCDR declara Sin aceptación SUNAT · CDR no acreditado y READY técnico | 15. Comprobantes electrónicos y ciclo fiscal | 17, 34, 35 | 8 |
| 278 | `csv-batch-clientes-invalid-files` | Bloquear CSV duplicado/desalineado, UTF-8 inválido, vacío y external_id repetido antes de importar | 05. Clientes, proveedores e importaciones | 31, 35 | 6 |
| 279 | `csv-batch-clientes-partial-retry` | Importar lote parcial, recuperar ACK perdido, corregir conflicto y exportar tras recarga | 05. Clientes, proveedores e importaciones | 31, 35, 38 | 5 |
| 280 | `csv-batch-clientes-permissions-isolation` | Denegar lista/plantilla/preview al lector y separar empresa2 en el mismo navegador | 05. Clientes, proveedores e importaciones | 03, 31, 35, 38 | 4 |
| 281 | `csv-batch-proveedores-invalid-files` | Bloquear CSV duplicado/desalineado, UTF-8 inválido, vacío y external_id repetido antes de importar | 05. Clientes, proveedores e importaciones | 31, 35 | 6 |
| 282 | `csv-batch-proveedores-partial-retry` | Importar lote parcial, recuperar ACK perdido, corregir conflicto y exportar tras recarga | 05. Clientes, proveedores e importaciones | 31, 35, 38 | 5 |
| 283 | `csv-batch-proveedores-permissions-isolation` | Denegar lista/plantilla/preview al lector y separar empresa2 en el mismo navegador | 05. Clientes, proveedores e importaciones | 03, 31, 35, 38 | 4 |
| 284 | `csv-clientes` | Importación CSV real, documento inválido bloqueado, replay sin duplicación y exportación filtrada con comas/saltos de línea | 05. Clientes, proveedores e importaciones | 03, 31, 35, 38 | 14 |
| 285 | `csv-proveedores` | Importación CSV real, documento inválido bloqueado, replay sin duplicación y exportación filtrada con comas/saltos de línea | 05. Clientes, proveedores e importaciones | 20, 31, 35, 38 | 13 |
| 286 | `current-finance-real-roles-isolation-after-cxc-fix` | Roles reales y aislamiento actual de CxC/CxP y cinco reportes financieros | 31. Libros, estados financieros y reportes operativos | 03, 35 | 44 |
| 287 | `current-sales-reports-native-browser-actor-isolation` | Corte19documentos: once reportes nativos conretry; Aging36.58/lector403; navegador principal→empresa2→lector→principal | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 8 |
| 288 | `customer-credit-current` | Saldo a favor58.40: aplicar20 a otra factura23.60; reembolsar38.40, revertir y pagar nuevamente | 10. Devoluciones de clientes, notas y saldo a favor | 15, 35, 38 | 5 |
| 289 | `cxc-adjustment-double-submit-and-retired-callback` | Ajustes CxC bloquean doble submit y callbacks retirados; original en página montada | 18. Cuentas por cobrar y recuperación de cartera | 03, 34, 35, 38, 39 | 88 |
| 290 | `cxc-adjustment-original-durable-recovery` | Ajustes CxC recuperan intención original durable sin depender de lista actual | 18. Cuentas por cobrar y recuperación de cartera | 35, 38, 39 | 88 |
| 291 | `cxc-adjustment-original-real-role-isolation` | Roles reales aíslan ambas intenciones originales de ajuste | 18. Cuentas por cobrar y recuperación de cartera | 03, 35, 38 | 20 |
| 292 | `cxc-adjustment-original-storage-concurrency` | Almacenamiento y concurrencia conservan cuerpo y clave originales de ajustes | 18. Cuentas por cobrar y recuperación de cartera | 35, 38, 39 | 88 |
| 293 | `cxc-adjustment-owned-native-physical-restart` | Reinicio físico Windows conserva ambas solicitudes originales de ajuste | 18. Cuentas por cobrar y recuperación de cartera | 34, 35, 38 | 8 |
| 294 | `cxc-adjustment-real-role-isolation` | Roles reales y empresa secundaria no muestran controles de ajuste ajenos | 18. Cuentas por cobrar y recuperación de cartera | 03, 35, 38 | 12 |
| 295 | `cxc-collection-complete-bank-source` | Fuente bancaria completa y reintento original sin catálogo actual | 18. Cuentas por cobrar y recuperación de cartera | 03, 35, 38 | 46 |
| 296 | `cxc-collection-native-original-physical-restart` | Reinicio físico Windows conserva cuerpo y clave originales del cobro | 18. Cuentas por cobrar y recuperación de cartera | 35, 38 | 4 |
| 297 | `cxc-collection-original-durable-recovery` | Solicitud original durable de cobro: almacenamiento, navegación, recarga y dos pestañas | 18. Cuentas por cobrar y recuperación de cartera | 03, 35, 38 | 38 |
| 298 | `cxc-collection-original-pending-role-isolation` | Aislamiento del pendiente de cobro con roles y empresas reales | 18. Cuentas por cobrar y recuperación de cartera | 03, 35, 38 | 16 |
| 299 | `cxc-collection-receipt-verification-controlled` | Recibos CxC verificados y cobros fuera de cola genérica; sin pagos reales | 18. Cuentas por cobrar y recuperación de cartera | 03, 31, 35, 38 | 68 |
| 300 | `cxc-complete-live-current-list-history` | CxC actual completa en vivo, historial recuperable y paginación sin parcial | 18. Cuentas por cobrar y recuperación de cartera | 03, 31, 35, 38 | 118 |
| 301 | `cxc-credit-note-neutral-original-creation-receipt` | Nota CxC exige recibo original de creación neutral pendiente de aceptación fiscal | 18. Cuentas por cobrar y recuperación de cartera | 03, 15, 34, 35, 38, 39 | 88 |
| 302 | `cxc-current-filtered-csv-currencies` | Filtros y CSV de CxC actuales con monedas nominales separadas | 18. Cuentas por cobrar y recuperación de cartera | 31, 35, 38 | 14 |
| 303 | `cxc-current-read-regression-after-adjustment-receipts` | Regresión CxC actual tras recibos de ajustes: lista completa, historial y CSV | 18. Cuentas por cobrar y recuperación de cartera | 03, 31, 35, 38 | 118 |
| 304 | `cxc-current-read-regression-after-durable-adjustments` | Regresión CxC actual tras ajustes durables: lista,historial yCSV | 18. Cuentas por cobrar y recuperación de cartera | 03, 31, 35, 38 | 118 |
| 305 | `cxc-current-read-regression-after-durable-collection` | Regresión CxC actual de lista completa, historial recuperable y CSV | 18. Cuentas por cobrar y recuperación de cartera | 03, 31, 35, 38 | 118 |
| 306 | `cxc-imported-overdue-current-real-recovery` | Saldo importado vencido: filtro visual y cobro original recuperado sin duplicados | 18. Cuentas por cobrar y recuperación de cartera | 15, 35, 38 | 3 |
| 307 | `cxc-reschedule-correlated-original-receipt` | Reprogramación CxC exige recibo original del ledger y reintento de la misma solicitud | 18. Cuentas por cobrar y recuperación de cartera | 03, 34, 35, 38, 39 | 88 |
| 308 | `cxp-current-browser-csv` | Descargar CSV real de cinco CxP actuales, diez columnas y valores exactos contra PostgreSQL | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35, 38 | 1 |
| 309 | `cxp-current-detail-history-csv-after-audited-delta` | CxP actual CSV20 y detalleUSD4 con dos pagos originales sin repetir | 19. Facturas de proveedor y cuentas por pagar | 31, 35, 38 | 18 |
| 310 | `cxp-detail-actual-role-tenant-isolation` | Lectores403/empresa2real404 retiran detalle/pagos; regresoOWNER conserva dos pagosUSD | 19. Facturas de proveedor y cuentas por pagar | 03, 35 | 8 |
| 311 | `cxp-detail-current-finance-five-regression` | Cinco reportes actuales tras arreglo de detalle: bancoUSD4.20/pagos2+2, lectores403/empresa2vacía y retry | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 34, 35, 38 | 51 |
| 312 | `cxp-detail-history-catalog16` | Recorrer16CxP reales:14facturas y2notas, soles/dólares, saldos y pagos completos iguales en ambasinterfaces | 19. Facturas de proveedor y cuentas por pagar | 03, 35 | 42 |
| 313 | `cxp-detail-late-navigation-read` | Respuesta200 real demorada del documento pagado no sustituye la otra deuda tras navegación | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 2 |
| 314 | `cxp-detail-live-complete-tenant` | Detalle de CxP:17lecturas fallidas o inválidas retiran importes/identidad/controles y retry recupera200 real | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 66 |
| 315 | `cxp-due-section-recovery` | Vencimientos fallidos/incompletos/malformados: error persistente y retry con lista válida conservada | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 6 |
| 316 | `cxp-filters-late-read-recovery` | Estado/proveedor actuales después de retry y fecha vacía real; lectura anterior tardía no restaura filas/CSV | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35, 38 | 3 |
| 317 | `cxp-history-complete-scoped-source-recovery` | Historial CxP completo por empresa/cuenta/moneda con errores y reintento | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 94 |
| 318 | `cxp-history-current20-original-payment-catalog` | Veinte CxP conservan sus pagos originales según SQL readonly | 19. Facturas de proveedor y cuentas por pagar | 03, 35 | 40 |
| 319 | `cxp-history-real-payments-no-false-zero` | Historial de pagos:12fallos/filas inválidas, duplicados y moneda incorrecta ocultan total/tabla hasta retry real | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 66 |
| 320 | `cxp-history-real-role-company-isolation` | Roles y empresa secundaria aíslan historiales de pagos CxP | 19. Facturas de proveedor y cuentas por pagar | 03, 35 | 10 |
| 321 | `cxp-list-current-read-recovery` | Lista CxP completa: 503, 200incompleto/malformado, paginación incompleta y red fallida retiran filas/métricas/CSV; retry real | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35, 38 | 11 |
| 322 | `cxp-overdue-partial-live-receipt` | Recibo parcial realVENCIDA deja confirmar pago con saldo positivo reducido y libera pendiente | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 2 |
| 323 | `cxp-payment-complete-live-receipt` | PagoCxP:400/403/503/red/201vacío/offline/pending/queued/cache y recibo bancario real ajeno no confirman | 19. Facturas de proveedor y cuentas por pagar | 03, 34, 35, 38 | 36 |
| 324 | `cxp-payment-corrupt-storage-blocks` | Nueve cuerpos guardados dañados/ajenos bloquean otro pago sin sobrescribir ni borrar intención | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 32 |
| 325 | `cxp-payment-durable-frozen-body-key` | Pago pendiente: campos congelados/cancel/reabrir/reload/navegación y dobleenvío conservan misma intención | 19. Facturas de proveedor y cuentas por pagar | 03, 34, 35, 38 | 36 |
| 326 | `cxp-payment-native-real-process-restart` | Reinicio real del mismo ejecutable/perfil restaura cuerpo/clave de pago y retry negativo exacto | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 5 |
| 327 | `cxp-payment-no-duplicate-generic-offline-queue` | PagoCxP pierde red o navegadoroffline: conserva intención del formulario y bloquea cola genérica/IPC | 19. Facturas de proveedor y cuentas por pagar | 34, 35, 38, 39 | 4 |
| 328 | `cxp-payment-paid-document-recovery-available` | Cuenta realUSD pagada/saldo0 permite revisar intención conocida sin registrar otro pago | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 2 |
| 329 | `cxp-payment-pending-actual-role-tenant-isolation` | PendienteOWNER sobrevive logout:lectores403/empresa2real404 no acceden;OWNER recupera cuerpo/clave | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 32 |
| 330 | `cxp-providers-section-recovery` | Catálogo proveedor fallido/incompleto/malformado: error persistente, selector bloqueado y retry con lista válida conservada | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 6 |
| 331 | `cxp-read-roles-isolation` | Dos lectores reciben403/red sin caché de propietario; empresa2 con listado/catálogo/vencimientos vacíos reales | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35, 38 | 6 |
| 332 | `cxp-unpaid-history-failure-revokes-payment-control` | Deuda real pendiente: historial503 bloquea AplicarPago; retry recupera control sin abrir modal oPOST | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 2 |
| 333 | `dashboard-operational-lifecycle` | Dashboard: actualización retenida/publicación atómica y respuesta tardía tras salidaSPA | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 14 |
| 334 | `dashboard-operational-read-semantic-recovery` | Dashboard: importes por moneda, notas de crédito y contratos completos sin cifras parciales | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 130 |
| 335 | `dashboard-operational-roles` | Dashboard: dos lectores reales, empresa2 vacía y regresoOWNER | 31. Libros, estados financieros y reportes operativos | 03, 15, 35, 38 | 14 |
| 336 | `deferred-accrual-cancel-current` | Gasto/ingreso: alta conACK/retry, devengos, período repetido y cancelación503/retry tras primera cuota | 27. Ingresos y gastos diferidos | 35, 38 | 8 |
| 337 | `deferred-accrue-operation-candidate` | Registro vivo sin cambios y ausencia de asiento antes de un devengo nuevo | 27. Ingresos y gastos diferidos | 35, 38 | 40 |
| 338 | `deferred-accrue-operation-corroboration` | Confirmar devengo por asiento y acumulados completos y recuperar sin POST | 27. Ingresos y gastos diferidos | 03, 15, 34, 35, 38 | 112 |
| 339 | `deferred-accrue-operation-inflight` | Respuesta tardía de devengo no anuncia ni retira tras desmontar | 27. Ingresos y gastos diferidos | 35, 38 | 10 |
| 340 | `deferred-accrue-operation-lifecycle` | Recuperar período pendiente tras recarga y reinicio real sin envío automático | 27. Ingresos y gastos diferidos | 35, 38 | 17 |
| 341 | `deferred-accrue-operation-offline` | Devengo pendiente fuera de cola genérica al perder red | 27. Ingresos y gastos diferidos | 34, 35, 38 | 8 |
| 342 | `deferred-accrue-operation-pending-roles` | Devengar y verificar sólo por permiso, empresa y actor de intención | 27. Ingresos y gastos diferidos | 03, 35, 38 | 14 |
| 343 | `deferred-accrue-operation-receipts` | Devengo sólo con resumen completo vivo de período y cuotas | 27. Ingresos y gastos diferidos | 34, 35, 38 | 86 |
| 344 | `deferred-accrue-operation-storage` | Devengo corrupto/fallido/concurrente se conserva sin reemplazo | 27. Ingresos y gastos diferidos | 03, 35, 38 | 38 |
| 345 | `deferred-accrue-operation-zero-historical` | Período sin cuotas confirma0 y asiento histórico bloquea nuevo devengo | 27. Ingresos y gastos diferidos | 35, 38 | 8 |
| 346 | `deferred-cancel-operation-candidate` | Consulta actual completa sin cambios antes de guardar una cancelación | 27. Ingresos y gastos diferidos | 35, 38 | 40 |
| 347 | `deferred-cancel-operation-inflight` | Respuesta tardía de cancelación no anuncia ni retira tras desmontar | 27. Ingresos y gastos diferidos | 34, 35, 38 | 10 |
| 348 | `deferred-cancel-operation-lifecycle` | Recuperar cancelación con misma fotografía y clave tras recarga y reinicio real | 27. Ingresos y gastos diferidos | 35, 38 | 17 |
| 349 | `deferred-cancel-operation-offline` | Cancelación pendiente queda fuera de cola genérica al perder red | 27. Ingresos y gastos diferidos | 34, 35, 38 | 8 |
| 350 | `deferred-cancel-operation-pending-roles` | Cancelar y reintentar sólo por permiso, empresa y actor de la intención | 27. Ingresos y gastos diferidos | 03, 35, 38 | 14 |
| 351 | `deferred-cancel-operation-receipts` | Cancelación de diferido sólo con recibo completo vivo y devengos intactos | 27. Ingresos y gastos diferidos | 03, 35, 38 | 104 |
| 352 | `deferred-cancel-operation-storage` | Cancelación corrupta/fallida/concurrente se conserva sin reemplazo | 27. Ingresos y gastos diferidos | 03, 35, 38 | 38 |
| 353 | `deferred-concurrent-cancel-accrual-real` | Registro vigente independiente, lector403 y dos operadores UI despachan cancelación/devengo solapados; recarga conserva cancelado sin cuota residual | 27. Ingresos y gastos diferidos | 03, 35, 38 | 5 |
| 354 | `deferred-create-operation-inflight` | Respuesta tardía tras desmontar no anuncia ni retira la intención | 27. Ingresos y gastos diferidos | 34, 35, 38 | 10 |
| 355 | `deferred-create-operation-lifecycle` | Recuperar cuerpo y clave de alta tras recarga y reinicio real del escritorio | 27. Ingresos y gastos diferidos | 35, 38 | 17 |
| 356 | `deferred-create-operation-offline` | Alta pendiente conserva el comando fuera de la cola genérica | 27. Ingresos y gastos diferidos | 34, 35, 38 | 8 |
| 357 | `deferred-create-operation-pending-roles` | Alta pendiente privada y reintento sólo para su empresa, actor y permiso | 27. Ingresos y gastos diferidos | 03, 35, 38 | 14 |
| 358 | `deferred-create-operation-receipts` | Alta de diferido sólo con recibo completo coherente en vivo | 27. Ingresos y gastos diferidos | 03, 35, 38 | 104 |
| 359 | `deferred-create-operation-storage` | Almacenamiento corrupto/fallido/concurrente preserva el alta sin reemplazo | 27. Ingresos y gastos diferidos | 03, 35, 38 | 38 |
| 360 | `deferred-live-read-controls-recovery` | Registro de diferidos y catálogos completos en vivo antes de operar | 27. Ingresos y gastos diferidos | 03, 35, 38 | 126 |
| 361 | `deferred-live-read-controls-roles` | Crear/devengar/cancelar por permiso; formulario y consultas aislados por actor | 27. Ingresos y gastos diferidos | 03, 34, 35, 38 | 30 |
| 362 | `deferred-read-recovery-current` | Registro, cuentas y centros indisponibles: lectura atómica, bloqueo y reintento | 27. Ingresos y gastos diferidos | 35, 38 | 3 |
| 363 | `dispatch-rejected-intent-browser-recovery` | Rechazo transaccional libera cantidad obsoleta;503/400 ambiguo/ACK perdido conservan intención, recarga y replay único | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 7 |
| 364 | `dispatch-rejected-intent-native-recovery` | Ejecutable embebido: liberar intento obsoleto, revisar0.25 pendiente y recuperar ACK perdido del último despacho | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 5 |
| 365 | `dispatch-same-actor-concurrent-window` | Segunda ventana confirma0.5 mientras la primera conserva cantidad1; corroborar rechazo sin efectos | 09. Pedidos, reservas, preparación y entrega | 03, 35 | 2 |
| 366 | `document-baja-current-RA` | RA: reserva, firma original, reintento y consulta de ticket | 17. Centro de documentos, archivos y bajas RA/RC | 15, 35, 38 | 3 |
| 367 | `document-baja-current-RC` | RC: reserva, firma original, reintento y consulta de ticket | 17. Centro de documentos, archivos y bajas RA/RC | 15, 35, 38 | 3 |
| 368 | `document-baja-current-reads` | Lecturas RA/RC actuales, fallos, caché y respuesta tardía | 17. Centro de documentos, archivos y bajas RA/RC | 15, 35, 38 | 5 |
| 369 | `document-manual-current-cancel` | Anulación de borrador con motivo y sin efecto fiscal | 17. Centro de documentos, archivos y bajas RA/RC | 35, 38 | 1 |
| 370 | `document-manual-current-create` | Alta de borrador manual y replay de su original | 17. Centro de documentos, archivos y bajas RA/RC | 35, 38 | 2 |
| 371 | `document-manual-current-send-unconfigured` | Envío fiscal sin credenciales rechaza sin aceptación inventada | 17. Centro de documentos, archivos y bajas RA/RC | 35, 38 | 1 |
| 372 | `document-manual-current-sign` | XML de boleta manual firmado y CPE vinculado único | 17. Centro de documentos, archivos y bajas RA/RC | 15, 35, 38 | 1 |
| 373 | `document-manual-current-update` | Edición de borrador manual con original recuperable | 17. Centro de documentos, archivos y bajas RA/RC | 35, 38 | 1 |
| 374 | `finance-current-supplier-detraction-reverse-real` | Revertir detracción no depositada y restaurar deuda sin cargo bancario | 20. Anticipos y ajustes fiscales financieros | 35, 38 | 1 |
| 375 | `finance-cxp-inline-aging-recovery` | Aging dentro de CxP, filtro de proveedor, errores y retry sin falso mensaje de todo pagado | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 7 |
| 376 | `finance-five-reports-browser-print` | Acción Imprimir/PDF de las cinco vistas y revisión de nueve páginas actuales | 31. Libros, estados financieros y reportes operativos | 35 | 6 |
| 377 | `finance-five-reports-live-network-recovery` | Cinco reportes exigen respuesta en vivo: red fallida no presenta caché propia como reporte actual ni habilita impresión; retry real | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 10 |
| 378 | `finance-positive-aging-pen-inline-usd` | Aging positivo PEN0-30 de23.60 e inline por proveedor; cambio USD por vencer sin inventar deuda vencida | 31. Libros, estados financieros y reportes operativos | 35, 38 | 2 |
| 379 | `finance-positive-cashflow-sparse-calendar-weeks` | Proyección diaria/semanal con vencimientos15oct/5nov separados en semanas1/4 del período; cambioPEN/USD | 31. Libros, estados financieros y reportes operativos | 35, 38 | 2 |
| 380 | `finance-positive-current-cxp-csv` | Descargar CSV de nueve documentos actuales: diez columnas, valores y fórmulas protegidas | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 1 |
| 381 | `finance-positive-cxp-due-actions` | Nueve CxP; alerta positiva de dos documentos PEN/USD a seis días, expandir/ocultar/navegar/cerrar/recargar y filtrar proveedor | 31. Libros, estados financieros y reportes operativos | 35, 38 | 3 |
| 382 | `finance-positive-debt-two-currencies` | Ranking PEN de dos proveedores23.60/17.70 y USD de uno5.90, importes y orden reales separados | 31. Libros, estados financieros y reportes operativos | 35, 38 | 1 |
| 383 | `finance-positive-eight-prints-sixteen-pages` | Cinco acciones Imprimir y tres variantesUSD: ocho PDF/16páginas con semanas y proveedores completos | 31. Libros, estados financieros y reportes operativos | 35 | 2 |
| 384 | `finance-positive-four-payables-origin` | Registrar cuatro obligaciones manuales desde UI: PEN23.60 vencida, PEN11.80/USD5.90 por vencer y PEN5.90 posterior; detalle y recarga | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 385 | `finance-positive-live-read-roles-regression` | Con deuda y proyección positivas repetir503/incompletos/red/retry/tardías/filtros, dos lectores403 y empresa2 vacía | 31. Libros, estados financieros y reportes operativos | 03, 34, 35, 38 | 109 |
| 386 | `finance-range-income-csv-six-pdfs` | CSVactual13documentos/10columnas y seis impresionesPDF con Aging/ranking/flujoPEN/USD | 31. Libros, estados financieros y reportes operativos | 35 | 2 |
| 387 | `finance-range-income-five-ui-creates` | Cuatro obligaciones nuevas: PEN31-60/61-90/+90 yUSDvencida; servicioCPE a créditoPEN4.72 desdeUI con checkpoint inmediato | 31. Libros, estados financieros y reportes operativos | 15, 35 | 2 |
| 388 | `finance-range-income-recovery-roles-native` | Aging positivo por moneda/rango, ingreso futuro y proyección diaria/semanal;503/incompletos/red/retry y cinco reportes con lectores403/empresa2vacía en web y nativo | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 4 |
| 389 | `finance-report-aging-read-recovery` | Aging CxP: contrato real200, error503/200incompleto/malformado y recuperación sin reporte o impresión anterior | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 7 |
| 390 | `finance-report-cashflow-read-recovery` | Flujo de caja proyectado: contrato real200, error503/200incompleto/malformado y recuperación sin reporte o impresión anterior | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 7 |
| 391 | `finance-report-debt-read-recovery` | Proveedores con mayor deuda: contrato real200, error503/200incompleto/malformado y recuperación sin reporte o impresión anterior | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 7 |
| 392 | `finance-report-filters-race-roles` | Filtros bancarios y USD, recuperación de dependencia Aging, paginación completa y respuesta tardía; lectores403 y empresa2 vacía | 31. Libros, estados financieros y reportes operativos | 03, 34, 35, 38 | 27 |
| 393 | `finance-report-movements-read-recovery` | Movimientos bancarios: contrato real200, error503/200incompleto/malformado y recuperación sin reporte o impresión anterior | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 7 |
| 394 | `finance-report-reconciliation-read-recovery` | Conciliaciones pendientes: contrato real200, error503/200incompleto/malformado y recuperación sin reporte o impresión anterior | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 7 |
| 395 | `financial-statements-current` | Balance de comprobación, ER, BG y flujo mensual; Excel/PDF descargados desdeUI | 31. Libros, estados financieros y reportes operativos | 35 | 131 |
| 396 | `fiscal-tax-current` | Boleta manual gravada3.39+IGV0.61 y exonerada0.13; firma, XML y PDF4.13 | 15. Comprobantes electrónicos y ciclo fiscal | 17, 35 | 2 |
| 397 | `fractional-dispatch-invoice-collection-accounting` | Facturar tres despachos de una unidad, cobrar36.58 desdeUI y recalcular cinco reportes contables/descargas | 09. Pedidos, reservas, preparación y entrega | 15, 31, 35 | 14 |
| 398 | `fx-current-136-accounting-five-views-ratios` | Cinco vistas contables y siete ratios al corte136 después de ambos pagos | 29. Monedas, tipos de cambio y revaluación | 31, 35 | 24 |
| 399 | `fx-current-136-five-ple-frozen-purchase` | Descargar cincoPLE actuales por UI y contrastarlos con líneas crudas y facturaUSD congelada | 29. Monedas, tipos de cambio y revaluación | 03, 31, 35 | 5 |
| 400 | `fx-current-136-six-excel-six-pdf` | Descargar seisExcel y seisPDF reales desde web/Windows y revisar doce páginas | 29. Monedas, tipos de cambio y revaluación | 31, 35 | 24 |
| 401 | `fx-current-136-tax-credit-carryforward` | Recuperar lecturas tributarias web/Windows y calcular IGV0 con saldo a favor.52 sin guardar versiones | 29. Monedas, tipos de cambio y revaluación | 34, 35, 38 | 38 |
| 402 | `fx-current-finance-roles-isolation-usd4-20` | Cinco reportes financieros: pagos2+2/bancoUSD4.20, lectores403, empresa2vacía y regresoOWNER | 29. Monedas, tipos de cambio y revaluación | 03, 31, 34, 35, 38 | 51 |
| 403 | `fx-current-official-import-failure-contract-ui` | Importación de tipo de cambio oficial: error visible y retry manual sin cotización inventada | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 1 |
| 404 | `fx-final-web-realized-loss` | Segundo pagoUSD2 desde web: deuda0/PAGADA/banco4.20 y pérdidaPEN.50 | 29. Monedas, tipos de cambio y revaluación | 35 | 2 |
| 405 | `fx-foreign-payable-origin` | Registrar factura manual USD11.80 con cotización documental3.75 | 29. Monedas, tipos de cambio y revaluación | 35 | 1 |
| 406 | `fx-manual-quote-lifecycle` | Cotización manual USD: alta, editar una punta, A→B→A y baja reiterada con recarga | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 5 |
| 407 | `fx-monthly-tax-version-retry` | Recalcular compras extranjeras y guardar versión4 conACK/retry conservando revisión e historia | 32. Impuestos y SIRE | 35, 38 | 4 |
| 408 | `fx-new-manual-rate-create-update-deactivate` | Registrar3.75, corregir4.25 y desactivar sólo la cotización manual nueva del10oct | 29. Monedas, tipos de cambio y revaluación | 35 | 6 |
| 409 | `fx-partial-document-frozen-rate4` | Crear factura real USD4 con TC documental4 y conservar su valuación fiscal tras ambos pagos | 29. Monedas, tipos de cambio y revaluación | 35 | 6 |
| 410 | `fx-partial-native-realized-gain` | Pagar USD2 desde Windows: deuda2/banco6.20 y ganancia realizadaPEN.50 | 29. Monedas, tipos de cambio y revaluación | 35 | 2 |
| 411 | `fx-ple-books-origin-currency` | Descargar cinco libros después de liquidaciónUSD; compras expresadas enPEN con origenUSD/3.75 | 29. Monedas, tipos de cambio y revaluación | 03, 31, 35 | 5 |
| 412 | `fx-purchase-operational-report` | Registro operativo y Excel con moneda original y totales por divisa | 29. Monedas, tipos de cambio y revaluación | 31, 35 | 1 |
| 413 | `fx-revaluation-atomic-ledger` | Reversar ajustes del baseline, corregir corte con ACK perdido, bloquear doble corte y rechazar cambio concurrente de cotización | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 5 |
| 414 | `fx-revaluation-cut-date-and-read` | Excluir obligación futura; cambio de corte descarta preview y respuesta tardía; consulta503 bloquea registro | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 4 |
| 415 | `fx-sire-rce-origin-currency` | Generar desdeUI y descargar RCE local con cinco compras enPEN | 32. Impuestos y SIRE | 31, 35 | 1 |
| 416 | `fx-usd-bank-settlement` | Banco USD, capital20 con cotización explícita, reversa previa y pago11.80 con ACK/retry | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 4 |
| 417 | `fx-validation-and-read-recovery` | Rechazar siete decimales y valores inválidos; consulta503 exige reintento | 29. Monedas, tipos de cambio y revaluación | 34, 35, 38 | 6 |
| 418 | `gre-action-invalid-confirmation-retains-intent` | Acción201 incompleta/ajena/estado erróneo/queued/caché no confirma anulación | 16. Guías de remisión y traslado | 35, 38 | 14 |
| 419 | `gre-annul-native-ack-restart-original-key` | Anular nueva GRE conACK perdido y reinicio real; reintentar misma acción sin segundo efecto | 16. Guías de remisión y traslado | 35, 38 | 4 |
| 420 | `gre-capacity-reverse-transfer` | GRE con producto de inventario0001→0000; rechazar otro producto, exceso y guía agotada; reintentar traslado real | 16. Guías de remisión y traslado | 35, 38 | 6 |
| 421 | `gre-current-five-guide-exports-xml-date` | CSV5guías/12columnas yPDF anulada: fecha delXML, peso0.125 ycampos exactos | 16. Guías de remisión y traslado | 17, 35, 38 | 8 |
| 422 | `gre-download-invalid-file-and-live-retry` | DescargarCSV/PDF:503/red/JSON/mime/truncado/caché bloquean archivo; retry real desde lista/detalle | 16. Guías de remisión y traslado | 17, 35, 38 | 32 |
| 423 | `gre-five-invalid-confirmation-harness-corrected` | Cinco variantes independientes de confirmación inválida: incompleta, estado, identidad, queued y caché | 16. Guías de remisión y traslado | 35, 38 | 14 |
| 424 | `gre-known-unapplied-vs-uncertain-rejection` | Rechazo explícito de demo libera envío;400 genérico/403/503/caché/red conservan clave trasrecarga | 16. Guías de remisión y traslado | 03, 15, 35, 38, 39 | 8 |
| 425 | `gre-late-filter-guide-download` | Cambiar filtro/guía durante consulta y descarga; descartar respuesta anterior | 16. Guías de remisión y traslado | 17, 35, 38 | 8 |
| 426 | `gre-live-complete-reads` | Guías, indicadores y detalle:503/red/incompletos/malformados/caché, retry actual y sin falso vacío/cero | 16. Guías de remisión y traslado | 17, 35, 38 | 68 |
| 427 | `gre-manual-create-sources-intent-recovery` | Alta manual: fuentes completas, confirmación201 incompleta y red fallida; cerrar/recargar conserva cuerpo/clave | 16. Guías de remisión y traslado | 35, 38 | 50 |
| 428 | `gre-order-origin-actual-role-isolation` | Lectores403 yempresa2real404 para pedido principal no exponen origen ni writer; OWNER recupera origen real | 16. Guías de remisión y traslado | 03, 35 | 10 |
| 429 | `gre-order-origin-base-read-regression5` | Regresión de34pasos de catálogos/indicadores/detalle/establecimientos/productos y retry negativo con cincoGRE existentes | 16. Guías de remisión y traslado | 17, 35, 38 | 68 |
| 430 | `gre-order-origin-context-abandoned-late` | Lectura deorigen retenida no habilita writer; abandonar página descarta respuesta negativa anterior | 16. Guías de remisión y traslado | 35, 38 | 6 |
| 431 | `gre-order-origin-live-complete-recovery` | GRE desde pedido: origen, destinatario y detalle completos en vivo; doce negativos retiran writer y retry real restaura | 16. Guías de remisión y traslado | 03, 35, 38 | 54 |
| 432 | `gre-original-context-explicit-recovery` | Botón UI regresa al contexto original; reintento negativo recupera misma clave y cuerpo | 16. Guías de remisión y traslado | 34, 35, 38 | 24 |
| 433 | `gre-pending-origin-dispatch-context` | Despacho distinto del mismo pedido bloquea reintento de alta anterior; conserva intención y clave | 16. Guías de remisión y traslado | 34, 35, 38 | 24 |
| 434 | `gre-persisted-origin-references-inconsistent` | Cinco referencias dañadas de pedido/despacho bloquean writer sin borrar o reemplazar intención | 16. Guías de remisión y traslado | 34, 35, 38 | 24 |
| 435 | `gre-private-motives` | Transporte privado: traslado entre establecimientos y devolución, conductor, placa y PDF | 16. Guías de remisión y traslado | 17, 35 | 4 |
| 436 | `gre-public-create-lost-ack-original-key` | Crear GRE pública/OTROS0.125; ACK perdido, cerrar/recargar y recuperar misma guía | 16. Guías de remisión y traslado | 15, 34, 35, 38 | 3 |
| 437 | `gre-reader-company-isolation` | Lectores inventario/contabilidad403, empresa2 realmentevacía, OWNER restaurado | 16. Guías de remisión y traslado | 03, 35 | 10 |
| 438 | `gre-transfer-current` | GRE traslado entre establecimientos0000→0001: alta, firma automática y PDF | 16. Guías de remisión y traslado | 17, 35 | 2 |
| 439 | `gre-transport-prewriter-exact-live-http400` | Transporte GRE: sólo HTTP400 real/código previo en vivo sinoffline/pending/queued libera intención | 16. Guías de remisión y traslado | 03, 35, 38 | 34 |
| 440 | `help-article-detail-get-fixtures` | Detalle de Ayuda: GETfixtures positivo/503/nulo/retry/cierre sin artículo empresarial | 37. Auditoría, notificaciones y ayuda | 34, 35, 38 | 14 |
| 441 | `help-catalog-read-recovery` | Consultar ayuda, distinguir error de catálogo vacío y reintentar | 37. Auditoría, notificaciones y ayuda | 35, 38 | 3 |
| 442 | `help-guided-tours-lifecycle` | Guía contextual y tours: avanzar, retroceder, finalizar, repetir, saltar/cerrar y resetear | 37. Auditoría, notificaciones y ayuda | 03, 34, 35, 38 | 12 |
| 443 | `help-native-real-roles-catalog-guide` | Ayuda nativa: tres perfiles, catálogo503/retry y35fichas locales | 37. Auditoría, notificaciones y ayuda | 03, 35, 38 | 10 |
| 444 | `help-native-tour-navigation` | Tours nativos: pasos visibles, atrás/finalizar/repetir/saltar/cerrar/resetear y progreso restituido | 37. Auditoría, notificaciones y ayuda | 34, 35, 38 | 36 |
| 445 | `help-sales-parent-anchor` | Tour contextual de vendedor destaca menú Ventas desplegable real | 37. Auditoría, notificaciones y ayuda | 03, 35, 38 | 6 |
| 446 | `help-tour-readable-contrast` | Texto de tours legible con colores semánticos en fondo oscuro | 37. Auditoría, notificaciones y ayuda | 35, 38 | 4 |
| 447 | `inventory-actual-atomic-abandonment-ui` | Dos abandonos privados reales y recuperación del ACK confirmado sin repetir stock; web/Windows | 07. Existencias, kardex, ajustes y transferencias | 15, 34, 35, 38 | 18 |
| 448 | `inventory-actual-unplanned-ack-read-archive` | ACK real anterior se recupera por GET y archiva completo antes de retirar, sin replay | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 6 |
| 449 | `inventory-current-real-original-recovery-transfer-kardex` | Ajuste original real recuperado, transferencia y kardex corroborados | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 1 |
| 450 | `inventory-dashboard-read-recovery` | Recuperar indicadores y catálogo del panel de forma independiente sin falsos ceros | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 12 |
| 451 | `inventory-kardex-read-filter-recovery` | Consultar40movimientos, filtrar costo0 y recuperar fallos de datos/resumen/catálogos sin respuestas anteriores | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 19 |
| 452 | `inventory-manual-original-read-fault-storage` | Recibo GET ajeno/parcial/cacheado, JSON corrupto y fallos de archivo preservan intención | 07. Existencias, kardex, ajustes y transferencias | 03, 34, 35, 38 | 40 |
| 453 | `inventory-manual-original-read-no-catalog` | Consulta manual GET recupera originales con catálogo fallido/vacío, sin RPC/reenvío | 07. Existencias, kardex, ajustes y transferencias | 35 | 12 |
| 454 | `inventory-master-current-category` | Categoría: alta, edición canónica, recarga y desactivación | 06. Productos, servicios y maestros de inventario | 35 | 1 |
| 455 | `inventory-master-current-location` | Ubicación: alta, edición, baja y reactivación | 06. Productos, servicios y maestros de inventario | 35 | 1 |
| 456 | `inventory-master-current-warehouse` | Almacén: alta, edición, bloqueo por ubicación activa y ciclo de estados | 06. Productos, servicios y maestros de inventario | 35 | 2 |
| 457 | `inventory-operation-adjustment-ack-restart-original-key` | Conteo-.25:201 real conACK perdido, reinicio deproceso, intención recuperada automáticamente yreintento único | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 4 |
| 458 | `inventory-operation-current44-kardex-two-warehouses` | Catálogo/panel yKardex44; producto valuado enambos almacenes tras traslado yconteo | 07. Existencias, kardex, ajustes y transferencias | 35 | 10 |
| 459 | `inventory-operation-late-generations` | Descartar lecturas yresultados anteriores tras cambio deconsulta/actor; conservar intento propio | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 18 |
| 460 | `inventory-operation-live-complete-catalogs` | Ajustes/traslados: catálogos completos en vivo; fallos, caché e incompletos bloquean escritura y permitenretry | 07. Existencias, kardex, ajustes y transferencias | 34, 35, 38 | 122 |
| 461 | `inventory-operation-live-read-country` | Operaciones Inventario: configuración fiscal desconocida bloquea campos; reintento manual | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 8 |
| 462 | `inventory-operation-live-read-guides` | Operaciones Inventario: catálogo completo de guías vigentes de traslado bajo permiso existente, sin generación/envío | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 26 |
| 463 | `inventory-operation-live-read-isolation` | Operaciones Inventario: catálogos propios de secundaria real y recuperación primaria | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 8 |
| 464 | `inventory-operation-live-read-lifecycle` | Operaciones Inventario: fuentes503, reintento y catálogo de pantalla anterior descartado | 07. Existencias, kardex, ajustes y transferencias | 34, 35, 38 | 12 |
| 465 | `inventory-operation-live-read-reads` | Operaciones Inventario: productos/almacenes completos en vivo, conteos/empresa/identidad y bloqueos ante desconocido/cache/cola | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 94 |
| 466 | `inventory-operation-live-read-restart` | Operaciones Inventario: reinicio físico separado sin ajuste/transferencia automática | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 6 |
| 467 | `inventory-operation-live-read-roles` | Operaciones Inventario: dos roles reales sin permiso de operación y retorno OWNER | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 10 |
| 468 | `inventory-operation-reader-company-isolation` | Lectores de inventario/contabilidad sin writer; empresa2 vacía; propietario recupera su contexto | 07. Existencias, kardex, ajustes y transferencias | 03, 35 | 10 |
| 469 | `inventory-operation-real-not-applied-rejection` | Rechazar conteo-999 real sin existencia:400 marcado, campos editables, sin operación ni asiento | 07. Existencias, kardex, ajustes y transferencias | 35 | 1 |
| 470 | `inventory-operation-transfer-quarter-original-key` | Trasladar0.25 Lima→Arequipa yrecuperar confirmación real con metadata objeto yclave original | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 1 |
| 471 | `inventory-original-receipt-ui-binding` | Ajuste/transferencia exige recibo original completo ligado a empresa, actor, clave y cuerpo | 07. Existencias, kardex, ajustes y transferencias | 03, 31, 34, 35, 38 | 60 |
| 472 | `inventory-original-receipt-ui-durable-archive` | Archivo completo verificado antes de retirar pendiente; recarga y errores de almacenamiento conservan intención | 07. Existencias, kardex, ajustes y transferencias | 34, 35 | 20 |
| 473 | `inventory-precision-zero-valued` | Altas KGM2.5, costo0 confirmado, edición mínimo y ajustes+0.125/-0.375 con kardex | 07. Existencias, kardex, ajustes y transferencias | 15, 35 | 9 |
| 474 | `inventory-products` | Altas de categoría/productos con stock inicial, gravado/exonerado, recarga | 06. Productos, servicios y maestros de inventario | 35 | 6 |
| 475 | `inventory-products-read-recovery` | Consultar catálogo, conservar búsqueda y recuperar503/200incompleto sin filas ni controles previos | 06. Productos, servicios y maestros de inventario | 03, 34, 35, 38 | 8 |
| 476 | `inventory-reader-controls-current` | Controles y rutas de producto por permisos reales: lector y OWNER | 06. Productos, servicios y maestros de inventario | 03, 35 | 14 |
| 477 | `inventory-reader-update-denied` | Rol con sólo lectura consulta producto, intenta editar, recibe403, conserva formulario y recarga valor original | 07. Existencias, kardex, ajustes y transferencias | 03, 35 | 2 |
| 478 | `inventory-resolution-physical-native-restart` | Reinicio físico Windows del pendiente original con mismo binario y archivo intacto | 07. Existencias, kardex, ajustes y transferencias | 34, 35, 38 | 4 |
| 479 | `inventory-resolution-web-two-tab` | Dos pestañas recuperan el mismo abandono sin archivo sobrescrito ni fila duplicada | 07. Existencias, kardex, ajustes y transferencias | 35, 38 | 5 |
| 480 | `inventory-safe-abandonment-storage-ui` | Abandono original: identidad/cuerpo, catálogo fallido, respuesta tardía y archivo durable en web/Windows | 07. Existencias, kardex, ajustes y transferencias | 03, 31, 34, 35, 38 | 92 |
| 481 | `inventory-three-pages-roles-isolation` | Cambiar actores/empresa y separar lectura de productos, indicadores y Kardex sin caché ajena | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 11 |
| 482 | `inventory-transfer-current` | Transferir2CMP Lima→Arequipa con GRE firmada; ACK perdido/reintento y Kardex de ambos almacenes | 07. Existencias, kardex, ajustes y transferencias | 15, 35, 38 | 2 |
| 483 | `invoice-from-order-inflight` | Respuesta retenida después de desmontar no confirma ni limpia | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 10 |
| 484 | `invoice-from-order-lifecycle` | ACK perdido, recarga y regreso conservan intención; verificación antes de retry manual | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 22 |
| 485 | `invoice-from-order-pending-restart` | Intención de factura sobrevive reinicio nativo y se verifica sin regenerar | 09. Pedidos, reservas, preparación y entrega | 15, 35, 38 | 5 |
| 486 | `invoice-from-order-reads-roles` | Pedido completo vivo por empresa; lector sin writer ni intención OWNER | 09. Pedidos, reservas, preparación y entrega | 03, 15, 34, 35, 38 | 46 |
| 487 | `invoice-from-order-receipts` | Confirmación de factura exige recibo vivo, pedido completo y CPE vinculado | 09. Pedidos, reservas, preparación y entrega | 15, 35, 38 | 92 |
| 488 | `invoice-from-order-storage` | Fallo/corrupción/cambio concurrente no reemplazan ni retiran la intención | 09. Pedidos, reservas, preparación y entrega | 03, 15, 35, 38 | 36 |
| 489 | `isolation-current` | Empresa2 desde cero; siete listados aislados y cuatro IDs ajenos404 desde navegación UI | 03. Usuarios, roles, permisos y sesiones | 15, 35 | 13 |
| 490 | `logistics-ready-read-recovery` | Tablero de despacho:503 persistente sin falso vacío ni filas previas; retry200, respuesta incompleta y recarga | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 5 |
| 491 | `mixed-invoice-catalog-receipts` | Exigir catálogo vivo de recepciones cerradas antes de facturar y recuperar nueve fallos mediante reintento propio | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 36 |
| 492 | `mixed-invoice-catalog-suppliers` | Validar proveedor activo de la empresa con catálogo completo y reintento visible | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 30 |
| 493 | `mixed-invoice-current-ple` | Descargar cinco libros PLE posteriores a factura mixta y contrastar con diario raw | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35 | 5 |
| 494 | `mixed-invoice-current-reports` | Consultar cinco estados del corte141 y descargar seis Excel y seis PDF desde ambas interfaces | 19. Facturas de proveedor y cuentas por pagar | 31, 35 | 24 |
| 495 | `mixed-invoice-native-create-ack` | Registrar factura consolidada real de orden mixta y recuperar ACK perdido mediante retryUI | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 4 |
| 496 | `mixed-invoice-roles-restart` | Leer la factura con roles y aislamiento y recuperarla después de reiniciar el mismo binario | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 16 |
| 497 | `mixed-receipt-current-ple` | Descargar cinco libros PLE del corte posterior a recepciones y contrastar diario raw | 14. Recepciones y devoluciones al proveedor | 03, 31, 35 | 5 |
| 498 | `mixed-receipt-current-reports` | Consultar cinco estados del corte140 y descargar seis Excel y seis PDF desde ambas interfaces | 14. Recepciones y devoluciones al proveedor | 31, 35 | 24 |
| 499 | `mixed-receipt-literal-routing` | Abrir ruta literal de alta y detalle UUID de recepción, conservando query tras recarga | 14. Recepciones y devoluciones al proveedor | 03, 35 | 4 |
| 500 | `mixed-receipt-native-remainder-ack` | Cerrar saldo real de orden mixta y recuperar ACK perdido mediante retry UI sin duplicación | 14. Recepciones y devoluciones al proveedor | 03, 31, 35, 38 | 4 |
| 501 | `mixed-receipt-quantity-scanner` | Cantidad pendiente exacta a dos decimales y escáner repetido limitado al saldo | 14. Recepciones y devoluciones al proveedor | 35, 38 | 10 |
| 502 | `mixed-receipt-roles-restart` | Leer tres recepciones con permisos/aislamiento y recuperar mismo corte tras reinicio | 14. Recepciones y devoluciones al proveedor | 03, 31, 35, 38 | 12 |
| 503 | `mixed-receipt-web-partial` | Recibir y cerrar parcial real de tres líneas con fracciones y precio cero | 14. Recepciones y devoluciones al proveedor | 35 | 3 |
| 504 | `monitor-live-read-lifecycle` | Monitoreo: respuesta de pantalla anterior descartada y fuente503 sin falso todo en orden | 37. Auditoría, notificaciones y ayuda | 35, 38 | 12 |
| 505 | `monitor-live-read-reads` | Monitoreo: cuatro fuentes completas en vivo y ventanas acotadas; negativos/recuperación sin drenaje | 37. Auditoría, notificaciones y ayuda | 03, 35, 38 | 204 |
| 506 | `monitor-live-read-restart` | Monitoreo: reinicio físico del escritorio separado sin claim, drenaje ni reintento automático | 37. Auditoría, notificaciones y ayuda | 35, 38 | 6 |
| 507 | `monitor-live-read-roles` | Monitoreo: dos actores reales y fixtures positivos sin control de reintento; retorno OWNER | 37. Auditoría, notificaciones y ayuda | 03, 35, 38 | 14 |
| 508 | `native-accounting-main-recovery-roles` | Repetir diez vistas, fallos/retry, carreras de período/carga y cambios de lector en el binario embebido actualizado | 31. Libros, estados financieros y reportes operativos | 03, 34, 35, 38 | 6 |
| 509 | `native-accounting-reads-current-binary` | Nuevo debug embebido: cinco estados109pasos/refresco2/roles27/libros34/tributos19 | 31. Libros, estados financieros y reportes operativos | 03, 15, 34, 35, 38 | 191 |
| 510 | `native-aging-positive-and-current-report-isolation` | Aging positivo nativoADMIN→lector403/sinred→ADMIN; mismo navegador once reportes principal18→empresa2vacía→lector→principal | 31. Libros, estados financieros y reportes operativos | 03, 35 | 7 |
| 511 | `native-cash-controls-current-binary130` | Nuevo debug: recuperación/roles/tardías/descargas negativas yreportes130 | 12. Cajas, arqueos, turnos y cortes | 03, 31, 35, 38 | 1 |
| 512 | `native-cash-report-current-api-same-binary131` | Reporte de caja con API actualizado y mismo debug/frontend verificados porhash | 12. Cajas, arqueos, turnos y cortes | 31, 35, 39 | 1 |
| 513 | `native-cash-supplier-current137-reports` | NuevoWindows corte137:cincoestados/cincofinancieros/impuestos/exportaciones actuales y segregación | 31. Libros, estados financieros y reportes operativos | 03, 34, 35, 38 | 118 |
| 514 | `native-cashflow-real-source-recovery` | Mismo binario contra API corregida: tres fallos de fuente/retry/recarga y76pasos de los cinco reportes | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 8 |
| 515 | `native-client-cache-actor` | Tauri2: login seguro, lectura autorizada, ADMIN→lector→ADMIN y fallback propio después de recarga | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 6 |
| 516 | `native-client-durable-edit` | Editar cliente sin conexión, informar pendiente202, bloquear otro envío, recargar y sincronizar la intención legacy previamente rechazada400 | 39. Trabajo sin conexión y escritorio Windows | 35, 38 | 6 |
| 517 | `native-client-sync-retry-503` | Sincronizar edición nativa:503 previo al commit, mismo ID pendiente y reintento200, teléfono persistente tras recarga | 39. Trabajo sin conexión y escritorio Windows | 35, 38 | 3 |
| 518 | `native-company-durable-intent-real-restart` | Reinicio real del mismo ejecutable/perfil recupera borrador propio congelado y mismo intento | 04. Identidad, parámetros, sucursales y series | 35, 38 | 6 |
| 519 | `native-company-optional-current-binary133` | Binario Windows actual: campos opcionales, recibos negativos, borradores, roles, reinicio y lecturasGRE | 04. Identidad, parámetros, sucursales y series | 03, 31, 35, 38 | 84 |
| 520 | `native-cpe-a4-current-binary131` | Nuevo binario Windows: A4 y regresión de listado/indicadores/consulta financiera sin nuevas operaciones | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 35, 38 | 111 |
| 521 | `native-cpe-creation-current-binary133` | Nuevo binario Windows: recuperación de emisión, sesión, borrador dañado, reportes, impuestos y estado final | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 34, 35, 38 | 90 |
| 522 | `native-cpe-creation-input-rejection-current-binary133` | BinarioWindowsactual: rechazo real/corrección negativa/sesiones/reinicio/borrador dañado/lecturas/24A4 | 15. Comprobantes electrónicos y ciclo fiscal | 03, 34, 35, 38 | 110 |
| 523 | `native-cpe-note-current-binary133` | Binario Windows actual: orígenes, firma recuperada, aislamiento, intención dañada, A4 y cálculos tributarios | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 34, 35, 38 | 85 |
| 524 | `native-cpe-read-current-binary131` | Cuatro recorridos deldebug nuevo: lecturas46/descargas15/tardías4/roles5 | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 35, 38, 39 | 70 |
| 525 | `native-cpe-send-current-binary133` | Binario Windows actual: envío negativo, sesión, reinicio, intención dañada,24A4 y lectura financiera | 15. Comprobantes electrónicos y ciclo fiscal | 03, 17, 34, 35, 38 | 112 |
| 526 | `native-cxp-detail-current136` | Nuevo binarioWindows: detalle/historial completos, recovery33/catálogo21/reportesfinancieros25 | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 34, 35, 38 | 79 |
| 527 | `native-cxp-list-sections-live-reports` | Nuevo ejecutable: Lista/catálogos/vencimientos CxP y cinco reportes exigiendo red, Aging inline, filtros, actores y rutas | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35, 38 | 8 |
| 528 | `native-cxp-payment-recovery-current136` | NuevoWindows:recuperación18/almacenamiento roles16/regresión detalle33/catálogo21/finanzas25 | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 34, 35, 38 | 113 |
| 529 | `native-finance-five-reports-and-inline-aging` | Repetir reportes, filtros, errores/retry/tardías, lectores y empresa2; Aging CxP y regresión de rutas en nuevo binario | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 7 |
| 530 | `native-finance-positive-current-binary` | Nuevo ejecutable: rutas/caché/actores, nueve casos positivos,76reportes y32CxP con errores/retry/roles | 31. Libros, estados financieros y reportes operativos | 03, 34, 35, 38 | 121 |
| 531 | `native-fx-partial-current-136` | Mismo binario Windows: pago parcial real, reportes/exportaciones/impuestos y aislamiento al corte136 | 29. Monedas, tipos de cambio y revaluación | 03, 31, 34, 35, 38 | 58 |
| 532 | `native-gre-context-current-binary133` | Binario Windows actual: contextos de alta GRE, reinicio, manual/origen/lecturas y roles | 16. Guías de remisión y traslado | 03, 17, 34, 35, 38 | 109 |
| 533 | `native-gre-context-original-recovery-restart` | Reinicio real de mismo binario/perfil conserva intento y bloquea despacho distinto; regreso UI recupera original | 16. Guías de remisión y traslado | 35, 38 | 6 |
| 534 | `native-gre-current-binary131` | Diez pruebas deldebug actual deGRE, perfil/SQLite yfuentes históricas preservados | 16. Guías de remisión y traslado | 03, 17, 35, 38, 39 | 100 |
| 535 | `native-gre-order-origin-current-binary133` | BinarioWindowsactual: GREdesdepedido/origenen vivo/roles/tardías/transporte negativo/lecturas base | 16. Guías de remisión y traslado | 03, 17, 35, 38 | 86 |
| 536 | `native-gre-unapplied-current-binary131` | Siete recorridos delnuevo debug:rechazos/lecturas/confirmación/descargas/tardías/roles/exportación | 16. Guías de remisión y traslado | 03, 15, 17, 35, 38, 39 | 81 |
| 537 | `native-inventory-current-binary131` | Once pruebas deldebug final posterior acontrato deconfirmación ypersistencia deintento | 07. Existencias, kardex, ajustes y transferencias | 03, 15, 31, 34, 35, 38, 39 | 272 |
| 538 | `native-inventory-three-pages-recovery` | Repetir tres pantallas, errores/retry, lecturas tardías y permisos en el binario embebido actual | 07. Existencias, kardex, ajustes y transferencias | 03, 35, 38 | 5 |
| 539 | `native-operational-current-binary116` | Debug embebido actual: panel/documentos/descargas68, oracle y lecturas tardías | 31. Libros, estados financieros y reportes operativos | 35 | 1 |
| 540 | `native-pending-queue-actor` | Cambiar ADMIN→lector→ADMIN con edición pendiente; lector no puede verla ni sincronizarla y el dueño la recupera | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 3 |
| 541 | `native-public-session-current-two-hosts` | Dos ventanas Windows conservan una sesión segura compartida al recuperar la ruta pública | 03. Usuarios, roles, permisos y sesiones | 35, 38 | 1 |
| 542 | `native-purchase-multiline-current-binary133` | Mismo binario Windows: edición real de varias líneas, recarga y permisos del nuevo BORRADOR | 13. Compras: cotización y orden | 03, 31, 35, 38 | 10 |
| 543 | `native-remaining-dispatch-retry` | Ejecutable embebido nuevo: pendiente1;503 antes del commit, mismos datos/clave, salida única yLISTO_FACTURAR | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 3 |
| 544 | `native-rrhh-benefits-reads-current-binary116` | Nuevo debug embebido: cuatro recorridos de lecturas laborales con errores/retry, roles, tardías y oracle | 35. CTS y liquidaciones | 03, 38 | 1 |
| 545 | `native-rrhh-cross-current-calculator-write` | Debug actual: calculadora con fuentes fallidas/retry/selección, nómina noviembre2025AFP real y septiembre visible | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 1 |
| 546 | `native-rrhh-eps-carry-current-binary116` | Nuevo debug EPS: origen estricto, cadena de consumo/retry del borrador, oracle y roles | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 1 |
| 547 | `native-rrhh-eps-settlement-current-binary120` | Nuevo debug: pago real/replay, recuperación laboral, roles, banco/ledger y reportes al corte120 | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 1 |
| 548 | `native-rrhh-liquidation-current-unchanged-binary` | Mismo debug embebido: cálculo nuevo de liquidación desdeUI con fuente503/incompleta y retry real | 35. CTS y liquidaciones | 38 | 1 |
| 549 | `native-rrhh-payroll-reads-current-binary116` | Debug actual: lectura estricta, recuperación, generaciones, permisos y oracle de ocho fotografías de planilla | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 1 |
| 550 | `native-rrhh-recruitment-reports` | Repetir carga/error/retry/filtros y cambios de actor/empresa en reclutamiento y reportes del nuevo binario | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 10 |
| 551 | `native-sales-report-availability-and-config-reader` | Paquete embebido: dos pedidos/seis unidades, OTIF no evaluado y recarga; ConfigReader sin editor/403; volver aADMIN y restauración deshabilitada | 31. Libros, estados financieros y reportes operativos | 03, 15, 35, 38 | 8 |
| 552 | `native-same-actor-late-read` | Demorar200 real en WebView2, revocar permiso por UI, recibir403 y liberar respuesta vieja; fallo de red posterior | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 8 |
| 553 | `native-static-actor-cache-bootstrap` | Paquete embebido ADMIN→lector→ADMIN;403 y fallo de red no filtran clientes; fallback propio y recarga sin401 falso de país | 39. Trabajo sin conexión y escritorio Windows | 03, 35 | 5 |
| 554 | `native-static-client-detail-offline` | Ficha de cliente: lectura real200, bloquear GET y recargar desde SQLite propio | 39. Trabajo sin conexión y escritorio Windows | 35, 38 | 2 |
| 555 | `native-static-company-editor-readonly` | Ejecutable embebido: abrir cinco datos originales, cancelar/recargar; lector no tiene editor; volver a ADMIN recupera control | 04. Identidad, parámetros, sucursales y series | 03, 35 | 3 |
| 556 | `native-static-dynamic-client-routes` | Ejecutable con frontend embebido: login, navegar a edición de cliente real, recargar y volver al detalle | 39. Trabajo sin conexión y escritorio Windows | 35, 38 | 4 |
| 557 | `native-static-exported-rma-journal` | Abrir RMA existente y recargar; ruta de edición de asiento inmutable rechaza y permite volver al detalle | 10. Devoluciones de clientes, notas y saldo a favor | 31, 35, 39 | 4 |
| 558 | `native-static-sales-reports-current` | Ejecutable embebido: resumen real, estado, diez reportes con503/retry200 y recarga | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 12 |
| 559 | `native-tax-period-recovery-roles` | Repetir recuperación/carreras y denegaciones de los dos formularios tributarios en el binario actualizado | 32. Impuestos y SIRE | 03, 34, 35, 38 | 13 |
| 560 | `native-treasury-batch-current-binary126` | Nuevo debug: pago real/replay, recuperación, roles y reportes al corte126 | 22. Tesorería y programación de pagos | 03, 35 | 1 |
| 561 | `native-treasury-current-binary116` | Nuevo debug136páginas: tesorería, estados/libros/tributos116 y regresión financiera positiva/permisos | 22. Tesorería y programación de pagos | 03, 15, 31, 34, 35, 38 | 319 |
| 562 | `native-wizard-current-binary116` | Nuevo debug embebido: wizard52 y preparación del perfil OWNER | 02. Primer acceso y preparación de la empresa | 35, 38 | 1 |
| 563 | `notifications-individual-real-order` | Generar avisos confirmando/cancelando pedido real; lectura individual503 y reintento con teclado, recarga conserva otro aviso pendiente | 37. Auditoría, notificaciones y ayuda | 35, 38 | 7 |
| 564 | `notifications-recovery-actions-current` | Error/reintento de bandeja, marcar todas y eliminar con503/retry, recarga y denegación vendedor | 37. Auditoría, notificaciones y ayuda | 03, 35, 38 | 8 |
| 565 | `notifications-same-browser-company-isolation` | Bandejas y recarga al pasar principal→empresa2→principal mediante logout/login UI | 37. Auditoría, notificaciones y ayuda | 03, 35 | 5 |
| 566 | `offline-cache-actor-permission-isolation` | ADMIN cachea clientes; lector de misma empresa recibe403 y falla cerrada ante red perdida; volver aADMIN | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 4 |
| 567 | `offline-client-cache-company-switch-real` | Cachear clientes reales, cambiar de empresa en mismo navegador y recuperar sólo catálogo propio tras fallo de red | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 7 |
| 568 | `offline-client-real-edit-sync` | Editar cliente sin conexión, conservar pendiente al recargar, bloquear doble envío y sincronizar tras503 con el mismo elemento | 39. Trabajo sin conexión y escritorio Windows | 34, 35, 38 | 5 |
| 569 | `offline-snapshots-company-scope` | Actualizar76snapshots por empresa, perder conexión y recuperar controles con cola vacía | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 3 |
| 570 | `onboarding` | Asistente completo: RUC/razón social, certificado de prueba, fiscal y autoridad | 02. Primer acceso y preparación de la empresa | 15, 35 | 10 |
| 571 | `operational-dashboard-seven-source-failures` | Siete fuentes backend fallidas impiden métricas parciales/caché y reintento real recupera21CPE | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 1 |
| 572 | `operational-fiscal-downloads-real-files` | DescargasPDF/XML fiscal desdeUI: bytes válidos, resolver seguro y retry; XML firmado idéntico en Centro de Documentos | 17. Centro de documentos, archivos y bajas RA/RC | 15, 35, 38 | 1 |
| 573 | `operational-panel-documents-downloads-recovery` | Panel, Documentos y Descargas: contratos completos,503/red/retry, filtros, lectores403 y empresa2 realmente vacía | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 2 |
| 574 | `operational-raw-oracle-late-queries` | Métricas e identidad fiscal contra filas crudas; cuatro lecturas tardías no sustituyen errores de otra consulta | 31. Libros, estados financieros y reportes operativos | 35, 38 | 4 |
| 575 | `payroll-approval-operation-inflight` | Salida durante POST o GET retenido conserva intención y recibo | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 14 |
| 576 | `payroll-approval-operation-lifecycle` | ACK503, recarga, cancelación, negativa y VERIFY recuperable sólo con GET | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 14 |
| 577 | `payroll-approval-operation-offline` | Fallo de red mantiene aprobación original fuera de cola genérica | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 16 |
| 578 | `payroll-approval-operation-payment-reads` | Regresión de pago por rechazo compartido de flags cached/queued/offline/pending | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 54 |
| 579 | `payroll-approval-operation-pending-restart-approve` | Reinicio real con aprobación APPROVE pendiente | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 5 |
| 580 | `payroll-approval-operation-pending-restart-verify` | Reinicio real con recibo VERIFY pendiente y recuperación exclusivamente GET | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 5 |
| 581 | `payroll-approval-operation-pending-roles` | Aprobador RRHH privado, calculador OWNER, pagador, lectores y empresa2 | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 20 |
| 582 | `payroll-approval-operation-reads` | Lecturas incompletas o no vivas bloquean aprobación; recuperación manual | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 50 |
| 583 | `payroll-approval-operation-receipts` | Aprobación exige recibo445 íntegro y luego fotografía viva | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 46 |
| 584 | `payroll-approval-operation-storage` | Set/readback/transición/remove, corrupción y cambio de bytes concurrente | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 28 |
| 585 | `payroll-approval-operation-verification` | Cabecera viva con importes, aprobador y evento coincidentes; rechazo de cache/cola | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 22 |
| 586 | `payroll-destination-live-approval-smoke` | Aprobación recuperable no se altera al endurecer destinos de tesorería | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 8 |
| 587 | `payroll-destination-live-payment-lifecycle` | ACK503 y replay del pago conservan la intención al endurecer destinos | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 14 |
| 588 | `payroll-destination-live-payment-reads` | Cabecera, detalle y destinos en vivo; regresión compartida de consultas | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 54 |
| 589 | `payroll-destination-live-read-recovery` | Destinos bancarios/caja no vivos bloquean pago y se recuperan manualmente | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 38 |
| 590 | `payroll-payment-operation-inflight` | Salida durante POST retenido: recibo tardío no limpia; retorno con retry manual | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 10 |
| 591 | `payroll-payment-operation-lifecycle` | ACK503, recarga, cancelar, negativa y estado pagado con replay manual | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 14 |
| 592 | `payroll-payment-operation-offline` | Fallo de red y respuestas offline conservan el mismo cuerpo sin cola | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 16 |
| 593 | `payroll-payment-operation-pending-restart` | Reinicio real de escritorio con intención de pago fixture pendiente | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 5 |
| 594 | `payroll-payment-operation-pending-roles` | OWNER, aprobador y pagador RRHH, lectores y empresa2 conservan scope privado | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 18 |
| 595 | `payroll-payment-operation-reads` | Detalle y destinos en vivo fallidos/parciales/cacheados bloquean pago; recuperación manual | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 38 |
| 596 | `payroll-payment-operation-receipts` | Pago de planilla exige recibo completo; negativos y replay por interfaz | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 72 |
| 597 | `payroll-payment-operation-storage` | Fallo set/readback/remove, corrupción y cambio desde otra ventana conservan intención | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 26 |
| 598 | `pdf-negative-zero-current-143` | Exportar estados sin signo negativo cuando el importe mostrado es cero | 31. Libros, estados financieros y reportes operativos | 35 | 14 |
| 599 | `period-create-operation-lifecycle` | Alta de período: recarga, red perdida y respuesta tardía conservan intención y clave | 24. Períodos y cierre contable | 35, 38 | 16 |
| 600 | `period-create-operation-real-restart` | Período2024-11 creado una vez y recuperado tras ACK perdido/reinicio real | 24. Períodos y cierre contable | 03, 35, 38 | 5 |
| 601 | `period-create-operation-receipts` | Alta de período: recibo completo, vivo y asociado a empresa, creador y año/mes | 24. Períodos y cierre contable | 03, 35, 38 | 66 |
| 602 | `period-create-operation-roles` | Alta de período: dos lectores reales sin creación ni intención del OWNER | 24. Períodos y cierre contable | 03, 35, 38 | 10 |
| 603 | `period-create-operation-storage` | Alta de período: fallos de almacenamiento, corrupción y cambio concurrente bloquean reemplazo | 24. Períodos y cierre contable | 03, 35, 38 | 30 |
| 604 | `period-live-read-controls-lifecycle` | Períodos: lectura retenida retira cifras/acciones y respuestas tardías tras salidaSPA | 24. Períodos y cierre contable | 03, 35, 38 | 24 |
| 605 | `period-live-read-controls-reads` | Períodos: catálogo/detalle/preflight completos, vivos, consistentes y recuperables | 24. Períodos y cierre contable | 03, 35, 38 | 106 |
| 606 | `period-live-read-controls-roles` | Períodos: dos lectores403 y empresa2vacía/detalleprincipal404 conOWNER restaurado | 24. Períodos y cierre contable | 03, 35, 38 | 28 |
| 607 | `period-provision-operation-lifecycle` | Estimación: intención privada, desconexión/recarga/Volver sin autoenvío y respuesta tardía | 24. Períodos y cierre contable | 35, 38 | 14 |
| 608 | `period-provision-operation-real-restart` | Estimación real única y recuperación del recibo positivo tras reinicio | 24. Períodos y cierre contable | 35, 38 | 5 |
| 609 | `period-provision-operation-receipts` | Estimación: identidad/criterio completos, asiento68/19 y detalle por documento vivos | 24. Períodos y cierre contable | 03, 35, 38 | 42 |
| 610 | `period-provision-operation-reports153` | Reportes y PLE del corte153 después de estimación real | 24. Períodos y cierre contable | 03, 31, 35 | 38 |
| 611 | `period-provision-operation-roles` | Estimación: lectores reales403 sin intenciónOWNER; retorno y confirmación privada | 24. Períodos y cierre contable | 03, 35, 38 | 10 |
| 612 | `period-provision-operation-storage` | Estimación: fallas/corrupción/bytes concurrentes conservados y retiro comprobado | 24. Períodos y cierre contable | 03, 35, 38 | 24 |
| 613 | `period-provision-receipt-controls-lifecycle` | Estimación: solicitud retenida y respuesta tardía trasAtrás, regreso sin autoenvío | 24. Períodos y cierre contable | 35, 38 | 10 |
| 614 | `period-provision-receipt-controls-presentation` | Períodos pendientes: fotografía incierta etiquetada, totales y nuevos writers ocultos | 24. Períodos y cierre contable | 35, 38 | 10 |
| 615 | `period-provision-receipt-controls-receipts` | Estimación: resultado vivo SQL509 completo, cero coherente, días enteros y errores separados | 24. Períodos y cierre contable | 35, 38 | 88 |
| 616 | `period-provision-receipt-controls-roles` | Estimación: dos lectores reales403 sin controles; OWNER restaurado | 24. Períodos y cierre contable | 03, 35, 38 | 8 |
| 617 | `period-transition-operation-lifecycle` | Cierre/reapertura: recarga, respuesta tardía y GET de reconciliación sin repetir transición | 24. Períodos y cierre contable | 34, 35, 38 | 30 |
| 618 | `period-transition-operation-real-close-restart` | Cierre único2024-11 recuperado porGET trasACK perdido/reinicio | 24. Períodos y cierre contable | 03, 35, 38 | 5 |
| 619 | `period-transition-operation-real-reopen-restart` | Reapertura única2024-11 recuperada porGET trasACK perdido/reinicio | 24. Períodos y cierre contable | 03, 35, 38 | 5 |
| 620 | `period-transition-operation-receipts` | Cierre/reapertura: recibo completo y consulta de recuperación validan fotografía, actor y secuencia | 24. Períodos y cierre contable | 03, 34, 35, 38 | 162 |
| 621 | `period-transition-operation-roles` | Cierre: lectores reales sin intención ni verificación ajena; OWNER recuperado | 24. Períodos y cierre contable | 03, 35, 38 | 10 |
| 622 | `period-transition-operation-storage` | Cierre/reapertura: persistencia antes del POST, retiro, corrupción y cambios concurrentes | 24. Períodos y cierre contable | 34, 35, 38 | 30 |
| 623 | `ple-five-books-retry` | Error visible503 y reintento de cinco libros PLE desde UI | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 2 |
| 624 | `pos-card` | Venta de productos gravado/exonerado con tarjeta, total4.13 | 11. Punto de venta | 35 | 1 |
| 625 | `pos-cash` | Venta efectivo4.13, redondeo0.03, impresión/CPE firmado y cierre físico504.10 | 11. Punto de venta | 15, 31, 35, 38 | 5 |
| 626 | `pos-concurrent-cart-price-review` | Cambiar cantidad mientras se consultan precios y exigir revisión nueva antes del cobro | 11. Punto de venta | 35, 38 | 1 |
| 627 | `pos-current-pending-emission-failure-contract-ui` | Emisión POS pendiente: error visible, dos reintentos manuales y ninguna nueva venta ni aceptación fiscal | 11. Punto de venta | 15, 35, 38 | 1 |
| 628 | `pos-open` | Abrir sesión Lima con conteo500; POS reconoce sesión persistida | 11. Punto de venta | 03, 35 | 2 |
| 629 | `pos-payment-mixed` | Venta4.13 mixed y recuperación en historial | 11. Punto de venta | 35, 38 | 2 |
| 630 | `pos-payment-ticket` | Venta4.13 ticket y recuperación en historial | 11. Punto de venta | 35, 38 | 2 |
| 631 | `pos-payment-transfer` | Venta4.13 transfer y recuperación en historial | 11. Punto de venta | 35, 38 | 2 |
| 632 | `pos-payment-wallet` | Venta4.13 wallet y recuperación en historial | 11. Punto de venta | 35, 38 | 2 |
| 633 | `pos-pure-ticket-rounding002` | Venta4unidades exoneradas0.13: ticket0.52, efectivo0.50 y redondeo0.02 | 11. Punto de venta | 35 | 3 |
| 634 | `pos-ticket-exchange-print` | Canjear ticket existente aB0017, recuperar cuatro impresiones y descargar cuatroPDF fiscales | 11. Punto de venta | 15, 31, 35, 38 | 10 |
| 635 | `product-create-operation-actual-real-restart` | Reinicio conalta producto pendiente: actual | 06. Productos, servicios y maestros de inventario | 35, 38 | 5 |
| 636 | `product-create-operation-catalogs` | Alta de producto: catalogs | 06. Productos, servicios y maestros de inventario | 03, 35, 38 | 18 |
| 637 | `product-create-operation-image-real-restart` | Reinicio conalta producto pendiente: image | 06. Productos, servicios y maestros de inventario | 35, 38 | 5 |
| 638 | `product-create-operation-images` | Alta de producto: images | 06. Productos, servicios y maestros de inventario | 35, 38 | 34 |
| 639 | `product-create-operation-inflight` | Alta de producto: inflight | 06. Productos, servicios y maestros de inventario | 35, 38 | 18 |
| 640 | `product-create-operation-lifecycle` | Alta de producto: lifecycle | 06. Productos, servicios y maestros de inventario | 35, 38 | 14 |
| 641 | `product-create-operation-offline` | Alta de producto: offline | 06. Productos, servicios y maestros de inventario | 35, 38 | 16 |
| 642 | `product-create-operation-pending-roles` | Alta de producto: pending-roles | 06. Productos, servicios y maestros de inventario | 03, 35, 38 | 14 |
| 643 | `product-create-operation-receipts` | Alta de producto: receipts | 06. Productos, servicios y maestros de inventario | 03, 31, 35, 38 | 72 |
| 644 | `product-create-operation-storage` | Alta de producto: storage | 06. Productos, servicios y maestros de inventario | 03, 35, 38 | 24 |
| 645 | `product-deactivate-operation-catalog` | Baja de producto: catalog | 06. Productos, servicios y maestros de inventario | 34, 35, 38 | 30 |
| 646 | `product-deactivate-operation-inflight` | Baja de producto: inflight | 06. Productos, servicios y maestros de inventario | 35, 38 | 10 |
| 647 | `product-deactivate-operation-lifecycle` | Baja de producto: lifecycle | 06. Productos, servicios y maestros de inventario | 35, 38 | 14 |
| 648 | `product-deactivate-operation-offline` | Baja de producto: offline | 06. Productos, servicios y maestros de inventario | 35, 38 | 8 |
| 649 | `product-deactivate-operation-pending-restart` | Reinicio nativo con baja pendiente fixture sin envío automático | 06. Productos, servicios y maestros de inventario | 35, 38 | 5 |
| 650 | `product-deactivate-operation-reads` | Baja de producto: reads | 06. Productos, servicios y maestros de inventario | 35, 38 | 28 |
| 651 | `product-deactivate-operation-real` | Baja real del maestro físico sinstock, ACK perdido, reinicio y replay sin borrar historial | 06. Productos, servicios y maestros de inventario | 35, 38 | 6 |
| 652 | `product-deactivate-operation-receipts` | Baja de producto: receipts | 06. Productos, servicios y maestros de inventario | 03, 15, 31, 34, 35, 38 | 136 |
| 653 | `product-deactivate-operation-roles` | Baja de producto: roles | 06. Productos, servicios y maestros de inventario | 03, 34, 35, 38 | 12 |
| 654 | `product-deactivate-operation-storage` | Baja de producto: storage | 06. Productos, servicios y maestros de inventario | 34, 35, 38 | 30 |
| 655 | `product-service-classification-contract` | Enviar y conservar clasificación de servicio,producto físico ysinstock | 06. Productos, servicios y maestros de inventario | 34, 35, 38 | 50 |
| 656 | `product-service-native-restart` | Conservar el servicio después de reiniciar el proceso Windows | 06. Productos, servicios y maestros de inventario | 35, 38 | 2 |
| 657 | `product-service-real-create` | Crear un SKU de servicio sin stock desde el escritorio | 06. Productos, servicios y maestros de inventario | 35 | 3 |
| 658 | `product-service-real-edit` | Editar la descripción del servicio conservando su clasificación | 06. Productos, servicios y maestros de inventario | 35 | 3 |
| 659 | `product-service-roles-stock-404` | Rechazar conversión con existencias yverificar lector/empresa sobre el servicio | 06. Productos, servicios y maestros de inventario | 03, 35 | 14 |
| 660 | `product-update-operation-actual-real-restart` | Reinicio conedición pendiente: actual | 06. Productos, servicios y maestros de inventario | 35, 38 | 5 |
| 661 | `product-update-operation-delete-real-restart` | Reinicio conedición pendiente: delete | 06. Productos, servicios y maestros de inventario | 35, 38 | 5 |
| 662 | `product-update-operation-image-storage` | Edición de producto: image-storage | 06. Productos, servicios y maestros de inventario | 35, 38 | 12 |
| 663 | `product-update-operation-images` | Edición de producto: images | 06. Productos, servicios y maestros de inventario | 35, 38 | 52 |
| 664 | `product-update-operation-inflight` | Edición de producto: inflight | 06. Productos, servicios y maestros de inventario | 35, 38 | 20 |
| 665 | `product-update-operation-lifecycle` | Edición de producto: lifecycle | 06. Productos, servicios y maestros de inventario | 35, 38 | 14 |
| 666 | `product-update-operation-offline` | Edición de producto: offline | 06. Productos, servicios y maestros de inventario | 35, 38 | 16 |
| 667 | `product-update-operation-pending-roles` | Edición de producto: pending-roles | 06. Productos, servicios y maestros de inventario | 03, 35, 38 | 14 |
| 668 | `product-update-operation-reads` | Edición de producto: reads | 06. Productos, servicios y maestros de inventario | 03, 35, 38 | 48 |
| 669 | `product-update-operation-receipts` | Edición de producto: receipts | 06. Productos, servicios y maestros de inventario | 03, 31, 35, 38 | 76 |
| 670 | `product-update-operation-storage` | Edición de producto: storage | 06. Productos, servicios y maestros de inventario | 03, 35, 38 | 26 |
| 671 | `product-update-operation-upload-real-restart` | Reinicio conedición pendiente: upload | 06. Productos, servicios y maestros de inventario | 35, 38 | 5 |
| 672 | `purchase-approval` | Aprobar OC con rol COMPRAS; recepción posterior confirma continuidad | 13. Compras: cotización y orden | 03, 35 | 1 |
| 673 | `purchase-current-pending-return-cancel-real` | Anular borrador de devolución, recargar y conservar stock sin evento económico | 14. Recepciones y devoluciones al proveedor | 35, 38 | 1 |
| 674 | `purchase-decisions-print` | OC28.32: rechazo segregado con error/retry, cancelación independiente y PDF de detalle | 13. Compras: cotización y orden | 03, 31, 35, 38 | 12 |
| 675 | `purchase-mixed-quote-complete-live-contract` | Bloquear lecturas y recibos vacíos/ajenos/cacheados antes de declarar éxito | 13. Compras: cotización y orden | 34, 35, 38 | 14 |
| 676 | `purchase-mixed-quote-conversion-ack` | Convertir a OC con respuesta perdida y recuperar una sola orden | 13. Compras: cotización y orden | 35, 38 | 2 |
| 677 | `purchase-mixed-quote-distinct-approval` | Aprobar cotización de gravado/exonerado/precio0 con actor distinto | 13. Compras: cotización y orden | 03, 31, 35, 38 | 1 |
| 678 | `purchase-mixed-quote-native-restart` | Reinicio real conserva cotización aprobada y enlace a única OC | 13. Compras: cotización y orden | 35, 38 | 2 |
| 679 | `purchase-mixed-quote-order-roles-export` | Permisos y aislamiento reales de cotización/OC vinculadas y CSV actuales | 13. Compras: cotización y orden | 03, 31, 35, 38 | 12 |
| 680 | `purchase-mixed-quote-send` | Enviar cotización mixta de tres líneas desde UI y rechazar autoaprobación | 13. Compras: cotización y orden | 35, 38 | 2 |
| 681 | `purchase-order` | OC20 unidades×24, total566.40, alta por asistente y consulta posterior | 13. Compras: cotización y orden | 35 | 2 |
| 682 | `purchase-order-approval-history-live` | Historial de aprobación confirmado vivo, de la misma empresa y orden, con reintento propio | 13. Compras: cotización y orden | 03, 15, 35, 38 | 16 |
| 683 | `purchase-order-approved-current-print` | Imprimir estado actual APROBADA/3líneas/precio0/total1.19 y exportar cabecera filtrada | 13. Compras: cotización y orden | 03, 31, 35 | 2 |
| 684 | `purchase-order-approved-native-restart` | Reinicio real del mismoejecutable recupera orden APROBADA sin nuevaacción | 13. Compras: cotización y orden | 35, 38 | 1 |
| 685 | `purchase-order-approved-role-history` | Leer aprobación única con actor/comentario y permisos reales | 13. Compras: cotización y orden | 03, 31, 35 | 12 |
| 686 | `purchase-order-complete-action-receipts` | Aprobar/rechazar/cancelar bloquean recibos incompletos/ajenos/cacheados y conservan formularios | 13. Compras: cotización y orden | 35, 38 | 14 |
| 687 | `purchase-order-complete-live-read` | DetalleOC bloquea lecturas incompletas/cacheadas/ajenas y recupera la misma orden por UI | 13. Compras: cotización y orden | 31, 35, 38 | 12 |
| 688 | `purchase-order-country-error-recovery` | Consulta fiscal403/429/503 bloquea módulos y recupera ruta sin falsoasistente | 04. Identidad, parámetros, sucursales y series | 03, 35, 38 | 12 |
| 689 | `purchase-order-create-inflight` | Salir con alta retenida y descartar el recibo tardío | 13. Compras: cotización y orden | 34, 35, 38 | 10 |
| 690 | `purchase-order-create-lifecycle` | Recuperar la orden pendiente tras recarga y Volver | 13. Compras: cotización y orden | 34, 35, 38 | 12 |
| 691 | `purchase-order-create-offline` | Recuperar el alta de OC tras fallo de red sin encolarla | 13. Compras: cotización y orden | 35, 38 | 8 |
| 692 | `purchase-order-create-pending-restart` | Recuperar el alta pendiente después de reiniciar Windows | 13. Compras: cotización y orden | 35, 38, 39 | 5 |
| 693 | `purchase-order-create-pending-roles` | Separar la orden pendiente por actor y empresa | 13. Compras: cotización y orden | 03, 35, 38 | 16 |
| 694 | `purchase-order-create-receipts` | Rechazar recibos incompletos y confirmar la fotografía completa del alta de OC | 13. Compras: cotización y orden | 03, 31, 35, 38 | 84 |
| 695 | `purchase-order-create-storage` | Conservar la orden ante corrupción y fallos de almacenamiento | 13. Compras: cotización y orden | 03, 34, 35, 38 | 32 |
| 696 | `purchase-order-existing-five-corpus` | Cinco órdenes existentes conservan estados/importes/cantidades recibidas y pendientes | 13. Compras: cotización y orden | 03, 31, 35, 38 | 12 |
| 697 | `purchase-order-history-current-five-documents` | Leer historial real de las cinco órdenes actuales y expandir las dos recepciones cerradas | 13. Compras: cotización y orden | 03, 35 | 12 |
| 698 | `purchase-order-history-current-roles` | Historial por permisos y empresa actuales tras cambios reales de sesión | 13. Compras: cotización y orden | 03, 31, 35 | 10 |
| 699 | `purchase-order-live-roles-isolation` | Permisos y aislamiento reales del detalle de la ordenmixta | 13. Compras: cotización y orden | 03, 31, 35 | 8 |
| 700 | `purchase-order-mixed-approval-ack` | AprobarOCmixta con actor distinto y recuperar ACK perdido sin segundo commit | 13. Compras: cotización y orden | 03, 35, 38 | 2 |
| 701 | `purchase-order-print-current-five` | Imprimir cinco órdenes actuales con totales completos y precio0, sin paneles operativos ni tasa global falsa | 13. Compras: cotización y orden | 03, 31, 35 | 5 |
| 702 | `purchase-order-real-self-approval` | Rechazar autoaprobación real del creador conservando orden y comentarios | 13. Compras: cotización y orden | 35 | 1 |
| 703 | `purchase-order-receipt-history-live` | Recepciones vivas completas de la misma orden, error visible y reintento propio | 13. Compras: cotización y orden | 35, 38 | 16 |
| 704 | `purchase-precision-recovery-current` | Sobreprecisión de cantidad/precio bloqueada, catálogos503/retry, rectificación de líneas en borrador y fecha civil | 13. Compras: cotización y orden | 35, 38 | 6 |
| 705 | `purchase-quote-cycle-current` | Cotización0.12×24: alta/retry, cabecera, envío, creador denegado, aprobación distinta, conversión/retry, edición deOC, cancelación yCSV | 13. Compras: cotización y orden | 31, 35, 38 | 13 |
| 706 | `purchase-quote-mixed-tax-zero-price` | Tres líneas gravada/exonerada/precio0: subtotal1.15/IGV.03/total1.18 y recálculo posterior1.19 | 13. Compras: cotización y orden | 35, 38 | 6 |
| 707 | `purchase-quote-multiline-current-page-csv` | Exportar CSV real de página filtrada del10oct con cotización1.19 y ocho columnas | 13. Compras: cotización y orden | 03, 31, 35, 38 | 1 |
| 708 | `purchase-quote-multiline-real-role-isolation` | Lector inventario403/empresa2real404 sin datos o editor; regresoOWNER recupera tres líneas | 13. Compras: cotización y orden | 03, 31, 35, 38 | 11 |
| 709 | `purchase-quote-native-multiple-quantity-edit` | Editar dos cantidades desde escritorio; sobreprecisión sinPUT,503 previo conserva tres líneas y200 real aplicado una vez | 13. Compras: cotización y orden | 35, 38 | 5 |
| 710 | `purchase-quote-three-lines-create-remove-before-save` | Agregarcuatro líneas/quitar temporal en asistente; crear una cotización real de tres productos distintos | 13. Compras: cotización y orden | 35, 38 | 3 |
| 711 | `purchase-read-recovery-current` | Listados/catálogos y detalle503 con error/reintento, proveedor indisponible y respuesta tardía de filtros | 13. Compras: cotización y orden | 35, 38 | 6 |
| 712 | `purchase-receipt-operation-inflight` | Salir con petición retenida y descartar su acuse tardío | 14. Recepciones y devoluciones al proveedor | 34, 35, 38 | 18 |
| 713 | `purchase-receipt-operation-lifecycle` | Recuperar la creación o el cierre pendiente tras recarga y Volver | 14. Recepciones y devoluciones al proveedor | 34, 35, 38 | 18 |
| 714 | `purchase-receipt-operation-offline` | Recuperar recepción sin usar la cola genérica | 14. Recepciones y devoluciones al proveedor | 34, 35, 38 | 18 |
| 715 | `purchase-receipt-operation-pending-roles` | Separar la recepción pendiente por empresa, actor y orden | 14. Recepciones y devoluciones al proveedor | 03, 35, 38 | 16 |
| 716 | `purchase-receipt-operation-receipts` | Confirmar creación y cierre sólo con la recepción completa | 14. Recepciones y devoluciones al proveedor | 03, 31, 35, 38 | 106 |
| 717 | `purchase-receipt-operation-restart-close` | Recuperar etapa CLOSE de recepción tras reiniciar Windows | 14. Recepciones y devoluciones al proveedor | 35, 38, 39 | 5 |
| 718 | `purchase-receipt-operation-restart-create` | Recuperar etapa CREATE de recepción tras reiniciar Windows | 14. Recepciones y devoluciones al proveedor | 35, 38, 39 | 5 |
| 719 | `purchase-receipt-operation-storage` | Conservar la recepción ante corrupción y fallos de almacenamiento | 14. Recepciones y devoluciones al proveedor | 03, 34, 35, 38 | 42 |
| 720 | `purchase-reception` | Recibir/cerrar12 y después8; OC persiste12/8pendiente y20/0 | 14. Recepciones y devoluciones al proveedor | 03, 35, 38 | 4 |
| 721 | `purchase-return-current-feedback-native` | Windows: error y recibo ajeno no confirman devolución; recibo válido conserva mensaje después de actualizar el detalle | 14. Recepciones y devoluciones al proveedor | 34, 35, 38 | 2 |
| 722 | `rce-operational-current` | RegistroCompras y Excel: originales339.84/226.56 y NC negativas113.28/118 separados | 31. Libros, estados financieros y reportes operativos | 35 | 3 |
| 723 | `recruitment-decisions` | Registrar candidatos independientes y guardar rechazo/contratación como estados de selección | 33. Recursos humanos: personas, contratos y solicitudes | 35 | 6 |
| 724 | `recruitment-read-recovery-filters-roles` | Carga completa de candidatos/vacantes/departamentos, filtros por estado/vacante y aislamiento en el mismo navegador | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35, 38 | 26 |
| 725 | `registers-permission-isolation` | Consignaciones y consolidación: vendedor403 y segunda empresa sin registros/definiciones ajenos | 03. Usuarios, roles, permisos y sesiones | 30, 35 | 6 |
| 726 | `revaluation-live-read-calendar` | Revaluación y Consolidación: fechas por defecto del día/año civil de Perú después de19:00 Lima | 29. Monedas, tipos de cambio y revaluación | 30, 35, 38 | 10 |
| 727 | `revaluation-live-read-isolation` | Revaluación: secundaria real con vacío confirmado propio y sin posiciones ajenas | 29. Monedas, tipos de cambio y revaluación | 03, 15, 30, 35, 38 | 8 |
| 728 | `revaluation-live-read-lifecycle` | Revaluación: retiro de simulación pendiente y respuestas/errores antiguos descartados tras fecha o pantalla | 29. Monedas, tipos de cambio y revaluación | 30, 35, 38 | 10 |
| 729 | `revaluation-live-read-reads` | Revaluación: simulación completa/viva, fuentes monetarias, cotizaciones, importes/valoraciones y totales; snapshot económico coincide con SQL readonly | 29. Monedas, tipos de cambio y revaluación | 03, 30, 35, 38 | 76 |
| 730 | `revaluation-live-read-restart` | Revaluación: reinicio físico separado y simulación completa en lectura sin registro/reversa | 29. Monedas, tipos de cambio y revaluación | 30, 35, 38 | 6 |
| 731 | `revaluation-live-read-roles` | Revaluación: dos roles reales con permisos observados, sin registro y retorno OWNER | 29. Monedas, tipos de cambio y revaluación | 03, 30, 35, 38 | 10 |
| 732 | `revaluation-registration-operation-actor-held` | Registro de revaluación: writer retenido y respuesta completa tras cambio real de actor no retiran ni exponen intención OWNER | 29. Monedas, tipos de cambio y revaluación | 03, 35, 38 | 10 |
| 733 | `revaluation-registration-operation-capture` | Registro de revaluación: lectura actual de dos posiciones para fotografía conservada, sin registro/reversa | 29. Monedas, tipos de cambio y revaluación | 35 | 1 |
| 734 | `revaluation-registration-operation-isolation` | Registro de revaluación: empresa secundaria real no ve ni envía intención primaria y retorno conserva cuerpo/clave | 29. Monedas, tipos de cambio y revaluación | 03, 35, 38 | 8 |
| 735 | `revaluation-registration-operation-lifecycle` | Registro de revaluación: respuesta tardía tras navegación conserva intención, regreso y retry manual | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 10 |
| 736 | `revaluation-registration-operation-receipts` | Registro de revaluación: recibo completo, mismo cuerpo/clave, parcial/caché/cola/409 y recarga sin autoenvío | 29. Monedas, tipos de cambio y revaluación | 03, 34, 35, 38 | 40 |
| 737 | `revaluation-registration-operation-restart` | Registro de revaluación: reinicio físico separado con intención ambigua, mismos bytes y retry manual sólo ante recibo completo | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 5 |
| 738 | `revaluation-registration-operation-roles` | Registro de revaluación: dos lectores reales no acceden/envían intención privada OWNER, regreso con mismos datos | 29. Monedas, tipos de cambio y revaluación | 03, 35, 38 | 13 |
| 739 | `revaluation-registration-operation-storage` | Registro de revaluación: solicitud/recibo archivados antes del retiro, cuota/corrupción y recuperación manual | 29. Monedas, tipos de cambio y revaluación | 35, 38 | 14 |
| 740 | `rma-current-flow` | Devolución2unidades: aprobación distinta, recepción parcial/reversa/nueva recepción, NC94.40 | 10. Devoluciones de clientes, notas y saldo a favor | 03, 31, 35, 38 | 9 |
| 741 | `role-operational-create-assign` | Crear rol lector con ACK perdido/retry, rechazar nombre duplicado, asignar usuario y comprobar lectura/denegación/empresa2 | 03. Usuarios, roles, permisos y sesiones | 35, 38 | 8 |
| 742 | `role-permission-catalog-recovery` | Bloquear alta durante lectura fallida de permisos; reintentar, distinguir vacío válido y descartar fallo tardío de diálogo cerrado | 03. Usuarios, roles, permisos y sesiones | 35, 38 | 6 |
| 743 | `roles-users` | Crear usuarios/roles y asignar permisos operativos con recarga | 03. Usuarios, roles, permisos y sesiones | 34, 35 | 11 |
| 744 | `rrhh-approve` | Aprobar planilla con persona distinta y recargar | 34. Planilla, vacaciones remuneradas y EPS | 35 | 1 |
| 745 | `rrhh-benefits-four-sources-live-recovery` | Liquidaciones/CTS: cuatro fuentes completas en vivo, retiro de datos/acciones ante fallo y retry con formulario conservado | 35. CTS y liquidaciones | 38 | 2 |
| 746 | `rrhh-benefits-raw-oracle-eight-rows` | Estados/importes de cinco liquidaciones y tres CTS contrastados con filas crudas independientes | 35. CTS y liquidaciones |  | 2 |
| 747 | `rrhh-benefits-roles-isolation-late` | Aprobador/pagador segregados, lector403, empresa2 vacía y consulta tardía tras navegación por menú | 35. CTS y liquidaciones | 03, 38 | 4 |
| 748 | `rrhh-boletas` | Descargar boletas HTML y renderizar impresiónPDF de Elena/Mario | 34. Planilla, vacaciones remuneradas y EPS | 31, 35 | 2 |
| 749 | `rrhh-calculation-confirmation-controls` | Confirmación completa de cálculo por identidad original, empleados, campos operativos, importes y conceptos | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 10 |
| 750 | `rrhh-calculation-physical-restart-late-lock` | Reinicio físico Windows, respuesta tardía y bloqueo simultáneo entre pestañas | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 9 |
| 751 | `rrhh-calculation-private-recovery` | Recuperación privada de cálculo tras409/503/recarga/navegación/cambio de usuario/corrupción | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 16 |
| 752 | `rrhh-calculation-resolution-controls` | Conciliar cálculo confirmado o abandonar solicitud con archivo del recibo antes de retirar pendiente | 34. Planilla, vacaciones remuneradas y EPS | 15, 35, 38 | 12 |
| 753 | `rrhh-calculation-source-late` | Fuentes tardías de un modal cerrado no reemplazan la lectura vigente | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 2 |
| 754 | `rrhh-calculation-source-recovery` | Reintento de fuentes conserva los campos manuales y actualiza el sueldo confirmado | 34. Planilla, vacaciones remuneradas y EPS | 15, 35, 38 | 24 |
| 755 | `rrhh-calculation-source-roles` | Lectores reales sin permiso de cálculo no abren la calculadora | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 4 |
| 756 | `rrhh-calculation-source-salary` | Calculadora con fuentes completas por empresa y sueldo del contrato vigente en el período | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 26 |
| 757 | `rrhh-cese31-current` | Cese31dic dos meses1200: CTS200/vacaciones200/grati400/bonus36; aprobación segregada y pago836 | 35. CTS y liquidaciones | 03, 38 | 6 |
| 758 | `rrhh-cross-independent-contracts-requests` | Empleado independiente, contratos agosto3000/septiembre3300 y dos solicitudes superpuestas aprobadas desdeUI | 34. Planilla, vacaciones remuneradas y EPS | 35 | 1 |
| 759 | `rrhh-cross-report-boleta-real-html-visual` | Descargar reporte y boleta de septiembre desdeUI; revisar sus dos páginas impresas | 34. Planilla, vacaciones remuneradas y EPS | 31, 35, 38 | 2 |
| 760 | `rrhh-cross-september-unique-days-salary-recovery` | Septiembre: unión de vacaciones superpuestas3d, aumento3300, cuatro fallos de empleados/retry y selección individual | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 1 |
| 761 | `rrhh-cross-source503-keeps-draft` | Cálculo tras fallo503 de solicitudes conserva borrador sin detalles; retry conserva identidad de alta | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 1 |
| 762 | `rrhh-cts` | Calcular CTS mayo200 por cada empleado y depositar con pagador separado | 35. CTS y liquidaciones | 38 | 5 |
| 763 | `rrhh-cts-november-historical` | Declarar gratificación julio2025 real900+bonus81, calcular CTS noviembre975, depositar por otro actor y recargar | 35. CTS y liquidaciones | 03, 38 | 3 |
| 764 | `rrhh-current-calculator-complete-source-regression` | Fuentes actuales de calculadora: contrato vigente y rechazo de lectura incompleta | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 44 |
| 765 | `rrhh-current-calculator-source-recovery-regression` | Recuperación actual de fuentes de calculadora y lectores reales sin calcular | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 20 |
| 766 | `rrhh-current-contract-finalize-real` | Finalizar contrato con motivo, recargar y conservar historia del empleado | 33. Recursos humanos: personas, contratos y solicitudes | 35 | 1 |
| 767 | `rrhh-current-contract-renew-real` | Renovar contrato temporal por dos meses y verificar fecha tras recarga | 33. Recursos humanos: personas, contratos y solicitudes | 35 | 1 |
| 768 | `rrhh-current-draft-payroll-edit-real` | Editar observaciones de borrador sin calcular y conservar período tras recarga | 34. Planilla, vacaciones remuneradas y EPS | 35 | 1 |
| 769 | `rrhh-current-official-evidence-contract-ui` | PLAME: evidencia vacía no envía; error conserva campos, cuerpo y clave | 36. PLAME, T-Registro y contexto por país | 35, 38 | 1 |
| 770 | `rrhh-current-payroll-create-source-regression` | Nueva planilla: fuentes actuales por período y sueldo con lectores reales | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 48 |
| 771 | `rrhh-detail-boleta-completeness-boleta` | Boletas HTML actuales con todos los conceptos, empresa, empleado y neto verificados | 34. Planilla, vacaciones remuneradas y EPS | 31, 35, 38 | 24 |
| 772 | `rrhh-detail-boleta-completeness-detail` | Detalle de planilla con fuentes completas de empleados y conceptos; incompleto bloquea | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 50 |
| 773 | `rrhh-detail-boleta-completeness-download` | Fuente de boleta incompleta bloquea archivo; reintento explícito descarga HTML actual completo | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 32 |
| 774 | `rrhh-detail-boleta-completeness-retry` | Reintento de detalle recupera fuentes completas actuales sin mostrar datos parciales | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 28 |
| 775 | `rrhh-employees` | Alta de empleado/contrato ONP1200 y ficha EPS/EsSalud antes de primera nómina | 33. Recursos humanos: personas, contratos y solicitudes | 15, 34, 35 | 5 |
| 776 | `rrhh-eps-april-legacy-intent-confirmation` | Abril: pago real1740 con ACK perdido; confirmar explícitamente intención original tras falso éxito local y legacy400 | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 1 |
| 777 | `rrhh-eps-carry-boletas-reports-oracle` | Tres fotografías EPS: detalle/oracle, seisHTML descargados y seisPDF/seis páginas revisadas | 34. Planilla, vacaciones remuneradas y EPS | 31, 35 | 2 |
| 778 | `rrhh-eps-carry-chain-no-current-covered-workers` | Saldo ERP sin afiliados actuales:320→140→0; segundo formulario con origen consumido recibe409 y recupera el mismo borrador | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 2 |
| 779 | `rrhh-eps-historical-origin320` | Cobertura histórica declarada crea fotografía de febrero: generado500/aplicado180/saldo320 | 34. Planilla, vacaciones remuneradas y EPS | 35 | 1 |
| 780 | `rrhh-eps-march-payment-lost-ack-replay` | Marzo: pérdida deACK después del commit, mismo modal reintenta misma clave y confirma pago único | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 1 |
| 781 | `rrhh-eps-origin-live-read-writer-block` | Origen de saldo EPS: consulta completa en vivo, error/retry conserva selección y bloquea cálculo/alta | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 2 |
| 782 | `rrhh-eps-paid-photos-bank-ledger-exports` | Marzo/abril pagados: fotografía, cuatro asientos y banco contrastados con filas crudas; ochoPDF/ocho páginas yCSV34filas | 34. Planilla, vacaciones remuneradas y EPS | 31, 35 | 2 |
| 783 | `rrhh-eps-paid-roles-isolation` | Fotografías pagadas con aprobador/pagador, lector403, empresa2 vacía real yOWNER restaurado | 34. Planilla, vacaciones remuneradas y EPS | 03, 35 | 2 |
| 784 | `rrhh-eps-two-separate-approvals` | Aprobar marzo y abril una vez con actor separado; conservar conceptos y créditoEPS | 34. Planilla, vacaciones remuneradas y EPS | 03, 35 | 2 |
| 785 | `rrhh-historical-normative-ui` | Configurar normativa2025Oct/Nov/Dic, versionar noviembre y recuperar respuesta perdida | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 7 |
| 786 | `rrhh-liquidation-current` | Cese7oct: cálculo1945.31 con CTSmayo depositada y gratificación julio realmente pagada | 35. CTS y liquidaciones |  | 1 |
| 787 | `rrhh-liquidation-overlap-anniversary-setup` | Alta independienteDiana, contratoONP2000 desde1oct2025 y tres solicitudes aprobadas cruzando aniversario/cese | 35. CTS y liquidaciones |  | 1 |
| 788 | `rrhh-liquidation-overlap-cese-unique-days-recovery` | Cálculo completo tras503/200incompleto: fechas únicas al cruzar aniversario y solicitud recortada al cese | 35. CTS y liquidaciones | 38 | 4 |
| 789 | `rrhh-liquidation-overlap-negative-baseline` | Fallo503 de vacaciones no crea fotografía; baseline7oct reproduce8d sumados en vez de7fechas únicas y permanece calculado | 35. CTS y liquidaciones | 03, 38 | 2 |
| 790 | `rrhh-liquidation-pay-reverse` | Transferencia1945.31: ACK perdido/retry, reversión y pago nuevo trazables | 35. CTS y liquidaciones | 03, 38 | 3 |
| 791 | `rrhh-liquidation-segregation` | Calculador no confirma su propia liquidación; otroactor aplica cese | 35. CTS y liquidaciones | 03 | 2 |
| 792 | `rrhh-ordinary-financial-current` | Borrador tras fallo previo al cálculo, recuperar, aprobar/pagar1044 con tres actores y descargar reporte | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 5 |
| 793 | `rrhh-pay` | Pagar planilla completa3814 por banco con pagador distinto y recargar | 34. Planilla, vacaciones remuneradas y EPS | 35 | 1 |
| 794 | `rrhh-payment-late-generation` | Cerrar/reabrir pago y recibir respuesta anterior no reemplaza el error actual | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 2 |
| 795 | `rrhh-payment-live-two-sources-recovery` | Pago: detalle y destinos completos en vivo; fallos retiran importes/acciones y retry conserva cuenta/referencia | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 4 |
| 796 | `rrhh-payroll-completeness-catalog` | Listado de planillas completo por empresa; fuentes incompletas bloquean | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 28 |
| 797 | `rrhh-payroll-completeness-empty` | Vacío completo de empresa actual y secundaria distinguido de fuente desconocida | 34. Planilla, vacaciones remuneradas y EPS | 03, 35 | 4 |
| 798 | `rrhh-payroll-completeness-eps` | Fuentes EPS completas, recuperación y selección no disponible conservan campos y bloquean cálculo | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 18 |
| 799 | `rrhh-payroll-completeness-retry` | Reintento manual recupera el catálogo actual sin escrituras | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 26 |
| 800 | `rrhh-payroll-create-bound-receipt-controls` | Recibos completos de alta y cálculo ligados al cuerpo original y dos UUID reservados | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 12 |
| 801 | `rrhh-payroll-create-complete-source` | Nueva planilla requiere fuentes completas por empresa/contrato vigente/sueldo conocido | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 18 |
| 802 | `rrhh-payroll-create-held-session-change` | Cambio real de sesión por UI mientras una respuesta de alta/cálculo permanece retenida | 34. Planilla, vacaciones remuneradas y EPS | 03, 35 | 12 |
| 803 | `rrhh-payroll-create-late-web-lock-roles-native-restart` | Respuestas tardías, exclusión de pestañas web, lectores reales y reinicio físico Windows | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 14 |
| 804 | `rrhh-payroll-create-private-staged-recovery` | Recuperación privada por empresa/actor de alta y cálculo tras409/503/cierre/recarga | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 12 |
| 805 | `rrhh-payroll-create-real-tcp-recovery` | Fallo TCP local real antes de API conserva alta/cálculo y permite conciliación manual | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 12 |
| 806 | `rrhh-payroll-create-resolution-archive-controls` | Conciliación por etapas o abandono seguro con archivo de recibo antes de retirar pendiente | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 10 |
| 807 | `rrhh-payroll-create-source-late` | Respuesta tardía del contrato antiguo no reemplaza fuentes/campos deNueva planilla reabierta | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 6 |
| 808 | `rrhh-payroll-create-source-recovery-period` | Nueva planilla conserva campos del mismo período yrevalida fuente/retry/permisos | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 12 |
| 809 | `rrhh-payroll-no-offline-success` | Pago sin red/503 conserva intención y referencia; ninguna confirmación local ni cola nueva | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 2 |
| 810 | `rrhh-payroll-paid-html-pdf-visual` | Reporte y boleta pagados de diciembre desdeUI; PDF derivados y páginas revisadas individualmente | 34. Planilla, vacaciones remuneradas y EPS | 31, 35, 38 | 2 |
| 811 | `rrhh-payroll-reads-errors-recovery` | Listado, detalle, reporte y boleta: errores503/200incompleto/dato inválido/red; recuperación desdeUI sin falso vacío ni archivos incompletos | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 2 |
| 812 | `rrhh-payroll-reads-late-replies` | Respuestas tardías del listado/detalle/reporte/boleta no sustituyen consulta nueva ni descargan después de salir | 34. Planilla, vacaciones remuneradas y EPS | 31, 35, 38 | 2 |
| 813 | `rrhh-payroll-reads-roles-raw-oracle` | Ocho planillas contra filas crudas; aprobador/pagador consultan, lector403 y empresa2vacía; OWNER recupera corte | 34. Planilla, vacaciones remuneradas y EPS | 03, 35 | 4 |
| 814 | `rrhh-personalized-july` | Crear/calcular planilla personalizada julio: gratificación800, bonus54/72, netos1898/1916 | 34. Planilla, vacaciones remuneradas y EPS | 15, 31, 35, 36 | 9 |
| 815 | `rrhh-plame` | Guardar fichas/jornada208h, congelar versión y descargarZIP real conRP/CSV/EPS | 36. PLAME, T-Registro y contexto por país | 15, 31, 34, 35 | 6 |
| 816 | `rrhh-recruitment-area-candidate` | Primera área desdeUI, vacante, candidato y edición de experiencia/estado civil/entrevista | 33. Recursos humanos: personas, contratos y solicitudes | 35 | 6 |
| 817 | `rrhh-report-atomic-read-recovery` | Consultar indicadores de seis empleados y recuperar dos lecturas ante503/respuesta incompleta/fila inválida | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35, 38 | 13 |
| 818 | `rrhh-report-independent-employee-lifecycle` | Alta de empleado independiente asignado al área, inactivación explícita y reporte que conserva historia | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35, 38 | 4 |
| 819 | `rrhh-report-roles-isolation` | Retirar indicadores al lector403, mantener denegación sin red y distinguir empresa secundaria vacía | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35, 38 | 4 |
| 820 | `rrhh-request-actual-medical-create` | Crear descanso médico de tres días y recuperar un commit tras reiniciar Windows | 33. Recursos humanos: personas, contratos y solicitudes | 35, 38 | 7 |
| 821 | `rrhh-request-actual-medical-decide` | Aprobar el descanso médico y recuperar un commit tras reiniciar Windows | 33. Recursos humanos: personas, contratos y solicitudes | 35, 38 | 7 |
| 822 | `rrhh-request-actual-other-types` | Crear licencia,compensación yotro tipo;aprobar dos yrechazar uno | 33. Recursos humanos: personas, contratos y solicitudes | 03, 34, 35, 38 | 13 |
| 823 | `rrhh-request-actual-six-type-corpus` | Consultar las doce solicitudes reales con seis tipos y fechas civiles | 33. Recursos humanos: personas, contratos y solicitudes | 35, 38 | 18 |
| 824 | `rrhh-request-actual-variant-roles` | Repetir permisos yempresa sobre el nuevo corte de doce solicitudes | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35 | 12 |
| 825 | `rrhh-request-write-durable-lifecycle` | Conservar cuerpo y clave durante recarga y Volver | 33. Recursos humanos: personas, contratos y solicitudes | 34, 35, 38 | 32 |
| 826 | `rrhh-request-write-late-back` | Descartar acuses tardíos al salir de la pantalla | 33. Recursos humanos: personas, contratos y solicitudes | 34, 35, 38 | 20 |
| 827 | `rrhh-request-write-native-pending-restart` | Recuperar una decisión pendiente tras reiniciar el proceso Windows | 33. Recursos humanos: personas, contratos y solicitudes | 35, 38 | 5 |
| 828 | `rrhh-request-write-offline` | Conservar la operación sin pasarla a cola genérica | 33. Recursos humanos: personas, contratos y solicitudes | 35, 38 | 20 |
| 829 | `rrhh-request-write-read-role-regression` | Repetir lectura viva, carga, vacío y roles con el escritor protegido | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35, 38 | 114 |
| 830 | `rrhh-request-write-receipts` | Confirmar recibos de solicitudes, aprobaciones y rechazos | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35, 38 | 106 |
| 831 | `rrhh-request-write-storage` | Preservar corrupción, fallo de almacenamiento y cambio durante el recibo | 33. Recursos humanos: personas, contratos y solicitudes | 03, 34, 35, 38 | 40 |
| 832 | `rrhh-requests-current` | Vacaciones5d aprobadas y permiso1d rechazado; búsqueda, entrada y salida persistidas | 33. Recursos humanos: personas, contratos y solicitudes | 35 | 7 |
| 833 | `rrhh-requests-current-live-read` | Validar solicitudes y empleados vivos antes de publicar filas, conteos o controles | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35, 38 | 76 |
| 834 | `rrhh-requests-current-loading-empty` | Retirar datos y controles durante carga y distinguir un vacío confirmado | 33. Recursos humanos: personas, contratos y solicitudes | 03, 15, 35 | 10 |
| 835 | `rrhh-requests-current-native-restart` | Recuperar lecturas RRHH al reiniciar Windows | 33. Recursos humanos: personas, contratos y solicitudes | 35, 38 | 2 |
| 836 | `rrhh-requests-current-roles` | Aislar RRHH por usuario y empresa con datos reales | 33. Recursos humanos: personas, contratos y solicitudes | 03, 35 | 12 |
| 837 | `rrhh-segregation` | Calculador no puede aprobar su propia planilla | 34. Planilla, vacaciones remuneradas y EPS | 03, 35 | 1 |
| 838 | `rrhh-tail-cap-payroll-complete` | Calcular, aprobar, pagar, descargar/imprimir boleta y generarPLAME: Luis octubre | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 36, 38 | 6 |
| 839 | `rrhh-tail-payroll-complete` | Calcular, aprobar, pagar, descargar/imprimir boleta y generarPLAME: Ana diciembre | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 36, 38 | 6 |
| 840 | `rrhh-twelve-request-current-payroll-real` | Doce solicitudes reales alimentan alta/cálculo UI, aprobación segregada y un pago con GL | 34. Planilla, vacaciones remuneradas y EPS | 03, 15, 35, 38 | 4 |
| 841 | `rrhh-vacation-current` | Nueva planilla noviembre creada desdeUI consume vacaciones aprobadas: sueldo1000 + vacacional200 | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 4 |
| 842 | `rrhh-vacation-settlement-actual-approval` | Noviembre2026 vinculado a vacaciones existentes aprobado una vez; fotografía fresca tras ACK perdido | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 4 |
| 843 | `rrhh-vacation-settlement-actual-payment-restart` | Un salario1044 y un cargo; reintento manual con la misma clave después de reinicio real | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 6 |
| 844 | `rrhh-vacation-settlement-annual` | Resultado y balance del ejercicio completo incluyen devengo Nov30, separados de octubre | 34. Planilla, vacaciones remuneradas y EPS | 31, 35 | 28 |
| 845 | `rrhh-vacation-settlement-finance-aging` | Aging; lectores403 y empresa2vacía | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 55 |
| 846 | `rrhh-vacation-settlement-finance-cashflow` | Flujo proyectado con bancos y obligaciones crudas; lectores403 y empresa2vacía | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 55 |
| 847 | `rrhh-vacation-settlement-finance-debt` | Mayor deuda; lectores403 y empresa2vacía | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 55 |
| 848 | `rrhh-vacation-settlement-finance-movements` | 52 movimientos bancarios únicos en dos páginas, un salario1044; lectores403 y empresa2vacía | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 55 |
| 849 | `rrhh-vacation-settlement-finance-reconciliation` | Conciliaciones pendientes; lectores403 y empresa2vacía | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 55 |
| 850 | `rrhh-vacation-settlement-payment-inflight` | Recuperación de pago y contrato real de tesorería: inflight | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 10 |
| 851 | `rrhh-vacation-settlement-payment-lifecycle` | Recuperación de pago y contrato real de tesorería: lifecycle | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 14 |
| 852 | `rrhh-vacation-settlement-payment-offline` | Recuperación de pago y contrato real de tesorería: offline | 34. Planilla, vacaciones remuneradas y EPS | 35, 38 | 16 |
| 853 | `rrhh-vacation-settlement-payment-reads` | Recuperación de pago y contrato real de tesorería: reads | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 38 |
| 854 | `rrhh-vacation-settlement-payment-receipts` | Recuperación de pago y contrato real de tesorería: receipts | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35, 38 | 78 |
| 855 | `rrhh-vacation-settlement-payment-storage` | Recuperación de pago y contrato real de tesorería: storage | 34. Planilla, vacaciones remuneradas y EPS | 03, 35, 38 | 26 |
| 856 | `rrhh-vacation-settlement-ple` | Cinco PLE octubre122asientos/325líneas/34cuentas/17compras/23ventas desde ambas interfaces | 34. Planilla, vacaciones remuneradas y EPS | 03, 31, 35 | 10 |
| 857 | `rrhh-vacation-settlement-states` | Cinco estados de octubre y seis descargas PDF/Excel por interfaz | 34. Planilla, vacaciones remuneradas y EPS | 31, 35 | 28 |
| 858 | `rrhh-vacation-settlement-tax` | Cálculos mensual/anual actuales, declaraciones5/4 exactas sin nuevas versiones | 34. Planilla, vacaciones remuneradas y EPS | 35 | 6 |
| 859 | `sales-aging-positive-partial-settled` | Aging73.16→53.15→0:CSV, filtros,503/retry, recarga, corte anterior y proyección31días | 31. Libros, estados financieros y reportes operativos | 35, 38 | 6 |
| 860 | `sales-collections-current` | Dos cobros parciales100; primer ACK perdido y reintento con misma intención | 18. Cuentas por cobrar y recuperación de cartera | 35, 38 | 2 |
| 861 | `sales-current-draft-quote-delete-real` | Eliminar cotización borrador: cancelar, confirmar, recargar y contrastar SQL | 08. Gestión comercial: precios, comisiones y cotizaciones | 35 | 1 |
| 862 | `sales-current-flow` | Cliente → cotización236 → aprobación distinta → pedido/reserva → picking/despacho → factura a crédito236 | 08. Gestión comercial: precios, comisiones y cotizaciones | 03, 15, 35 | 8 |
| 863 | `sales-delivery-operation-fill-rate` | Entrega y SLA: configuración deshabilitada real y positivo readonly con bandera en memoria | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 16 |
| 864 | `sales-delivery-operation-lifecycle` | Entrega: recarga, salida, respuesta tardía y recuperación manual | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 14 |
| 865 | `sales-delivery-operation-receipts` | Entrega: recibo completo, intención durable y rechazo de respuestas inciertas | 09. Pedidos, reservas, preparación y entrega | 03, 31, 35, 38 | 54 |
| 866 | `sales-delivery-operation-restart` | Entrega: registro único Windows, ACK perdido y reinicio con clave original | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 5 |
| 867 | `sales-delivery-operation-roles` | Entrega: intención privada del propietario invisible a lectores | 09. Pedidos, reservas, preparación y entrega | 03, 35, 38 | 10 |
| 868 | `sales-delivery-operation-storage` | Entrega: persistencia y retiro verificados sin sobrescribir datos inciertos | 09. Pedidos, reservas, preparación y entrega | 03, 35, 38 | 20 |
| 869 | `sales-existing-two-unit-quote-to-ready` | Cotización existente73.16: enviar, aprobar porotroactor, convertir una vez, confirmar/reservar2 y preparar desdeUI | 08. Gestión comercial: precios, comisiones y cotizaciones | 03, 35 | 5 |
| 870 | `sales-fill-rate-canonical-dispatches` | Habilitar desde UI, consultar dos pedidos canónicos y seis unidades despachadas;100%, OTIF no evaluado,503/retry, contrato incompleto, vacío válido y restaurar | 31. Libros, estados financieros y reportes operativos | 35, 38 | 6 |
| 871 | `sales-fill-rate-partial-full-real` | Fill-rate positivo parcial y completo; habilitar/restaurar desdeUI y recargar | 31. Libros, estados financieros y reportes operativos | 03, 35 | 4 |
| 872 | `sales-final-collection-current` | Cobrar saldo3.60 de F001-00000002 tras aplicación de crédito20; recargar deuda cancelada | 18. Cuentas por cobrar y recuperación de cartera | 35, 38 | 2 |
| 873 | `sales-order-cancel` | Pedido directo a precio40, reserva1 y cancelación con motivo, ACK perdido y retry único | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 6 |
| 874 | `sales-partial-dispatch-lost-ack` | Despachar1de2: cantidades inválidas sinPOST; ACK perdido, recarga, mismo payload/clave recupera despacho sin repetir salida | 09. Pedidos, reservas, preparación y entrega | 35, 38 | 9 |
| 875 | `sales-quote-edit-send-reject` | Editar cotización, conservar formulario ante503, enviar y rechazar por actor distinto | 08. Gestión comercial: precios, comisiones y cotizaciones | 03, 35, 38 | 8 |
| 876 | `sales-report-availability-configuration` | Configurar Fill-rate/KPIs, objetivo y frecuencia indicada; cancelar/validar, ACK perdido/retry mismoID, recargar y restaurar; lector sin editor | 31. Libros, estados financieros y reportes operativos | 03, 15, 35, 38 | 9 |
| 877 | `sales-report-controls-print-current` | Ordenar productos/clientes,Top10/20/50, abrir cliente/cotización reales e imprimir resumen con ocho columnas | 31. Libros, estados financieros y reportes operativos | 35, 38 | 6 |
| 878 | `sales-report-read-cotizaciones-pendientes` | Reporte cotizaciones-pendientes: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 879 | `sales-report-read-cxc-aging` | Reporte cxc-aging: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 880 | `sales-report-read-fill-rate` | Reporte fill-rate: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 881 | `sales-report-read-lead-time` | Reporte lead-time: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 882 | `sales-report-read-pedidos-por-estado` | Reporte pedidos-por-estado: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 883 | `sales-report-read-pipeline` | Reporte pipeline: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 884 | `sales-report-read-productos-mas-vendidos` | Reporte productos-mas-vendidos: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 885 | `sales-report-read-sunat-kpis` | Reporte sunat-kpis: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 5 |
| 886 | `sales-report-read-top-clientes` | Reporte top-clientes: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 887 | `sales-report-read-ventas-por-cliente` | Reporte ventas-por-cliente: filtros ofrecidos,503 sin datos anteriores, retry200, respuesta incompleta y lectura tardía | 31. Libros, estados financieros y reportes operativos | 35, 38 | 5 |
| 888 | `sales-reports-browser-actor-company-isolation` | Mismo navegador: ADMIN principal→ADMIN empresa2→lector inventario→ADMIN; once reportes, recarga y pérdida de red del lector | 31. Libros, estados financieros y reportes operativos | 03, 15, 35 | 27 |
| 889 | `sales-summary-report-current` | Consultar comprobantes reales por fecha/estado/cliente; base gravada, moneda/serie, CSV, error503/retry y descarte de lectura tardía | 31. Libros, estados financieros y reportes operativos | 15, 35, 38 | 9 |
| 890 | `sales-two-dispatches-invoice-partial-collections` | Facturar dos despachos, cobro20.01 conACK/retry y liquidación53.15; recargar y recalcular cinco estados financieros | 18. Cuentas por cobrar y recuperación de cartera | 15, 35, 38 | 10 |
| 891 | `same-actor-late-read-after-role-revocation` | Demorar respuesta200 real autorizada, retirar permiso porUI, recibir403 yliberar lectura vieja; caché cerrada ysin clientes al perder red | 39. Trabajo sin conexión y escritorio Windows | 03, 35, 38 | 6 |
| 892 | `same-actor-role-open-client-page` | Administrador cambia lector→VENDEDOR→lector; sesiónabierta recibe403, retira filas yno reutiliza clientes al perder red | 03. Usuarios, roles, permisos y sesiones | 35, 38 | 7 |
| 893 | `series` | Crear y recargar series B002/F002 para Arequipa | 04. Identidad, parámetros, sucursales y series | 35 | 4 |
| 894 | `service-payment-actual` | Factura de servicio F570-10110001 saldada con pago único PEN 1.77 | 19. Facturas de proveedor y cuentas por pagar | 34, 35, 38 | 6 |
| 895 | `service-payment-current-aging` | Aging después del pago de servicio: lectura/permisos/aislamiento | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35 | 12 |
| 896 | `service-payment-current-cashflow` | Flujo proyectado después del pago de servicio: lectura/permisos/aislamiento | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35 | 10 |
| 897 | `service-payment-current-debt` | Mayor deuda de proveedores después del pago de servicio: lectura/permisos/aislamiento | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35 | 10 |
| 898 | `service-payment-current-movements` | Movimientos bancarios después del pago de servicio: lectura/permisos/aislamiento | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35 | 10 |
| 899 | `service-payment-current-ple` | Cinco libros electrónicos actuales descargados desde UI | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35 | 5 |
| 900 | `service-payment-current-reconciliation` | Conciliaciones pendientes después del pago de servicio: lectura/permisos/aislamiento | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35 | 10 |
| 901 | `service-payment-current-states` | Cinco estados actuales 144 y seis descargas Excel/PDF por interfaz | 19. Facturas de proveedor y cuentas por pagar | 31, 35 | 24 |
| 902 | `service-payment-current-tax` | Cálculos tributarios actuales 144 sin guardar ni presentar declaraciones | 19. Facturas de proveedor y cuentas por pagar | 35 | 6 |
| 903 | `service-purchase-current-reports-143` | Exportar estados yPLE después de recibir yfacturar elservicio | 13. Compras: cotización y orden | 31, 35 | 24 |
| 904 | `service-purchase-distinct-approval` | Aprobar la compra de servicio con otro usuario | 13. Compras: cotización y orden | 35, 38 | 2 |
| 905 | `service-purchase-live-corpus-roles-restart` | Leer servicio recibido,deuda yproducto conroles yreinicio | 13. Compras: cotización y orden | 03, 35, 38 | 12 |
| 906 | `service-purchase-real-invoice-restart` | Registrar la factura del servicio yrecuperar el acuse tras reinicio | 13. Compras: cotización y orden | 35, 38 | 3 |
| 907 | `service-purchase-real-order` | Crear una orden de servicio fraccionario sin almacén | 13. Compras: cotización y orden | 35 | 2 |
| 908 | `service-purchase-real-receipt` | Recibir el servicio sin movimiento de inventario | 14. Recepciones y devoluciones al proveedor | 03, 35 | 2 |
| 909 | `service-receipt-variants-approval` | Aprobación única segregada BUYER | 14. Recepciones y devoluciones al proveedor | 35, 38 | 2 |
| 910 | `service-receipt-variants-batch` | Un lote UI paga sólo las dos facturas nuevas por PEN2.66 | 14. Recepciones y devoluciones al proveedor | 35 | 5 |
| 911 | `service-receipt-variants-current-aging` | Aging actual150; lectores403 y empresa2 vacía | 14. Recepciones y devoluciones al proveedor | 03, 31, 34, 35, 38 | 53 |
| 912 | `service-receipt-variants-current-cashflow` | Flujo proyectado actual150; lectores403 y empresa2 vacía | 14. Recepciones y devoluciones al proveedor | 03, 31, 34, 35, 38 | 53 |
| 913 | `service-receipt-variants-current-debt` | Mayor deuda actual150; lectores403 y empresa2 vacía | 14. Recepciones y devoluciones al proveedor | 03, 31, 34, 35, 38 | 53 |
| 914 | `service-receipt-variants-current-movements` | Movimientos bancarios actual150; lectores403 y empresa2 vacía | 14. Recepciones y devoluciones al proveedor | 03, 31, 34, 35, 38 | 53 |
| 915 | `service-receipt-variants-current-ple` | Cinco libros actuales121 asientos/323líneas/17compras | 14. Recepciones y devoluciones al proveedor | 03, 31, 35 | 5 |
| 916 | `service-receipt-variants-current-reconciliation` | Conciliaciones pendientes actual150; lectores403 y empresa2 vacía | 14. Recepciones y devoluciones al proveedor | 03, 31, 34, 35, 38 | 53 |
| 917 | `service-receipt-variants-current-states` | Cinco estados150 y seis descargas Excel/PDF por interfaz | 14. Recepciones y devoluciones al proveedor | 31, 35 | 24 |
| 918 | `service-receipt-variants-current-tax` | Cálculos tributarios150 sin guardar ni presentar | 14. Recepciones y devoluciones al proveedor | 35 | 6 |
| 919 | `service-receipt-variants-invoices` | Dos facturas únicas ligadas a recepciones aceptadas0.89/1.77 | 14. Recepciones y devoluciones al proveedor | 35 | 4 |
| 920 | `service-receipt-variants-observed` | Recepción observada0.50 completa orden desde acción PARCIAL | 14. Recepciones y devoluciones al proveedor | 35, 38 | 3 |
| 921 | `service-receipt-variants-order` | OC de servicio0.75 creada una vez | 14. Recepciones y devoluciones al proveedor | 35, 38 | 3 |
| 922 | `service-receipt-variants-partial` | Recepción parcial0.25 existente recuperada readonly sin repetir escritor | 14. Recepciones y devoluciones al proveedor | 35, 38 | 4 |
| 923 | `service-receipt-variants-partial-action` | Crear Recepción disponible para PARCIAL con pendiente y permiso; ocho regresiones por interfaz | 14. Recepciones y devoluciones al proveedor | 03, 35 | 16 |
| 924 | `service-receipt-variants-reject` | Rechazo0.25 cerrado sin fulfillment, stock ni GL | 14. Recepciones y devoluciones al proveedor | 35, 38 | 3 |
| 925 | `sire-current-acceptance-failure-original-ui` | SIRE: cancelar confirmación y recuperar error de aceptación con la misma clave | 32. Impuestos y SIRE | 35, 38 | 1 |
| 926 | `sire-current-pending-ticket-contract-ui` | SIRE: ticket pendiente simulado conserva clave de dos consultas fallidas | 32. Impuestos y SIRE | 35, 38 | 1 |
| 927 | `sire-frozen-download-content-integrity` | Descarga SIRE congelada íntegra, rechazo de contenido alterado y recuperación | 32. Impuestos y SIRE | 31, 35, 38 | 104 |
| 928 | `sire-frozen-download-current-role-isolation` | Permisos e aislamiento de descarga SIRE histórica sin regeneración | 32. Impuestos y SIRE | 03, 31, 35 | 8 |
| 929 | `sire-live-read-lifecycle` | SIRE: borrador no enviado preservado ante503 y respuestas tardías descartadas | 32. Impuestos y SIRE | 35, 38 | 16 |
| 930 | `sire-live-read-operations` | SIRE: bitácora completa correlacionada con empresa y reporte; error distinto de vacío | 32. Impuestos y SIRE | 03, 35, 38 | 34 |
| 931 | `sire-live-read-reads` | SIRE: reportes y estadísticas completos en vivo; fallos/caché/cola sin falsos vacíos | 32. Impuestos y SIRE | 03, 35, 38 | 78 |
| 932 | `sire-live-read-restart` | SIRE: reinicio físico del escritorio separado y recuperación de lecturas, sin generación/envío | 32. Impuestos y SIRE | 35, 38 | 6 |
| 933 | `sire-live-read-roles` | SIRE: dos lectores reales sin escritores fiscales y retorno OWNER | 32. Impuestos y SIRE | 03, 35, 38 | 10 |
| 934 | `supplier-create` | Alta de proveedor, edición de contacto con error/retry y recarga sin duplicar | 05. Clientes, proveedores e importaciones | 35, 38 | 4 |
| 935 | `supplier-credit-apply` | Aplicar50 de crédito a factura real: crédito41.44 y deuda176.56 | 19. Facturas de proveedor y cuentas por pagar | 35 | 2 |
| 936 | `supplier-credit-refund` | Reembolsar41.44 al banco; ACK perdido y reintento mismo intento; crédito0 | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 3 |
| 937 | `supplier-final-payment-current` | Pago final176.56 tras aplicación de crédito50 a factura226.56 | 19. Facturas de proveedor y cuentas por pagar | 35 | 1 |
| 938 | `supplier-history-recovery` | Historial caído se muestra como error; reintento recupera pago real200 | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 2 |
| 939 | `supplier-invoice-catalog-current-regression` | Repetir catálogos vivos y reintentos después de cambiar el contrato de respuesta | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 66 |
| 940 | `supplier-invoice-complete-post-receipt` | Exigir recibo completo del alta de proveedor y recuperar49 respuestas inválidas con el mismo cuerpo | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35, 38 | 198 |
| 941 | `supplier-invoice-durable-intent-lifecycle` | Conservar la intención antes del POST y recuperarla tras recarga o Volver sin envío automático | 19. Facturas de proveedor y cuentas por pagar | 34, 35, 38 | 24 |
| 942 | `supplier-invoice-durable-intent-native-restart` | Recuperar un alta pendiente después de cerrar yabrir el proceso Windows | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 5 |
| 943 | `supplier-invoice-durable-intent-offline` | Impedir que un alta sin confirmación se convierta en cola genérica | 19. Facturas de proveedor y cuentas por pagar | 34, 35, 38 | 8 |
| 944 | `supplier-invoice-durable-intent-receipt-catalog` | Repetir el contrato de49 recibos inválidos y los catálogos vivos con la intención durable | 19. Facturas de proveedor y cuentas por pagar | 03, 31, 35, 38 | 264 |
| 945 | `supplier-invoice-durable-intent-roles` | Aislar la intención pendiente durante cambios reales de lector yempresa | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 28 |
| 946 | `supplier-invoice-durable-intent-storage` | Bloquear corrupción o fallos de almacenamiento y conservar una intención cambiada durante el recibo | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 44 |
| 947 | `supplier-invoice-inflight-navigation` | Congelar el formulario durante envío y respetar Volver al llegar un acuse tardío | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 6 |
| 948 | `supplier-invoice-response-current-roles-restart` | Repetir roles/empresa y recuperar corte141 después de reiniciar el binario final | 19. Facturas de proveedor y cuentas por pagar | 03, 35, 38 | 16 |
| 949 | `supplier-invoices` | Registrar facturas recibidas ligadas a recepciones12/8:339.84 y226.56 | 19. Facturas de proveedor y cuentas por pagar | 35 | 2 |
| 950 | `supplier-nc-adjust` | NC recibida por ajuste118, detalle persistido | 19. Facturas de proveedor y cuentas por pagar | 35 | 2 |
| 951 | `supplier-nc-return` | NC recibida por devolución113.28, documento fiscal separado y detalle persistido | 19. Facturas de proveedor y cuentas por pagar | 35 | 2 |
| 952 | `supplier-payment` | Pago parcial bancario200 y saldo139.84 persistidos | 19. Facturas de proveedor y cuentas por pagar | 35, 38 | 2 |
| 953 | `supplier-return-create` | Crear devolución4 unidades | 14. Recepciones y devoluciones al proveedor | 35 | 1 |
| 954 | `supplier-return-emit` | Emitir devolución de proveedor4 unidades y confirmar estado por recarga | 14. Recepciones y devoluciones al proveedor | 03, 35 | 1 |
| 955 | `tax-annual-retry-versions` | Guardar renta anual con ACK perdido, reintentar misma versión y preservar historial | 32. Impuestos y SIRE | 35, 38 | 4 |
| 956 | `tax-coefficient-validation` | Rechazar coeficiente inválido, conservar revisión y versión anterior | 32. Impuestos y SIRE | 35 | 3 |
| 957 | `tax-current-annual-versions-local-constancia` | Versión annual y constancia expresamente simulada local, ACK perdido y recarga | 32. Impuestos y SIRE | 35, 38 | 3 |
| 958 | `tax-current-fresh-adjustments-original-GL` | Anticipo, detracción y depósito: ACK perdido, recarga, efectos únicos y asientos balanceados | 32. Impuestos y SIRE | 15, 20, 35, 38 | 5 |
| 959 | `tax-current-monthly-versions-local-constancia` | Versión monthly y constancia expresamente simulada local, ACK perdido y recarga | 32. Impuestos y SIRE | 35, 38 | 3 |
| 960 | `tax-monthly-carry` | Cambiar a noviembre y recalcular arrastre sin repetir ingreso mensual | 32. Impuestos y SIRE | 15, 35, 38 | 1 |
| 961 | `tax-monthly-outside-cpe` | Registrar ingreso tributario fuera deCPE100 con sustento, recalcular y guardarv3 | 32. Impuestos y SIRE | 15, 35 | 3 |
| 962 | `tax-period-anual-recovery-current-version` | Recuperar Renta Anual e ITAN tras fallos/cambio de período y guardar el corte actual conACK perdido/retry | 32. Impuestos y SIRE | 34, 35, 38 | 14 |
| 963 | `tax-period-mensual-recovery-current-version` | Recuperar IGV y Renta mensual tras fallos/cambio de período y guardar el corte actual conACK perdido/retry | 32. Impuestos y SIRE | 34, 35, 38 | 14 |
| 964 | `tax-period-roles-isolation` | Cambiar actores/empresa en el mismo navegador; consultar como lector contable y rechazar su guardado | 32. Impuestos y SIRE | 03, 34, 35, 38 | 10 |
| 965 | `treasury-batch-final-web-payment` | Pago final1.18 desdeUI, confirmación bancaria/reference y recarga de deuda pagada | 22. Tesorería y programación de pagos | 35 | 2 |
| 966 | `treasury-batch-first-payment-readonly-corroboration` | Primer lote201 con error visual posterior: pago2.36 completo y1.18 parcial corroborados sin repetir writer | 22. Tesorería y programación de pagos | 35 | 2 |
| 967 | `treasury-batch-late-generations` | Respuestas antiguas no reemplazan errores actuales ni rehabilitan el pago | 22. Tesorería y programación de pagos | 35, 38 | 4 |
| 968 | `treasury-batch-native-partial-lost-ack-replay` | Pago parcial nativo1.18 con ACK perdido; misma intención confirma201replay y un cargo | 22. Tesorería y programación de pagos | 35, 38 | 3 |
| 969 | `treasury-batch-no-offline-false-success` | Red/503 antes del writer conserva intención y clave, sin falso pago ni cola nueva | 22. Tesorería y programación de pagos | 35, 38 | 4 |
| 970 | `treasury-batch-paid-bank-ledger-exports` | Dos deudas pagadas, seis asientos y banco; seisPDF/seispáginas yCSV38filas reales | 22. Tesorería y programación de pagos | 31, 35 | 4 |
| 971 | `treasury-batch-role-tenant-isolation` | Dos lectores403 sin datos/acciones, empresa2vacía real y restauraciónOWNER | 22. Tesorería y programación de pagos | 03, 35 | 2 |
| 972 | `treasury-batch-selection-amount-back` | Selección de Programación conservada; lote incluye vencidas, valida importe y preserva pago parcial al volver | 22. Tesorería y programación de pagos | 35, 38 | 4 |
| 973 | `treasury-batch-two-invoices-real-ui` | Dos facturas únicas PEN2.36/3.54 registradas desdeUI, sin recepción física | 22. Tesorería y programación de pagos | 35 | 2 |
| 974 | `treasury-current-accounting116-raw-exports` | Cinco estados del corte116, siete ratios, comparaciones/enero y seis descargas Excel/PDF cotejadas | 31. Libros, estados financieros y reportes operativos | 35, 38 | 2 |
| 975 | `treasury-current-books116-roles-exports` | Diez libros del corte116, fallos/retry/races, lectores403/200, empresa2 vacía y exportación compras | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 3 |
| 976 | `treasury-current-ple116-five-files` | Cinco PLE individuales y descarga conjunta tras503 del corte116 | 31. Libros, estados financieros y reportes operativos | 03, 35, 38 | 6 |
| 977 | `treasury-current-tax116-no-saves` | Tributos actuales116: lecturas/recálculo sin guardar, fallos/retry/períodos/races y versiones inmutables | 32. Impuestos y SIRE | 35, 38 | 2 |
| 978 | `treasury-direct-atomic-recovery-roles` | Tesorería directa y dashboard: contratos completos, retiro de datos fallidos, retry, filtros30/60/90/180, consultas tardías y actores | 22. Tesorería y programación de pagos | 03, 35, 38 | 2 |
| 979 | `treasury-programming-live-complete-recovery` | Programación vigente: vencidas, fallos503/red, retiro de filas/totales/acciones y retry; vacío2099 real | 22. Tesorería y programación de pagos | 35, 38 | 4 |
| 980 | `user-open-session-revoked-by-disable` | Activar vendedor existente, consultar clientes con sesión abierta, dar baja desde otra ventana y verificar401/login bloqueado | 03. Usuarios, roles, permisos y sesiones | 35 | 6 |
| 981 | `users-live-role-browser-native` | Reemplazar y restaurar rol con dos sesiones abiertas; fallo503 conserva editor y el permiso cambia en la consulta siguiente | 03. Usuarios, roles, permisos y sesiones | 34, 35, 38 | 8 |
| 982 | `users-open-session-revocation` | Desactivar usuario con sesión activa y bloquear acceso al recargar | 03. Usuarios, roles, permisos y sesiones | 35 | 3 |
| 983 | `users-read-recovery-lifecycle` | Error catálogo bloquea CRUD; editar rol/teléfono, baja/login denegado, reactivar y denegar administración al vendedor | 03. Usuarios, roles, permisos y sesiones | 35, 38 | 10 |
| 984 | `warehouses` | Crear almacenes Lima y Arequipa vinculados a establecimiento | 07. Existencias, kardex, ajustes y transferencias | 35 | 4 |
| 985 | `wizard-current-completion-logo-real` | Cierre del asistente y logo: recuperar respuestas perdidas sin repetir efecto | 02. Primer acceso y preparación de la empresa | 35, 38 | 1 |
| 986 | `wizard-current-reset-and-reconfigure-real` | Reinicio cancelado, ACK perdido, replay exacto y configuración nueva tras recarga | 02. Primer acceso y preparación de la empresa | 35, 38 | 2 |
| 987 | `wizard-read-contracts-recovery-isolation` | Estado, progreso, empresa y demo: rechazar503/200incompleto/red; reintentar y descartar lectura tardía sin escrituras automáticas | 02. Primer acceso y preparación de la empresa | 03, 35, 38 | 2 |
| 988 | `wizard-rejected-step-confirmations-preserve-intent` | Cinco confirmaciones inválidas de paso conservan Welcome e intención sin avanzar | 02. Primer acceso y preparación de la empresa | 35, 38 | 2 |