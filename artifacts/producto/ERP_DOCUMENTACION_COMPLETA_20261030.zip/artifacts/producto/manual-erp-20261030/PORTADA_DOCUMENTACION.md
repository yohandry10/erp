# Documentación del ERP por finalidad

## A. Entender el funcionamiento

[Manual funcional y operativo](MANUAL_DEL_PRODUCTO.html): procesos por dominio, reglas, ejemplos, restricciones y recuperación.

## B. Operar según la responsabilidad

[Guías por rol y responsabilidad](GUIAS_POR_ROL.html): administración, ventas, compras, almacén, caja, finanzas, contabilidad y RRHH, más soporte transversal.

[Inventario de pantallas](INVENTARIO_DE_PANTALLAS.html): rutas verificadas desde código, con referencia de proceso y límites del contraste visual.

## C. Seguir un proceso entre áreas

[Procesos empresariales](PROCESOS_EMPRESARIALES.html): compras de bienes, servicios, venta a crédito, POS, devoluciones, remuneraciones y cierre.

## D. Administrar y mantener el servicio

[Guía técnica y operativa](GUIA_TECNICA_Y_OPERATIVA.html): acceso a los seis documentos canónicos incluidos, diagnóstico, respaldo, recuperación, promoción y dependencias externas.

## E. Consultar la certificación

[Filas UAT y controles originales](REFERENCIA_FUNCIONAL_COMPLETA.html) y [linaje de las rondas](ALCANCE_HISTORICO.md). Los resultados de certificación no son instrucciones de operación ni prueban exhaustividad del manual.

## Cobertura y vacíos comprobados

[Evaluación de producto](EVALUACION_DE_PRODUCTO.html): qué existe realmente, qué se ha añadido y qué no queda acreditado todavía. No se cuentan filas de prueba como funciones distintas ni enlaces válidos como reglas completamente explicadas.
