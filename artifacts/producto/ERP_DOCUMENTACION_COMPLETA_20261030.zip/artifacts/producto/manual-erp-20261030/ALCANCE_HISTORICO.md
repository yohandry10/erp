# Conciliación del alcance histórico y rondas UAT

La matriz original contiene 1.012 filas de matriz. Su selección de 988 casos coincide exactamente, por identificador, con la consolidación vigente. Los 24 registros restantes se conservan y se explican individualmente a continuación. Los estados históricos no se convierten en aprobaciones ni pendientes actuales.

## Rondas

UAT576 inicial precede a 576R2. No se atribuye el nombre literal R1 sin una fuente que lo confirme. 576R2 y R3 comparten la matriz original de 988 requisitos: el archivo descomprimido de R3 coincide por SHA-256 con la fuente R2. Las rondas no se suman como requisitos distintos.

## Correspondencia de las 24 filas

| ID histórico | Estado de esa ejecución | Sección del manual | Requisitos actuales relacionados |
|---|---|---|---|
| rrhh-vacation-old | CASO_LOCAL_ANTERIOR_NO_RETEST_570 | 33. Vacaciones y permisos con decisión persistida | rrhh-requests-current, rrhh-requests-current-live-read |
| rrhh-liquidation-old | CASO_LOCAL_ANTERIOR_NO_RETEST_570 | 35. Liquidación con historia de beneficios verificable | rrhh-liquidation-current, rrhh-liquidation-overlap-cese-unique-days-recovery |
| mixed-receipt-native-second-partial | PARCIAL_CON_FALLO_PRESERVADO | 14. Continuar una recepción parcial en Windows | mixed-receipt-native-remainder-ack, mixed-receipt-web-partial, mixed-receipt-roles-restart |
| budget-delete-receipt-baseline | P1_HISTORICO_CORREGIDO_REVALIDADO_570 | 25. Confirmar la baja de un presupuesto | budget-delete-operation-receipts, budget-delete-operation-real |
| rrhh-vacation-source-pagination | PENDIENTE | 34. Usar las vacaciones aprobadas completas | rrhh-vacation-current, rrhh-twelve-request-current-payroll-real, rrhh-liquidation-overlap-cese-unique-days-recovery |
| inventory-sucursal-source-pagination | PENDIENTE | 07. Stock y precios en la sucursal seleccionada | inventory-current-real-original-recovery-transfer-kardex, warehouses |
| revaluation-registration-receipt-support | PENDIENTE | 29. Recuperar una revaluación registrada | revaluation-registration-operation-receipts |
| asset-depreciation-source-pagination | PENDIENTE | 26. Seleccionar el lote completo de depreciación | asset-depreciation-original-batch-receipt-recovery, asset-schedule-live-read-recovery |
| asset-create-receipt-api | PENDIENTE | 26. Confirmación del alta de un activo | asset-current-real-create-ack-recovery, asset-create-operation-receipts |
| rrhh-employee-source-pagination | PENDIENTE | 34. Incluir a los empleados de la empresa | rrhh-payroll-create-complete-source, rrhh-current-calculator-complete-source-regression |
| rrhh-contract-source-pagination | PENDIENTE | 34. Elegir el contrato vigente del período | rrhh-calculation-source-salary, rrhh-payroll-create-complete-source |
| rrhh-payroll-source-pagination | PENDIENTE | 34. Elegir una planilla desde un catálogo completo | rrhh-payroll-create-complete-source, rrhh-vacation-current |
| rrhh-payroll-detail-source-pagination | PENDIENTE | 34. Consultar el detalle completo de planilla | rrhh-current-calculator-complete-source-regression, rrhh-tail-payroll-complete |
| rrhh-payroll-concept-source-pagination | PENDIENTE | 34. Revisar todos los conceptos de remuneración | rrhh-current-calculator-complete-source-regression, rrhh-tail-payroll-complete |
| rrhh-calculation-rpc-receipt | PENDIENTE | 34. Comprobar el resultado completo del cálculo | rrhh-current-calculator-complete-source-regression, rrhh-tail-payroll-complete |
| rrhh-calculation-original-intent-ledger | PENDIENTE | 34. Mantener la identidad del cálculo de planilla | rrhh-current-calculator-complete-source-regression, rrhh-cross-source503-keeps-draft |
| rrhh-payroll-create-complete-rpc-receipt | PENDIENTE | 34. Confirmar la creación de la planilla | rrhh-payroll-create-complete-source, rrhh-payroll-create-source-recovery-period |
| rrhh-payroll-create-original-operation-ledger | PENDIENTE | 34. Recuperar el alta original de planilla | rrhh-payroll-create-source-recovery-period, rrhh-cross-source503-keeps-draft |
| inventory-operation-complete-original-ledger-receipt | PENDIENTE | 07. Identidad y archivo del movimiento confirmado | inventory-original-receipt-ui-binding, inventory-original-receipt-ui-durable-archive |
| inventory-original-receipt-readonly-recovery | PENDIENTE | 07. Recuperar el recibo sin ejecutar el movimiento | inventory-manual-original-read-no-catalog, inventory-manual-original-read-fault-storage |
| inventory-readonly-harness-incident-audited | PENDIENTE | 41. Distinguir consulta de modificación durante soporte | inventory-current-real-original-recovery-transfer-kardex |
| inventory-frozen-cost-fixed-scale-read-recovery | PENDIENTE | 07. Costo histórico de una operación recuperada | inventory-current-real-original-recovery-transfer-kardex, inventory-original-receipt-ui-binding |
| inventory-operation-atomic-abandonment-fence | PENDIENTE | 07. Resolver un intento de inventario abandonado | inventory-original-receipt-ui-binding, inventory-manual-original-read-no-catalog |
| inventory-operation-original-resolution-api | PENDIENTE | 07. Consultar si el original fue confirmado o abandonado | inventory-original-receipt-ui-binding, inventory-manual-original-read-fault-storage |

## Instrucciones conservadas por fila

### rrhh-vacation-old

Registre el tipo de solicitud y sus fechas, revise los días y envíe la decisión con el permiso correspondiente. Después de aprobar o rechazar, recargue y consulte el estado persistido. Una solicitud rechazada no se trata como vacaciones aprobadas. El registro de otra empresa no debe aparecer al cambiar de sesión.

### rrhh-liquidation-old

Indique la fecha de cese y revise CTS, gratificaciones y vacaciones con sus fuentes históricas. Si falta la historia necesaria, el conflicto conserva la revisión y no autoriza a suponer un beneficio pagado. El resultado depende de esas fechas y fuentes; los importes de una prueba antigua no son una fórmula ni un saldo aplicable a otro trabajador.

### mixed-receipt-native-second-partial

Abra la orden parcial y revise lo recibido y su saldo por línea. Registre únicamente la cantidad pendiente que corresponda. Si se pierde la confirmación, recupere el mismo intento y compruebe las recepciones existentes antes de recibir otra vez. El fallo de una prueba histórica no equivale a una segunda recepción pendiente del usuario.

### budget-delete-receipt-baseline

Cancelar la confirmación conserva el presupuesto. Al confirmar, un recibo vacío o perteneciente a otro presupuesto no acredita la baja. Conserve la intención, recupere su resultado y recargue el listado. No interprete una respuesta HTTP exitosa por sí sola como ausencia confirmada del presupuesto.

### rrhh-vacation-source-pagination

El cálculo consume las solicitudes aprobadas pertinentes al período. Compruebe todas las páginas y fechas; una consulta fallida no equivale a cero vacaciones. Los solapamientos se revisan por fechas únicas y la liquidación limita las fechas al cese. Registrar o aprobar la solicitud no constituye por sí mismo el pago de vacaciones.

### inventory-sucursal-source-pagination

Compruebe empresa, sucursal y almacén antes de interpretar disponibilidad o precio. Las fuentes deben terminar de cargar todas sus páginas; no extrapole el stock de una primera página ni reutilice datos de otra sucursal. Si cambia el alcance, espere la nueva consulta y descarte la respuesta del alcance anterior.

### revaluation-registration-receipt-support

La simulación y el registro son pasos distintos. Después de registrar, el resultado recuperado debe corresponder a la fecha, simulación, solicitud y asiento originales. Una lectura actual del tipo de cambio no sustituye esa fotografía. Si falta la confirmación, recupere el original antes de registrar otra revaluación.

### asset-depreciation-source-pagination

Revise el período y los candidatos cargados por completo. Una página ausente o una lectura fallida no representa un lote vacío ni autoriza depreciar una selección parcial como si fuera completa. Recupere la consulta; después confirme el lote y conserve su recibo original.

### asset-create-receipt-api

Después de guardar, el alta sólo queda confirmada cuando el recibo corresponde al activo, empresa, usuario y solicitud originales. Una respuesta incompleta conserva el intento pendiente. Consulte o recupere ese mismo intento antes de crear otro activo.

### rrhh-employee-source-pagination

Espere la carga completa del catálogo de empleados antes de calcular. Una lista parcial no representa a toda la empresa y un error no significa ausencia de trabajadores. Cambiar de empresa exige volver a validar las fuentes y no debe conservar empleados del contexto anterior.

### rrhh-contract-source-pagination

La calculadora necesita los contratos completos de la empresa y del empleado, no sólo el primer resultado disponible. Verifique la vigencia en el período y el sueldo confirmado. Si falla una página, recupere la fuente; no complete el cálculo suponiendo que no hay contrato.

### rrhh-payroll-source-pagination

Al seleccionar una planilla para una operación relacionada, compruebe empresa y período y espere el catálogo completo. Una lectura fallida no acredita que la planilla no exista ni habilita crear otra. Recupere la consulta y vuelva a revisar el vínculo antes de aplicar un beneficio o crédito.

### rrhh-payroll-detail-source-pagination

La consulta debe terminar todas las páginas del detalle de la planilla seleccionada. Un subtotal de una página no acredita el total de trabajadores. Confirme además la completitud de los conceptos de cada empleado; la cabecera, los empleados y los conceptos son fuentes relacionadas con verificaciones distintas.

### rrhh-payroll-concept-source-pagination

El detalle de una planilla debe incluir los conceptos completos de cada empleado. Cargar la cabecera o la lista de empleados no confirma que ingresos, descuentos y aportes estén completos. Ante un fallo, recupere el detalle antes de aprobar, pagar o emitir una boleta como definitiva.

### rrhh-calculation-rpc-receipt

La confirmación debe corresponder a la planilla y sus empleados e importes calculados. Un total aislado no acredita un detalle completo. Ante un resultado incompleto, mantenga la solicitud y recupere su confirmación; revise el detalle y las fuentes antes de solicitar aprobación.

### rrhh-calculation-original-intent-ledger

El cálculo conserva su planilla, solicitud e identidad originales durante la recuperación. Si una fuente falla, el borrador no se considera calculado. Recupere las fuentes y el mismo intento; no cree otra planilla para resolver una respuesta perdida. La resolución de un abandono debe confirmarse antes de preparar un intento nuevo.

### rrhh-payroll-create-complete-rpc-receipt

El recibo de creación debe corresponder a empresa, período, país, moneda, usuario y datos originales. La planilla creada se inicia en borrador y con pago pendiente; crear no equivale a calcular, aprobar ni pagar. Un recibo incompleto conserva la intención para recuperación.

### rrhh-payroll-create-original-operation-ledger

Al volver, recargar o recuperar la conexión, conserve la identidad y los datos del alta pendiente. La recuperación consulta o reintenta ese original; no crea automáticamente otra planilla. Si cambia el período, revise y resuelva primero la intención pendiente para no mezclar fuentes de dos meses.

### inventory-operation-complete-original-ledger-receipt

Compruebe que el recibo pertenece al mismo ajuste o traslado, empresa, usuario, clave y datos enviados. La aplicación conserva la intención hasta archivar y verificar el recibo completo. Si falla el archivo, mantenga la operación recuperable; no vuelva a registrar el movimiento como una operación nueva.

### inventory-original-receipt-readonly-recovery

La consulta manual del recibo original no repite el ajuste ni la transferencia y puede recuperar el resultado aunque fallen los catálogos actuales. Si el recibo es ajeno, parcial o inválido, la operación continúa pendiente. No cambie producto o almacén para intentar recuperar otra operación.

### inventory-readonly-harness-incident-audited

Una investigación de soporte debe declarar cualquier cambio que haya producido y conservar la evidencia anterior y posterior. Una prueba que modificó existencias no puede presentarse como consulta de sólo lectura. Para revisar un resultado use recibos y lecturas; una corrección del stock requiere su propia operación autorizada y trazable.

### inventory-frozen-cost-fixed-scale-read-recovery

Al recuperar un ajuste o traslado, revise el costo registrado en su operación original. No reconstruya ese costo con el precio, stock o promedio actuales. La presentación puede redondear una cifra; la recuperación debe conservar la precisión del valor registrado y su relación con el kardex.

### inventory-operation-atomic-abandonment-fence

Use la resolución explícita de la operación pendiente. Si el servidor confirma abandono, el intento anterior queda cerrado y una petición tardía no debe ejecutarlo. El formulario conserva sus valores para revisión; un nuevo envío requiere una intención nueva. Abandonar no revierte un movimiento ya confirmado.

### inventory-operation-original-resolution-api

La resolución distingue una operación confirmada de otra abandonada. Una respuesta incierta no se interpreta como ninguna de las dos. Mantenga el intento y consulte de nuevo con su contexto original. Un recibo confirmado recupera el movimiento existente; el abandono confirmado permite revisar los campos conservados.

## Controles de las ocho fases

Los 62 controles originales se conservan literalmente en ALCANCE_HISTORICO.json y se explican por responsabilidad en REFERENCIA_FUNCIONAL_COMPLETA.html. No son otras 62 operaciones de negocio.

## Comprobación y límites

La entrega verifica igualdad de identificadores, orden, criterios y contenido de sus detalles contra las fuentes con hash. Cada operación tiene una ficha y acceso al procedimiento del manual. Se ha añadido texto explícito para las 24 filas históricas. La verificación estructural no afirma que una clasificación automática sea una revisión humana independiente de cada aserción ni altera la certificación.
