# Documentación de producto del ERP

El punto de entrada es [Documentación por finalidad A–E](PORTADA_DOCUMENTACION.html). La [evaluación de cobertura](EVALUACION_DE_PRODUCTO.html) distingue material disponible, vacíos y límites de verificación.

El **Manual funcional y operativo** es la referencia por dominio; los anexos UAT se conservan como certificación, sin equiparar sus filas a funciones distintas.

- [Leer el libro con índice y búsqueda](MANUAL_DEL_PRODUCTO.html).
- [Texto completo del manual](MANUAL_DEL_PRODUCTO.md).
- [Libro en PDF](output/pdf/MANUAL_DEL_PRODUCTO_ERP.pdf).
- [Referencia funcional de las 1.012 filas de matriz y los 62 controles](REFERENCIA_FUNCIONAL_COMPLETA.html).
- [Conciliación de UAT576, 576R2, R3 y las 24 filas históricas](ALCANCE_HISTORICO.md).
- [Revisión de omisiones: 13 correcciones contrastadas con el producto](REVISION_DE_OMISIONES.md).
- [Correspondencia de los 988 requisitos actuales](COBERTURA_UAT.md).
- [Correspondencia estructurada e íntegra](COBERTURA_UAT.json).
- [Fuentes y hashes de la edición](manifest.json).

La edición ampliada 2 desarrolla 42 capítulos para usuarios, responsables de área, administradores y soporte. Cada capítulo incorpora datos de trabajo, decisiones, procedimientos o comprobaciones y ejemplos de interpretación. El PDF incluye marcadores de capítulo y sección; el lector HTML ofrece un índice interno por capítulo. Incorpora instrucciones explícitas para las 24 filas históricas adicionales. La referencia complementaria conserva las 1.012 filas de matriz del universo original, los 19.598 criterios de los 988 requisitos actuales y los 62 controles originales de ocho fases. No se han vuelto a ejecutar pruebas ni se ha cambiado el dictamen. R2 y R3 son rondas sobre la misma matriz; no se suman como requisitos distintos.

`scope-completeness-validation.json` comprueba los identificadores, el orden y los detalles completos de los criterios contra las fuentes con hash. Esta validación acredita integridad documental; no atribuye una nueva certificación ni una revisión humana independiente a un proceso automático.

La guía explica las capacidades del candidato documentado y distingue operación interna, estados fiscales, confirmación, conexión, recuperación y restricciones. No representa despliegue ni habilitación fiscal externa.
