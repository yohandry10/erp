# Evaluación de cobertura documental del producto

Esta evaluación inspecciona los archivos locales y el código congelado; no se basa sólo en los mensajes del chat. La documentación UAT y las validaciones de enlaces se mantienen, pero no se usan como prueba automática de exhaustividad funcional.

## Qué se confundía

- 988 son requisitos o filas actuales de una matriz con muchas variantes; no 988 procedimientos empresariales independientes.
- 1.012 son filas del corpus histórico: 988 seleccionadas y 24 adicionales. No se ha demostrado que representen 1.012 funciones distintas.
- `DETALLE_DE_PROCEDIMIENTOS.md` amplía 42 capítulos; no contiene 988 procedimientos individuales.
- Los 62 controles pertenecen a ocho fases de certificación y servicio; no son otras 62 funciones de usuario.
- Los 19.598 son ocurrencias de criterios conservados con sus detalles. Su presencia en un anexo acredita fidelidad de fuente, no explicación semántica completa.
- La documentación técnica sí existía en seis documentos canónicos. Faltaba integrarla en el paquete y distinguir sus ejemplos históricos de los procedimientos vigentes.

## Revisión de las cinco áreas

| Área | Evidencia inspeccionada y acción realizada | Qué puede afirmarse | Qué no queda acreditado |
|---|---|---|---|
| A. Referencia funcional | Manual de 42 capítulos, reglas y 13 correcciones contrastadas con fuentes. | Existe una base funcional extensa por dominio. | Que todas las reglas vigentes y todas sus relaciones tengan una explicación identificable. |
| B. Usuario por rol | Se incorporan ocho guías operativas y una responsabilidad transversal de soporte. Se inventarían 124 páginas de fuente verificadas. | Hay recorridos y referencias reales de pantallas para cada responsabilidad. | Un manual visual exhaustivo de las 124 páginas, con capturas, controles y mensajes contrastados individualmente. |
| C. Procesos empresariales | Se incorporan siete recorridos entre áreas con entradas, entregas, efectos y excepciones. | Compras de bienes y servicios, venta, POS, devolución, remuneraciones y cierre tienen recorridos propios. | Todas las variantes empresariales posibles o etapas no implementadas, como una requisición interna independiente. |
| D. Técnica y operación | Se integran los seis documentos canónicos con hashes y una guía de diagnóstico, respaldo, despliegue y activación. | La documentación técnica está localizada e incluida en la entrega. | Un catálogo exhaustivo de todos los contratos API, una validación de todos los runbooks o RTO/RPO no medidos. |
| E. Certificación UAT | Matriz, criterios, controles, linaje y certificado existentes; no se ejecutan pruebas nuevas. | La trazabilidad e integridad del corpus UAT se preservan. | Que aprobar UAT o validar enlaces cierre por sí solo las áreas A–D. |

## Vacíos reales que permanecen identificados

1. No existe una revisión semántica completa que relacione cada comportamiento vigente del código con una explicación funcional precisa. La clasificación por capítulo no la sustituye.
2. No hay contraste visual individual de cada pantalla en esta revisión. Las rutas verificadas no equivalen a capturas o recorridos de interfaz validados.
3. Analytics existe en el código y estaba excluido de UAT. Requiere una guía propia de interpretación y fuentes; no puede desaparecer del alcance de producto por esa exclusión.
4. Las guías por responsabilidad explican tareas y separación de facultades, pero no constituyen una matriz manual completa de permisos. Esa autoridad permanece en los decorators, guards y catálogo vigentes.
5. Los ejemplos históricos de promoción y restauración tienen versiones y límites específicos. No se convierten en procedimientos universales para el candidato 577.
6. Las integraciones reales por cliente, validación legal y aceptación externa continúan sujetas a sus evidencias y activación; no se cierran con esta revisión documental.

## Decisión documental

La entrega se presenta como una suite de documentación en cinco áreas con cobertura y límites explícitos. **No se acredita como documentación integral exhaustiva terminada.** Esto no invalida ni reabre la certificación UAT. El trabajo nuevo de esta revisión es documental: guías por responsabilidad, procesos entre módulos, integración técnica, inventario independiente de pantallas y corrección de las unidades de conteo.
