Este directorio es el expediente técnico de pruebas. La documentación de producto para uso del ERP está en [Manual funcional y operativo](../../../producto/manual-erp-20261030/LEEME.md).

# Documentación UAT del 1 al 988

- [Consultar con búsqueda y navegación](UAT_COMPLETO.html).
- [Leer el documento completo](UAT_COMPLETO.md).
- [Datos íntegros estructurados](UAT_COMPLETO.json).
- [Hashes y comprobación de integridad](manifest.json).

El orden, los988IDs y los19.598criterios son los de la matriz certificada. Cada requisito documenta su operación, criterios literales, resultado consolidado, procedencia R2/R3, evidencias y límites. No se ejecutaron de nuevo las pruebas ni se modificó su aceptación.

La versión HTML funciona sin conexión y muestra un requisito a la vez; el Markdown contiene todos de principio a fin. Los archivos de evidencia permanecen en sus rutas originales. Los hashes permiten contrastar la fuente. La documentación conserva las limitaciones del certificado local577 y no autoriza activación productiva.
